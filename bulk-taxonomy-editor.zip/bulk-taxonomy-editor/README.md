# Bulk Content & Taxonomy Manager

إضافة ووردبريس لإدارة التصنيفات وحقول JetEngine (بما فيها Repeater) لعدة منشورات دفعة واحدة، مع REST API لإنشاء البوستات.

## المميزات

- تحديد نوع المنشور (Post Type) الذي تريد تعديله
- اختيار عدة تصنيفات (Taxonomies) مع المصطلحات التابعة لها
- تنفيذ إجراءات: إضافة/استبدال/إزالة المصطلحات
- دعم حقول JetEngine Repeater وتعديلها جماعيًا
- اختيار المنشورات التي تريد تعديلها دفعة واحدة
- البحث السريع في المنشورات والمصطلحات
- REST API لإنشاء بوستات جديدة مع taxonomies و meta
- صفحة إعدادات للـ API (تفعيل/صلاحيات/أنواع بوست)

## التثبيت

1. قم بتحميل مجلد الإضافة بالكامل
2. ارفع المجلد إلى مجلد `wp-content/plugins/` في موقع ووردبريس الخاص بك
3. قم بتفعيل الإضافة من صفحة "الإضافات" في لوحة تحكم ووردبريس

## الاستخدام

1. انتقل إلى صفحة "Bulk Content & Taxonomy Manager" من لوحة تحكم ووردبريس
2. حدد نوع المنشور (Post Type) الذي تريد تعديله
3. اختر التصنيفات (Taxonomies) وحدد المصطلحات داخل كل تصنيف
4. (اختياري) أدخل بيانات حقول JetEngine Repeater
5. اختر نوع الإجراء الذي تريد تنفيذه:
   - إضافة المصطلحات للمنشورات (مع الحفاظ على المصطلحات الحالية)
   - استبدال جميع المصطلحات بالمصطلحات المحددة
   - إزالة المصطلحات المحددة من المنشورات
6. حدد المنشورات التي تريد تعديلها
7. اضغط على زر "تحديث المنشورات" لتطبيق التغييرات

## REST API المخصص (Custom API)

الإضافة توفر مسارات API مخصصة للتعامل الآلي (مثلاً عبر Custom GPT) مع التصنيفات وحقول JetEngine المعقدة (بما فيها الـ Repeaters، رفع الصور عبر الروابط أوتوماتيكياً، والمقتطفات).
تعتمد الإضافة على مصادقة `Basic Auth` باستخدام اسم المستخدم وكلمة المرور الأساسية (إذا تم تفعيل إضافة JSON Basic Authentication).

### 1- جلب قائمة البوستات (GET)
لجلب أرقام الـ IDs وعناوين البوستات أو الرحلات بسهولة (وهذا مفيد جداً للـ GPT قبل البدء في أي تعديل):
- **المسار الافتراضي:** `/wp-json/bulk-taxonomy-editor/v1/posts`

```powershell
$pair = "Username:Password"
$encoded = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($pair))

# مسار لجلب قائمة الرحلات (أرقام الـ IDs والعناوين فقط)
$uri = "https://your-site.com/wp-json/bulk-taxonomy-editor/v1/posts?post_type=tours-and-activities&per_page=50"

$response = Invoke-RestMethod -Uri $uri -Method Get -Headers @{ Authorization = "Basic $encoded" }
foreach ($tour in $response.data) { Write-Host ("ID: " + $tour.id + " | Title: " + $tour.title + " | Status: " + $tour.status) }
```

### 2- قراءة تفاصيل بوست مخصص مع حقول JetEngine (GET)
يقوم هذا المسار بقراءة البوست وإرجاعه بنفس البنية المهيكلة التي يفهمها الـ API عند الإنشاء:
- **المسار:** `/wp-json/bulk-taxonomy-editor/v1/posts/{id}`
```powershell
$uri = "https://your-site.com/wp-json/bulk-taxonomy-editor/v1/posts/55300"
$response = Invoke-RestMethod -Uri $uri -Method Get -Headers @{ Authorization = "Basic $encoded" }
# حفظ الداتا في ملف لدعم العربي
$response.data | ConvertTo-Json -Depth 10 | Out-File "Tour_Data.json" -Encoding UTF8
```

### 3- إنشاء أو تعديل بوست ببيانات معقدة وصور (POST/PUT/PATCH)
- **المسار:** `/wp-json/bulk-taxonomy-editor/v1/posts` (يقبل طرق POST و PUT و PATCH).
- **ميزة رفع الصور:** إذا تم تمرير رابط ويب مباشر (`http...`) في أي حقل صورة أو داخل Repeater في الـ `meta`، ستقوم الإضافة تلقائياً بتحميل الصورة لمكتبة الوسائط وربط الـ ID بالبوست.
- **التعديل الآمن (Safe Update):** لتعديل بوست موجود، أضف `"id": 55441` ضمن الـ JSON. أرسل فقط الحقول التي تريد تعديلها (سواء نصوص أو meta) والإضافة لن تقوم بمسح الحقول القديمة الغير موجودة في الطلب.
- **التعديل (Update):** لتعديل بوست موجود، فقط أضف `"id": 55441` ضمن الـ JSON.

**مثال تطبيقي (JSON Payload):**
```powershell
$jsonPayload = @"
{
  "id": 55441, 
  "post_type": "tours-and-activities",
  "title": "عنوان المقال أو الرحلة",
  "content": "<p>محتوى المقال</p>",
  "excerpt": "مقتطف المقال",
  "status": "publish",
  "tax_input": {
    "location_jet": ["665"]
  },
  "meta": {
    "rank_math_focus_keyword": "كلمة مفتاحية",
    "prices": 500,
    "itinerary_item": [
      {
        "number": 1,
        "title": "اليوم الأول",
        "description": "استقبال من المطار",
        "image": "https://example.com/image.jpg"
      }
    ]
  }
}
"@

# تحويل النص لـ UTF-8 لضمان وصول العربي سليم
$utf8Bytes = [System.Text.Encoding]::UTF8.GetBytes($jsonPayload)

Invoke-RestMethod -Uri "https://your-site.com/wp-json/bulk-taxonomy-editor/v1/posts" `
  -Method Post -Headers @{ Authorization="Basic $encoded"; "Content-Type"="application/json; charset=utf-8" } `
  -Body $utf8Bytes
```

### 4- حذف بوست نهائياً (DELETE)
يُستخدم المسار الافتراضي للووردبريس للحذف النهائي متخطياً سلة المهملات:
```powershell
Invoke-RestMethod -Uri "https://your-site.com/wp-json/wp/v2/posts/55441?force=true" `
  -Method Delete -Headers @{ Authorization = "Basic $encoded" }
```

## المتطلبات

- ووردبريس 5.0 أو أحدث
- PHP 7.0 أو أحدث

## الدعم

إذا واجهت أي مشاكل أو كان لديك أي استفسارات، يرجى التواصل معنا عبر:
- البريد الإلكتروني: support@example.com
- الموقع الإلكتروني: https://example.com/support

## الترخيص

هذه الإضافة مرخصة تحت رخصة GPL v2 أو أحدث.

## التغييرات

### الإصدار 1.0.0
- الإصدار الأول من الإضافة
- إمكانية تعديل التصنيفات لعدة منشورات دفعة واحدة
- واجهة سهلة الاستخدام باللغة العربية
