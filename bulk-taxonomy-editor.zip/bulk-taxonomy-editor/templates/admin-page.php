<?php
/**
 * صفحة إدارة تعديل المحتوى المجمع
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap bulk-taxonomy-editor-wrap">
    <h1><?php _e('Bulk Taxonomy Editor', 'bulk-taxonomy-editor'); ?></h1>

    <div class="bte-notices">
        <?php if ($message === 'success'): ?>
             <div class="notice notice-success is-dismissible"><p><?php echo esc_html($message_text); ?></p></div>
        <?php elseif ($message === 'error'): ?>
             <div class="notice notice-error is-dismissible"><p><?php echo esc_html($message_text); ?></p></div>
        <?php elseif ($message === 'warning'): ?>
             <div class="notice notice-warning is-dismissible"><p><?php echo esc_html($message_text); ?></p></div>
        <?php endif; ?>
    </div>

    <div class="bte-container">
        <div class="bte-form-container">
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" id="bulk-taxonomy-editor-form">
                <input type="hidden" name="action" value="bulk_taxonomy_editor_update">
                <?php wp_nonce_field('bulk_taxonomy_editor_nonce', 'bulk_taxonomy_editor_nonce_field'); ?>

                <div class="bte-section">
                    <h2><?php _e('Editor Mode', 'bulk-taxonomy-editor'); ?></h2>
                    <div class="bte-field">
                        <label>
                            <input type="radio" name="object_type" value="post" checked> <strong><?php _e('Edit Posts', 'bulk-taxonomy-editor'); ?></strong>
                        </label>
                        <label style="margin-left: 20px;">
                            <input type="radio" name="object_type" value="term"> <strong><?php _e('Edit Taxonomy Terms', 'bulk-taxonomy-editor'); ?></strong>
                        </label>
                    </div>
                </div>

                <div class="bte-section">
                    <h2><?php _e('Select Target', 'bulk-taxonomy-editor'); ?></h2>
                    <div class="bte-field">
                        <span id="wrapper-post-type" style="display:inline-block;">
                            <label for="post-type-select"><?php _e('Post Type:', 'bulk-taxonomy-editor'); ?></label>
                            <select name="post_type" id="post-type-select">
                                <option value=""><?php _e('-- Select Post Type --', 'bulk-taxonomy-editor'); ?></option>
                                <?php foreach ($post_types as $pt): ?>
                                    <option value="<?php echo esc_attr($pt->name); ?>"><?php echo esc_html($pt->labels->name); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </span>

                        <span id="wrapper-taxonomy" style="display:none;">
                            <label for="taxonomy-mode-select"><?php _e('Taxonomy:', 'bulk-taxonomy-editor'); ?></label>
                            <select name="taxonomy_target" id="taxonomy-mode-select">
                                <option value=""><?php _e('-- Select Taxonomy --', 'bulk-taxonomy-editor'); ?></option>
                                <?php
                                $public_taxonomies = get_taxonomies(array('public' => true), 'objects');
                                foreach ($public_taxonomies as $tax) {
                                    echo '<option value="' . esc_attr($tax->name) . '">' . esc_html($tax->labels->name) . '</option>';
                                }
                                ?>
                            </select>
                        </span>

                        <?php
                        // WPML Language Selector
                        $active_languages = apply_filters('wpml_active_languages', NULL, 'orderby=id&order=desc');
                        if (is_array($active_languages) && !empty($active_languages)) {
                            echo '<label for="language-select" style="margin-left: 20px; margin-right: 5px;">' . __('Language:', 'bulk-taxonomy-editor') . '</label>';
                            echo '<select name="language" id="language-select">';
                            echo '<option value="all">' . __('All Languages', 'bulk-taxonomy-editor') . '</option>';
                            foreach ($active_languages as $l) {
                                $selected = $l['active'] ? 'selected="selected"' : '';
                                echo '<option value="' . esc_attr($l['language_code']) . '" ' . $selected . '>' . esc_html($l['translated_name']) . '</option>';
                            }
                            echo '</select>';
                        }
                        ?>
                    </div>
                </div>

                <div id="taxonomies-section" class="bte-section" style="display:none;">
                    <h2><?php _e('Select Taxonomies & Terms', 'bulk-taxonomy-editor'); ?></h2>
                    <div class="bte-field">
                        <label for="terms-search"><?php _e('Search Terms:', 'bulk-taxonomy-editor'); ?></label>
                        <input type="text" id="terms-search" placeholder="<?php _e('Search terms...', 'bulk-taxonomy-editor'); ?>" class="regular-text">
                    </div>
                    <div id="taxonomies-container" class="bte-checkbox-container"></div>
                </div>

                <div id="meta-fields-section" class="bte-section" style="display:none;">
                    <h2><?php _e('Other Meta Fields (JetEngine)', 'bulk-taxonomy-editor'); ?></h2>
                    <p class="description"><?php _e('Leave blank to keep current values. Fill a field to replace for all selected posts.', 'bulk-taxonomy-editor'); ?></p>
                    <div id="meta-fields-container"></div>
                </div>

                <div id="repeaters-section" class="bte-section" style="display:none;">
                    <h2><?php _e('JetEngine Repeater Fields', 'bulk-taxonomy-editor'); ?></h2>
                    <div id="repeaters-container"></div>
                </div>

                <div id="action-type-section" class="bte-section" style="display:none;">
                    <h2><?php _e('Action Type', 'bulk-taxonomy-editor'); ?></h2>
                    <div class="bte-field bte-radio-group">
                        <label><input type="radio" name="action_type" value="add" checked> <?php _e('Add (Keep current terms & append)', 'bulk-taxonomy-editor'); ?></label>
                        <label><input type="radio" name="action_type" value="replace"> <?php _e('Replace (Remove old terms & set new)', 'bulk-taxonomy-editor'); ?></label>
                        <label><input type="radio" name="action_type" value="remove"> <?php _e('Remove (Only remove selected terms)', 'bulk-taxonomy-editor'); ?></label>
                    </div>
                </div>

                <div id="posts-section" class="bte-section" style="display:none;">
                    <h2><?php _e('Select Posts', 'bulk-taxonomy-editor'); ?></h2>
                    <div class="bte-field">
                        <label for="posts-search"><?php _e('Search Posts:', 'bulk-taxonomy-editor'); ?></label>
                        <input type="text" id="posts-search" placeholder="<?php _e('Search posts...', 'bulk-taxonomy-editor'); ?>" class="regular-text">
                    </div>
                    
                    <div class="bte-field">
                        <label class="bte-checkbox-label">
                            <input type="checkbox" id="select-all-posts"> <?php _e('Select All on this page', 'bulk-taxonomy-editor'); ?>
                        </label>
                    </div>
                    <div id="posts-container" class="bte-checkbox-container"></div>
                    
                    <div id="posts-pagination" class="bte-pagination" style="display:none;">
                        <button type="button" class="button" id="prev-page"><?php _e('&laquo; Previous', 'bulk-taxonomy-editor'); ?></button>
                        <span id="page-info"></span>
                        <button type="button" class="button" id="next-page"><?php _e('Next &raquo;', 'bulk-taxonomy-editor'); ?></button>
                    </div>
                </div>

                <div id="actions-section" class="bte-actions" style="display:none;">
                    <button type="submit" class="button button-primary"><?php _e('Update Posts', 'bulk-taxonomy-editor'); ?></button>
                </div>

            </form>
        </div>

        <div class="bte-help-container">
            <h2><?php _e('How to Use', 'bulk-taxonomy-editor'); ?></h2>
            <ol>
                <li><?php _e('Select the post type you want to modify.', 'bulk-taxonomy-editor'); ?></li>
                <li><?php _e('Select the taxonomies and terms you want to edit (multiple taxonomies supported).', 'bulk-taxonomy-editor'); ?></li>
                <li><?php _e('Choose the action type (add, replace, or remove).', 'bulk-taxonomy-editor'); ?></li>
                <li><?php _e('Fill JetEngine repeater fields if needed (optional).', 'bulk-taxonomy-editor'); ?></li>
                <li><?php _e('Select the posts you want to update.', 'bulk-taxonomy-editor'); ?></li>
                <li><?php _e('Click the "Update Posts" button to apply changes.', 'bulk-taxonomy-editor'); ?></li>
            </ol>
        </div>
    </div>
</div>
