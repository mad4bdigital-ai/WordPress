<?php
/**
 * صفحة إعدادات API
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap bulk-taxonomy-editor-wrap">
    <h1><?php _e('Bulk Taxonomy Editor - API Settings', 'bulk-taxonomy-editor'); ?></h1>

    <div class="bte-section">
        <h2><?php _e('API Endpoint', 'bulk-taxonomy-editor'); ?></h2>
        <div class="bte-field">
            <?php
            $endpoint = rest_url('bulk-taxonomy-editor/v1/posts');
            ?>
            <label for="bte-api-endpoint"><?php _e('Endpoint URL:', 'bulk-taxonomy-editor'); ?></label>
            <input type="text" id="bte-api-endpoint" class="regular-text" value="<?php echo esc_url($endpoint); ?>" readonly>
            <p class="description"><?php _e('Use this URL with Application Passwords to create posts.', 'bulk-taxonomy-editor'); ?></p>
        </div>
    </div>

    <div class="bte-section">
        <h2><?php _e('API Endpoints Guide', 'bulk-taxonomy-editor'); ?></h2>
        <div class="bte-field">
            <p><strong>1. Create / Update Post:</strong> <code style="padding:4px; background:#eee;">POST <?php echo esc_url(rest_url('bulk-taxonomy-editor/v1/posts')); ?></code></p>
            <p><strong>2. List Posts:</strong> <code style="padding:4px; background:#eee;">GET <?php echo esc_url(rest_url('bulk-taxonomy-editor/v1/posts')); ?>?post_type=tour&per_page=20</code></p>
            <p><strong>3. Get Single Post Details:</strong> <code style="padding:4px; background:#eee;">GET <?php echo esc_url(rest_url('bulk-taxonomy-editor/v1/posts/123')); ?></code></p>
            <p><strong>4. List Taxonomies for Post Type:</strong> <code style="padding:4px; background:#eee;">GET <?php echo esc_url(rest_url('bulk-taxonomy-editor/v1/taxonomies')); ?>?post_type=tour</code></p>
            <p><strong>5. List Terms in a Taxonomy:</strong> <code style="padding:4px; background:#eee;">GET <?php echo esc_url(rest_url('bulk-taxonomy-editor/v1/terms')); ?>?taxonomy=category</code></p>
            
            <p><strong>Authentication:</strong> Use WordPress Application Passwords (Basic AuthHeader).</p>
            <p><strong>Parameters for POST (JSON Payload format):</strong></p>
            <pre style="background: #f1f1f1; padding: 15px; border-left: 4px solid #0073aa; border-radius: 4px; overflow: auto; max-width: 800px; box-sizing: border-box; display: block;">
{
  "post_type": "tour",           // Required (must be allowed in settings below)
  "post_title": "My New Tour",   // Required
  "post_status": "publish",      // Optional (publish, draft, pending)
  "post_content": "Description", // Optional
  "taxonomies": {
    "category": [10, 15],        // Term IDs
    "post_tag": ["Adventure"]    // Or Term Names
  },
  "meta_data": {
    "tour_mode": "private",      // Simple JetEngine Field Name -> Value
    "is_public": "yes"
  },
  "repeater_data": {             // JetEngine Repeaters Support
    "itinerary_days": [
      {
        "day_number": "1",
        "day_desc": "Arrival"
      },
      {
        "day_number": "2",
        "day_desc": "Pyramids"
      }
    ]
  }
}
            </pre>
        </div>
    </div>

    <form method="post" action="">
        <?php wp_nonce_field('bte_save_settings', 'bte_settings_nonce'); ?>

        <div class="bte-section">
            <h2><?php _e('API Access', 'bulk-taxonomy-editor'); ?></h2>
            <div class="bte-field">
                <label>
                    <input type="checkbox" name="bte_api_enabled" value="1" <?php checked(1, $enabled); ?>>
                    <?php _e('Enable API endpoint', 'bulk-taxonomy-editor'); ?>
                </label>
                <p class="description"><?php _e('Controls whether the custom REST API endpoint is active.', 'bulk-taxonomy-editor'); ?></p>
            </div>
        </div>

        <div class="bte-section">
            <h2><?php _e('Allowed Roles', 'bulk-taxonomy-editor'); ?></h2>
            <div class="bte-field">
                <?php foreach ($roles as $role_key => $role_data): ?>
                <label class="bte-checkbox-label">
                    <input type="checkbox" name="bte_allowed_roles[]" value="<?php echo esc_attr($role_key); ?>" <?php checked(in_array($role_key, $allowed_roles, true)); ?>>
                    <?php echo esc_html($role_data['name']); ?>
                </label>
                <?php endforeach; ?>
                <p class="description"><?php _e('Users must have one of these roles to use the API.', 'bulk-taxonomy-editor'); ?></p>
            </div>
        </div>

        <div class="bte-section">
            <h2><?php _e('Allowed Post Types', 'bulk-taxonomy-editor'); ?></h2>
            <div class="bte-field">
                <?php foreach ($post_types as $post_type): ?>
                <label class="bte-checkbox-label">
                    <input type="checkbox" name="bte_allowed_post_types[]" value="<?php echo esc_attr($post_type->name); ?>" <?php checked(in_array($post_type->name, $allowed_post_types, true)); ?>>
                    <?php echo esc_html($post_type->labels->name); ?>
                </label>
                <?php endforeach; ?>
                <p class="description"><?php _e('Limit which post types can be created via API. Leave empty to allow all.', 'bulk-taxonomy-editor'); ?></p>
            </div>
        </div>

        <p>
            <button type="submit" class="button button-primary"><?php _e('Save Settings', 'bulk-taxonomy-editor'); ?></button>
        </p>
    </form>
</div>

