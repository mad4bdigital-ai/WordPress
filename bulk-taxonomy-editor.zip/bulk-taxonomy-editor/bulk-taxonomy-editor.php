<?php
/**
 * Plugin Name: Bulk Content & Taxonomy Manager
 * Plugin URI: https://example.com/bulk-taxonomy-editor
 * Description: إدارة جماعية للتصنيفات وحقول JetEngine (بما فيها Repeater) مع API لإنشاء البوستات
 * Version: 1.1.0
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL v2 or later
 * Text Domain: bulk-taxonomy-editor
 * Domain Path: /languages
 */

// منع الوصول المباشر للملف
if (!defined('ABSPATH')) {
    exit;
}

// تمرير Authorization header إذا كان السيرفر يحجبه (لـ Application Passwords)
add_action('init', function() {
    if (isset($_SERVER['PHP_AUTH_USER'])) {
        return;
    }

    $header = '';
    if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $header = $_SERVER['HTTP_AUTHORIZATION'];
    } elseif (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
        $header = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
    } elseif (isset($_SERVER['AUTHORIZATION'])) {
        $header = $_SERVER['AUTHORIZATION'];
    }

    if (!$header && function_exists('getallheaders')) {
        $headers = getallheaders();
        if (isset($headers['Authorization'])) {
            $header = $headers['Authorization'];
        }
    }

    if ($header && stripos($header, 'basic ') === 0) {
        $data = substr($header, 6);
        $decoded = base64_decode($data);
        if ($decoded && strpos($decoded, ':') !== false) {
            list($user, $pass) = explode(':', $decoded, 2);
            $_SERVER['PHP_AUTH_USER'] = $user;
            $_SERVER['PHP_AUTH_PW'] = $pass;
        }
    }
});

class Bulk_Taxonomy_Editor {

    // مثيل واحد من الكلاس (Singleton)
    private static $instance = null;

    // الحصول على المثيل الوحيد من الكلاس
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    // المنشئ
    private function __construct() {
        // إضافة قائمة في لوحة التحكم
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_menu', array($this, 'add_settings_submenu'));

        // تحميل الأنماط والسكربتات
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));

        // معالجة طلبات التعديل الجماعي
        add_action('admin_post_bulk_taxonomy_editor_update', array($this, 'handle_bulk_update'));
    }

    // إضافة قائمة في لوحة التحكم
    public function add_admin_menu() {
        add_menu_page(
            __('Bulk Taxonomy Editor', 'bulk-taxonomy-editor'),
            __('Bulk Taxonomy Editor', 'bulk-taxonomy-editor'),
            'manage_options',
            'bulk-taxonomy-editor',
            array($this, 'render_admin_page'),
            'dashicons-edit',
            30
        );
    }

    public function add_settings_submenu() {
        add_submenu_page(
            'bulk-taxonomy-editor',
            __('BTE Settings', 'bulk-taxonomy-editor'),
            __('Settings', 'bulk-taxonomy-editor'),
            'manage_options',
            'bulk-taxonomy-editor-settings',
            array($this, 'render_settings_page')
        );
    }

    // تحميل الأنماط والسكربتات
    public function enqueue_scripts($hook) {
        // تحميل السكربتات فقط في صفحة الإضافة
        if ('toplevel_page_bulk-taxonomy-editor' !== $hook) {
            return;
        }

        // تحميل jQuery (محمّل بالفعل في ووردبريس)

        // تحميل أنماط CSS للإضافة
        wp_enqueue_style(
            'bulk-taxonomy-editor-style',
            plugins_url('assets/css/style.css', __FILE__),
            array(),
            '1.1.0'
        );

        // تحميل سكربت JavaScript للإضافة
        wp_enqueue_script(
            'bulk-taxonomy-editor-script',
            plugins_url('assets/js/script.js', __FILE__),
            array('jquery'),
            time(),
            true
        );

        // تمرير المتغيرات للسكربت
        wp_localize_script('bulk-taxonomy-editor-script', 'bte_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bulk_taxonomy_editor_nonce'),
            'strings' => array(
                'select_post_type' => __('Please select a post type', 'bulk-taxonomy-editor'),
                'select_taxonomy' => __('Please select a taxonomy', 'bulk-taxonomy-editor'),
                'select_terms' => __('Please select at least one term', 'bulk-taxonomy-editor'),
                'select_terms_or_repeaters' => __('Please select at least one term or enter repeater data.', 'bulk-taxonomy-editor'),
                'select_posts' => __('Please select at least one post', 'bulk-taxonomy-editor'),
                'confirm_update' => __('Are you sure you want to update the selected posts?', 'bulk-taxonomy-editor'),
                'success' => __('Posts updated successfully!', 'bulk-taxonomy-editor'),
                'error' => __('An error occurred. Please try again.', 'bulk-taxonomy-editor'),
                'select_taxonomy_option' => __('-- Select Taxonomy --', 'bulk-taxonomy-editor'),
                'no_taxonomies' => __('-- No taxonomies available --', 'bulk-taxonomy-editor'),
                'error_loading_taxonomies' => __('-- Error loading taxonomies --', 'bulk-taxonomy-editor'),
                'loading_taxonomies' => __('Loading taxonomies...', 'bulk-taxonomy-editor'),
                'loading_repeaters' => __('Loading repeater fields...', 'bulk-taxonomy-editor'),
                'loading_terms' => __('Loading terms...', 'bulk-taxonomy-editor'),
                'no_terms' => __('No terms available for this taxonomy.', 'bulk-taxonomy-editor'),
                'error_loading_terms' => __('Error loading terms.', 'bulk-taxonomy-editor'),
                'no_terms_found' => __('No terms found matching your search.', 'bulk-taxonomy-editor'),
                'loading_posts' => __('Loading posts...', 'bulk-taxonomy-editor'),
                'no_posts' => __('No posts found.', 'bulk-taxonomy-editor'),
                'error_loading_posts' => __('Error loading posts.', 'bulk-taxonomy-editor'),
                'no_meta_fields' => __('No meta fields found for this post type.', 'bulk-taxonomy-editor'),
                'error_loading_meta_fields' => __('Error loading meta fields.', 'bulk-taxonomy-editor'),
                'no_repeaters' => __('No repeater fields found for this post type.', 'bulk-taxonomy-editor'),
                'error_loading_repeaters' => __('Error loading repeater fields.', 'bulk-taxonomy-editor'),
                'add_row' => __('Add row', 'bulk-taxonomy-editor'),
                'remove_row' => __('Remove', 'bulk-taxonomy-editor'),
                'repeater_help' => __('Fill rows below. This will be applied to all selected posts for this repeater field.', 'bulk-taxonomy-editor'),
                'page' => __('Page', 'bulk-taxonomy-editor'),
                'of' => __('of', 'bulk-taxonomy-editor'),
            )
        ));
    }

    // معالجة طلبات التعديل الجماعي
    public function handle_bulk_update() {
        // التحقق من الصلاحيات
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to perform this action.', 'bulk-taxonomy-editor'));
        }

        // التحقق من nonce
        check_admin_referer('bulk_taxonomy_editor_nonce', 'bulk_taxonomy_editor_nonce_field');

        // الحصول على البيانات من النموذج
        $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : '';
        $taxonomy_target = isset($_POST['taxonomy_target']) ? sanitize_text_field($_POST['taxonomy_target']) : '';
        $terms_input = isset($_POST['terms']) && is_array($_POST['terms']) ? $_POST['terms'] : array();
        $repeater_input = isset($_POST['repeater_data']) && is_array($_POST['repeater_data']) ? $_POST['repeater_data'] : array();
        $meta_data_input = isset($_POST['meta_data']) && is_array($_POST['meta_data']) ? wp_unslash($_POST['meta_data']) : array();
        $posts = isset($_POST['posts']) ? array_map('intval', $_POST['posts']) : array();
        $action_type = isset($_POST['action_type']) ? sanitize_text_field($_POST['action_type']) : 'add';
        $object_type = isset($_POST['object_type']) ? sanitize_text_field($_POST['object_type']) : 'post';

        if ($object_type === 'term') {
            $post_type = $taxonomy_target;
        }

        // التحقق من البيانات
        if (empty($post_type) || empty($posts)) {
            wp_redirect(add_query_arg(array(
                'page' => 'bulk-taxonomy-editor',
                'message' => 'error',
                'text' => urlencode(__('Missing required fields.', 'bulk-taxonomy-editor'))
            ), admin_url('admin.php')));
            exit;
        }

        // تجهيز التصنيفات والمصطلحات المحددة
        $tax_terms_map = array();
        foreach ($terms_input as $tax_key => $tax_terms) {
            $tax_key = sanitize_text_field($tax_key);
            if (!is_array($tax_terms)) {
                continue;
            }
            $tax_terms = array_map('intval', $tax_terms);
            $tax_terms = array_values(array_filter($tax_terms));
            if (!empty($tax_terms)) {
                $tax_terms_map[$tax_key] = $tax_terms;
            }
        }

        // تجهيز بيانات الريبيتر
        $repeater_map = array();
        foreach ($repeater_input as $field_key => $json) {
            $field_key = sanitize_text_field($field_key);
            if (!is_string($json)) {
                continue;
            }
            $json = trim(wp_unslash($json));
            if ($json === '') {
                continue;
            }

            $decoded = json_decode($json, true);
            if (!is_array($decoded)) {
                wp_redirect(add_query_arg(array(
                    'page' => 'bulk-taxonomy-editor',
                    'message' => 'error',
                    'text' => urlencode(__('Invalid JSON for repeater fields.', 'bulk-taxonomy-editor'))
                ), admin_url('admin.php')));
                exit;
            }

            // تأكد أن كل صف عبارة عن مصفوفة
            $rows = array();
            foreach ($decoded as $row) {
                if (is_array($row)) {
                    $rows[] = $row;
                }
            }

            if (!empty($rows)) {
                $repeater_map[$field_key] = $rows;
            }
        }

        if (empty($tax_terms_map) && empty($repeater_map) && empty(array_filter($meta_data_input))) {
            wp_redirect(add_query_arg(array(
                'page' => 'bulk-taxonomy-editor',
                'message' => 'error',
                'text' => urlencode(__('Please select at least one term, enter repeater data, or provide a meta value.', 'bulk-taxonomy-editor'))
            ), admin_url('admin.php')));
            exit;
        }

        if ($object_type === 'post') {
            $post_type_taxonomies = get_object_taxonomies($post_type);
            foreach ($tax_terms_map as $taxonomy => $terms) {
                if (!taxonomy_exists($taxonomy) || !in_array($taxonomy, $post_type_taxonomies, true)) {
                    wp_redirect(add_query_arg(array(
                        'page' => 'bulk-taxonomy-editor',
                        'message' => 'error',
                        'text' => urlencode(__('Invalid taxonomy for selected post type.', 'bulk-taxonomy-editor'))
                    ), admin_url('admin.php')));
                    exit;
                }
            }
        }

        // تنفيذ العملية على كل البوستات المحددة
        $success_count = 0;
        $error_count = 0;

        foreach ($posts as $object_id) {
            $object_had_error = false;

            if ($object_type === 'post') {
                $post = get_post($object_id);
                if (!$post || $post->post_type !== $post_type) {
                    $error_count++;
                    continue;
                }

                foreach ($tax_terms_map as $taxonomy => $terms) {
                    if ($action_type === 'add') {
                        $result = wp_set_object_terms($object_id, $terms, $taxonomy, true);
                    } elseif ($action_type === 'replace') {
                        $result = wp_set_object_terms($object_id, $terms, $taxonomy, false);
                    } elseif ($action_type === 'remove') {
                        $current_terms = wp_get_object_terms($object_id, $taxonomy, array('fields' => 'ids'));
                        $new_terms = array_diff($current_terms, $terms);
                        $result = wp_set_object_terms($object_id, $new_terms, $taxonomy, false);
                    } else {
                        $result = new WP_Error('invalid_action', __('Invalid action type.', 'bulk-taxonomy-editor'));
                    }

                    if (is_wp_error($result)) {
                        $object_had_error = true;
                    }
                }
            } else {
                $term = get_term($object_id);
                if (!$term || is_wp_error($term)) {
                    $error_count++;
                    continue;
                }
            }

            foreach ($meta_data_input as $meta_key => $meta_val) {
                if (trim($meta_val) !== '') {
                    $meta_key = sanitize_text_field($meta_key);
                    $meta_val = wp_unslash($meta_val);
                    if ($object_type === 'post') {
                        $updated = update_post_meta($object_id, $meta_key, $meta_val);
                        if ($updated === false && get_post_meta($object_id, $meta_key, true) !== $meta_val) {
                            $object_had_error = true;
                        }
                    } else {
                        $updated = update_term_meta($object_id, $meta_key, $meta_val);
                        if ($updated === false && get_term_meta($object_id, $meta_key, true) !== $meta_val) {
                            $object_had_error = true;
                        }
                    }
                }
            }

            foreach ($repeater_map as $field_key => $rows) {
                $current = ($object_type === 'post') ? get_post_meta($object_id, $field_key, true) : get_term_meta($object_id, $field_key, true);
                if (!is_array($current)) {
                    $current = array();
                }

                if ($action_type === 'add') {
                    $new_value = array_merge($current, $rows);
                } elseif ($action_type === 'replace') {
                    $new_value = $rows;
                } elseif ($action_type === 'remove') {
                    $remove_map = array();
                    foreach ($rows as $row) {
                        $remove_map[wp_json_encode($row)] = true;
                    }

                    $new_value = array();
                    foreach ($current as $row) {
                        $key = wp_json_encode($row);
                        if (!isset($remove_map[$key])) {
                            $new_value[] = $row;
                        }
                    }
                } else {
                    $object_had_error = true;
                    continue;
                }

                $updated = ($object_type === 'post') ? update_post_meta($object_id, $field_key, $new_value) : update_term_meta($object_id, $field_key, $new_value);
                if ($updated === false) {
                    $object_had_error = true;
                }
            }

            if ($object_had_error) {
                $error_count++;
            } else {
                $success_count++;
            }
        }

        // إعادة التوجيه مع رسالة النتيجة
        if ($error_count === 0) {
            wp_redirect(add_query_arg(array(
                'page' => 'bulk-taxonomy-editor',
                'message' => 'success',
                'text' => urlencode(sprintf(__('%d posts updated successfully!', 'bulk-taxonomy-editor'), $success_count))
            ), admin_url('admin.php')));
        } else {
            wp_redirect(add_query_arg(array(
                'page' => 'bulk-taxonomy-editor',
                'message' => 'warning',
                'text' => urlencode(sprintf(__('%d posts updated, %d failed.', 'bulk-taxonomy-editor'), $success_count, $error_count))
            ), admin_url('admin.php')));
        }
        exit;
    }

    // عرض صفحة الإدارة
    public function render_admin_page() {
        // الحصول على جميع أنواع البوستات العامة
        $post_types = get_post_types(array('public' => true), 'objects');

        // الحصول على رسائل النتائج إن وجدت
        $message = isset($_GET['message']) ? sanitize_text_field($_GET['message']) : '';
        $message_text = isset($_GET['text']) ? sanitize_text_field($_GET['text']) : '';

        // عرض الصفحة
        include plugin_dir_path(__FILE__) . 'templates/admin-page.php';
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'bulk-taxonomy-editor'));
        }

        if (isset($_POST['bte_settings_nonce']) && wp_verify_nonce($_POST['bte_settings_nonce'], 'bte_save_settings')) {
            $enabled = isset($_POST['bte_api_enabled']) ? 1 : 0;
            $allowed_roles = isset($_POST['bte_allowed_roles']) ? array_map('sanitize_text_field', (array) $_POST['bte_allowed_roles']) : array();
            $allowed_post_types = isset($_POST['bte_allowed_post_types']) ? array_map('sanitize_text_field', (array) $_POST['bte_allowed_post_types']) : array();

            update_option('bte_api_enabled', $enabled);
            update_option('bte_api_allowed_roles', $allowed_roles);
            update_option('bte_api_allowed_post_types', $allowed_post_types);

            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Settings saved.', 'bulk-taxonomy-editor') . '</p></div>';
        }

        $enabled = (int) get_option('bte_api_enabled', 1);
        $allowed_roles = (array) get_option('bte_api_allowed_roles', array('administrator', 'editor'));
        $allowed_post_types = (array) get_option('bte_api_allowed_post_types', array());
        $roles = wp_roles()->roles;
        $post_types = get_post_types(array('public' => true), 'objects');

        include plugin_dir_path(__FILE__) . 'templates/settings-page.php';
    }

    // الحصول على التصنيفات المتاحة لنوع بوست معين
    public static function get_taxonomies_for_post_type($post_type) {
        $taxonomies = get_object_taxonomies($post_type, 'objects');
        $result = array();

        foreach ($taxonomies as $taxonomy) {
            if ($taxonomy->public || $taxonomy->publicly_queryable) {
                $result[$taxonomy->name] = $taxonomy->labels->name;
            }
        }

        return $result;
    }

    // الحصول على البوستات لنوع بوست معين
    public static function get_posts_for_post_type($post_type, $search = '', $paged = 1, $posts_per_page = 20) {
        $args = array(
            'post_type' => $post_type,
            'post_status' => 'any',
            'posts_per_page' => $posts_per_page,
            'paged' => max(1, intval($paged)),
            'orderby' => 'title',
            'order' => 'ASC',
        );

        if (!empty($search)) {
            $args['s'] = $search;
        }

        $query = new WP_Query($args);

        // حساب إجمالي العناصر بشكل ثابت باستخدام found_posts في Query صغير
        $count_args = $args;
        $count_args['fields'] = 'ids';
        $count_args['posts_per_page'] = 1;
        $count_args['paged'] = 1;
        $count_args['no_found_rows'] = false;
        $count_args['suppress_filters'] = false;
        $count_query = new WP_Query($count_args);
        $total = isset($count_query->found_posts) ? intval($count_query->found_posts) : 0;
        $pages = $total > 0 ? ceil($total / max(1, intval($posts_per_page))) : 1;

        return array(
            'posts' => $query->posts,
            'total' => $total,
            'pages' => $pages,
        );
    }

    // الحصول على المصطلحات (terms) لتصنيف معين
    public static function get_terms_for_taxonomy($taxonomy, $search = '') {
        $args = array(
            'taxonomy' => $taxonomy,
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC',
        );

        if (!empty($search)) {
            $args['search'] = $search;
        }

        return get_terms($args);
    }
}

// الحصول على حقول Repeater من JetEngine لنوع بوست معين أو تصنيف
function bte_get_jet_repeater_fields_for_post_type($post_type, $object_type = 'post') {
    if (!function_exists('jet_engine')) {
        return array();
    }

    $jet = jet_engine();
    $repeaters = array();

    $meta_boxes = array();
    if (isset($jet->meta_boxes) && method_exists($jet->meta_boxes, 'get_meta_boxes')) {
        $fetched = $jet->meta_boxes->get_meta_boxes();
        if (is_array($fetched)) {
            $meta_boxes = $fetched;
        }
    }

    // 1. Direct DB Fetch for Taxonomy Built-in Fields
    if ($object_type === 'term') {
        // From Options (Older/Alternative JetEngine storage)
        $jet_tax_option = get_option('jet_engine_taxonomies');
        if (is_array($jet_tax_option)) {
            foreach ($jet_tax_option as $tax) {
                $meta_fields = isset($tax['meta_fields']) ? $tax['meta_fields'] : array();
                if (!empty($meta_fields)) {
                    $meta_boxes[] = array(
                        'args' => array('object_type' => 'taxonomy', 'allowed_tax' => array($post_type), 'title' => 'Taxonomy Built-in Fields (Option)'),
                        'meta_fields' => $meta_fields
                    );
                }
            }
        }
        // From CPT (Modern JetEngine storage)
        $tax_posts = get_posts(array('post_type' => 'jet-engine-tax', 'posts_per_page' => -1, 'post_status' => 'any', 'suppress_filters' => true));
        foreach ($tax_posts as $tax_post) {
            $all_meta = get_post_meta($tax_post->ID);
            foreach ($all_meta as $key => $val) {
                $unserialized = maybe_unserialize($val[0]);
                if (is_array($unserialized)) {
                    if (isset($unserialized['meta_fields']) && is_array($unserialized['meta_fields'])) {
                        $meta_boxes[] = array(
                            'args' => array('object_type' => 'taxonomy', 'allowed_tax' => array($post_type), 'title' => 'Taxonomy Built-in Fields (CPT)'),
                            'meta_fields' => $unserialized['meta_fields']
                        );
                    } elseif (isset($unserialized[0]) && is_array($unserialized[0]) && isset($unserialized[0]['name'])) {
                        $meta_boxes[] = array(
                            'args' => array('object_type' => 'taxonomy', 'allowed_tax' => array($post_type), 'title' => 'Taxonomy Built-in Fields (CPT Raw)'),
                            'meta_fields' => $unserialized
                        );
                    }
                }
            }
        }
    }

    // Direct DB Fetch for JetEngine Custom Meta Boxes
    $meta_posts = get_posts(array('post_type' => 'jet-engine-meta', 'posts_per_page' => -1, 'post_status' => 'any', 'suppress_filters' => true));
    foreach ($meta_posts as $meta_post) {
        $all_meta = get_post_meta($meta_post->ID);
        foreach ($all_meta as $key => $val) {
            $unserialized = maybe_unserialize($val[0]);
            if (is_array($unserialized)) {
                if (isset($unserialized['meta_fields']) && is_array($unserialized['meta_fields'])) {
                    $meta_boxes[] = array(
                        'args' => array('object_type' => 'taxonomy'),
                        'meta_fields' => $unserialized['meta_fields']
                    );
                } elseif (isset($unserialized[0]) && is_array($unserialized[0]) && isset($unserialized[0]['name'])) {
                    $meta_boxes[] = array(
                        'args' => array('object_type' => 'taxonomy'),
                        'meta_fields' => $unserialized
                    );
                }
            }
        }
    }

    // 2. Direct DB Fetch for Post Type Built-in Fields
    if ($object_type !== 'term') {
        // From Options
        $jet_cpt_option = get_option('jet_engine_cpt');
        if (is_array($jet_cpt_option)) {
            foreach ($jet_cpt_option as $cpt) {
                $meta_fields = isset($cpt['meta_fields']) ? $cpt['meta_fields'] : array();
                if (!empty($meta_fields)) {
                    $meta_boxes[] = array(
                        'args' => array('object_type' => 'post', 'post_type' => array($post_type), 'title' => 'CPT Built-in Fields (Option)'),
                        'meta_fields' => $meta_fields
                    );
                }
            }
        }
        // From CPT
        $cpt_posts = get_posts(array('post_type' => 'jet-engine', 'posts_per_page' => -1, 'post_status' => 'any', 'suppress_filters' => true));
        foreach ($cpt_posts as $cpt_post) {
            $meta_fields = get_post_meta($cpt_post->ID, '_meta_fields', true);
            if (!empty($meta_fields) && is_array($meta_fields)) {
                $meta_boxes[] = array(
                    'args' => array('object_type' => 'post', 'post_type' => array($post_type), 'title' => 'CPT Built-in Fields (CPT)'),
                    'meta_fields' => $meta_fields
                );
            }
        }
    }

    if (is_array($meta_boxes)) {
        foreach ($meta_boxes as $box) {
                $args = isset($box['args']) && is_array($box['args']) ? $box['args'] : $box;

                $box_type = 'post';
                if (isset($args['meta_box_source'])) {
                    $box_type = $args['meta_box_source'];
                } elseif (isset($args['object_type'])) {
                    $box_type = $args['object_type'];
                } elseif (isset($args['type'])) {
                    $box_type = $args['type'];
                }

                $allowed = array();
                if ($object_type === 'term') {
                    // JetEngine restricts taxonomy boxes in very unpredictable ways.
                    // Bypass all filtering to guarantee fields show up for terms.
                } else {
                    if (isset($args['allowed_post_type'])) $allowed = array_merge($allowed, (array) $args['allowed_post_type']);
                    if (isset($args['allowed_post_types'])) $allowed = array_merge($allowed, (array) $args['allowed_post_types']);
                    if (isset($args['post_type'])) $allowed = array_merge($allowed, (array) $args['post_type']);

                    if (empty($allowed) && !in_array($box_type, array('post', 'post_type'), true)) {
                        continue;
                    }
                    if (!empty($allowed) && !in_array($post_type, $allowed, true)) {
                        continue;
                    }
                }
                $fields = array();
                if (isset($box['meta_fields']) && is_array($box['meta_fields'])) {
                    $fields = $box['meta_fields'];
                } elseif (isset($args['meta_fields']) && is_array($args['meta_fields'])) {
                    $fields = $args['meta_fields'];
                } elseif (isset($box['fields']) && is_array($box['fields'])) {
                    $fields = $box['fields'];
                }

                foreach ($fields as $field) {
                    if (!is_array($field)) {
                        continue;
                    }
                    if (!isset($field['type']) || $field['type'] !== 'repeater') {
                        continue;
                    }

                    $key = '';
                    if (isset($field['name'])) {
                        $key = $field['name'];
                    } elseif (isset($field['id'])) {
                        $key = $field['id'];
                    }

                    if (empty($key)) {
                        continue;
                    }

                    $label = $key;
                    if (isset($field['title']) && $field['title'] !== '') {
                        $label = $field['title'];
                    } elseif (isset($field['label']) && $field['label'] !== '') {
                        $label = $field['label'];
                    }

                    $sub_fields = array();
                    if (isset($field['repeater-fields']) && is_array($field['repeater-fields'])) {
                        $sub_fields = $field['repeater-fields'];
                    } elseif (isset($field['repeater_fields']) && is_array($field['repeater_fields'])) {
                        $sub_fields = $field['repeater_fields'];
                    } elseif (isset($field['fields']) && is_array($field['fields'])) {
                        $sub_fields = $field['fields'];
                    }

                    $repeaters[$key] = array(
                        'label' => $label,
                        'fields' => bte_normalize_jet_fields($sub_fields),
                    );
                }
            }
        }

    // 2) CPT Meta Fields API (JetEngine)
    if (isset($jet->cpt) && method_exists($jet->cpt, 'get_items')) {
        $items = $jet->cpt->get_items();
        if (is_array($items)) {
            foreach ($items as $item) {
                if (!is_array($item)) {
                    continue;
                }
                if (!isset($item['slug']) || $item['slug'] !== $post_type) {
                    continue;
                }

                $fields = array();
                if (isset($item['meta_fields']) && is_array($item['meta_fields'])) {
                    $fields = $item['meta_fields'];
                }

                foreach ($fields as $field) {
                    if (!is_array($field)) {
                        continue;
                    }
                    if (!isset($field['type']) || $field['type'] !== 'repeater') {
                        continue;
                    }

                    $key = '';
                    if (isset($field['name'])) {
                        $key = $field['name'];
                    } elseif (isset($field['id'])) {
                        $key = $field['id'];
                    }

                    if (empty($key)) {
                        continue;
                    }

                    $label = $key;
                    if (isset($field['title']) && $field['title'] !== '') {
                        $label = $field['title'];
                    } elseif (isset($field['label']) && $field['label'] !== '') {
                        $label = $field['label'];
                    }

                    $sub_fields = array();
                    if (isset($field['repeater-fields']) && is_array($field['repeater-fields'])) {
                        $sub_fields = $field['repeater-fields'];
                    } elseif (isset($field['repeater_fields']) && is_array($field['repeater_fields'])) {
                        $sub_fields = $field['repeater_fields'];
                    } elseif (isset($field['fields']) && is_array($field['fields'])) {
                        $sub_fields = $field['fields'];
                    }

                    $repeaters[$key] = array(
                        'label' => $label,
                        'fields' => bte_normalize_jet_fields($sub_fields),
                    );
                }
            }
        }
    }

    // ULTRA FALLBACK: If nothing was found for terms, forcefully extract ALL repeaters from ALL Meta Boxes!
    if ($object_type === 'term' && empty($repeaters) && is_array($meta_boxes)) {
        foreach ($meta_boxes as $box) {
            $fields = array();
            if (isset($box['meta_fields']) && is_array($box['meta_fields'])) $fields = $box['meta_fields'];
            elseif (isset($box['args']['meta_fields']) && is_array($box['args']['meta_fields'])) $fields = $box['args']['meta_fields'];
            elseif (isset($box['fields']) && is_array($box['fields'])) $fields = $box['fields'];
            
            foreach ($fields as $field) {
                if (!is_array($field) || !isset($field['type']) || $field['type'] !== 'repeater') continue;
                
                $key = isset($field['name']) ? $field['name'] : (isset($field['id']) ? $field['id'] : '');
                if (empty($key)) continue;
                
                $label = $key;
                if (isset($field['title']) && $field['title'] !== '') $label = $field['title'];
                elseif (isset($field['label']) && $field['label'] !== '') $label = $field['label'];
                
                $sub_fields = array();
                if (isset($field['repeater-fields'])) $sub_fields = $field['repeater-fields'];
                elseif (isset($field['repeater_fields'])) $sub_fields = $field['repeater_fields'];
                elseif (isset($field['fields'])) $sub_fields = $field['fields'];
                
                $repeaters[$key] = array(
                    'label' => $label,
                    'fields' => bte_normalize_jet_fields($sub_fields)
                );
            }
        }
    }

    return $repeaters;
}

// الحصول على حقول JetEngine غير الريبيتر
function bte_get_jet_fields_for_post_type($post_type, $object_type = 'post') {
    if (!function_exists('jet_engine')) {
        return array();
    }

    $jet = jet_engine();
    $field_map = array();

    $meta_boxes = array();
    if (isset($jet->meta_boxes) && method_exists($jet->meta_boxes, 'get_meta_boxes')) {
        $fetched = $jet->meta_boxes->get_meta_boxes();
        if (is_array($fetched)) {
            $meta_boxes = $fetched;
        }
    }

    // 1. Direct DB Fetch for Taxonomy Built-in Fields
    if ($object_type === 'term') {
        // From Options (Older/Alternative JetEngine storage)
        $jet_tax_option = get_option('jet_engine_taxonomies');
        if (is_array($jet_tax_option)) {
            foreach ($jet_tax_option as $tax) {
                $meta_fields = isset($tax['meta_fields']) ? $tax['meta_fields'] : array();
                if (!empty($meta_fields)) {
                    $meta_boxes[] = array(
                        'args' => array('object_type' => 'taxonomy', 'allowed_tax' => array($post_type), 'title' => 'Taxonomy Built-in Fields (Option)'),
                        'meta_fields' => $meta_fields
                    );
                }
            }
        }
        // From CPT (Modern JetEngine storage)
        $tax_posts = get_posts(array('post_type' => 'jet-engine-tax', 'posts_per_page' => -1, 'post_status' => 'any', 'suppress_filters' => true));
        foreach ($tax_posts as $tax_post) {
            $all_meta = get_post_meta($tax_post->ID);
            foreach ($all_meta as $key => $val) {
                $unserialized = maybe_unserialize($val[0]);
                if (is_array($unserialized)) {
                    if (isset($unserialized['meta_fields']) && is_array($unserialized['meta_fields'])) {
                        $meta_boxes[] = array(
                            'args' => array('object_type' => 'taxonomy', 'allowed_tax' => array($post_type), 'title' => 'Taxonomy Built-in Fields (CPT)'),
                            'meta_fields' => $unserialized['meta_fields']
                        );
                    } elseif (isset($unserialized[0]) && is_array($unserialized[0]) && isset($unserialized[0]['name'])) {
                        $meta_boxes[] = array(
                            'args' => array('object_type' => 'taxonomy', 'allowed_tax' => array($post_type), 'title' => 'Taxonomy Built-in Fields (CPT Raw)'),
                            'meta_fields' => $unserialized
                        );
                    }
                }
            }
        }
    }

    // Direct DB Fetch for JetEngine Custom Meta Boxes
    $meta_posts = get_posts(array('post_type' => 'jet-engine-meta', 'posts_per_page' => -1, 'post_status' => 'any', 'suppress_filters' => true));
    foreach ($meta_posts as $meta_post) {
        // Just grab ALL meta for this post to hunt for fields!
        $all_meta = get_post_meta($meta_post->ID);
        foreach ($all_meta as $key => $val) {
            $unserialized = maybe_unserialize($val[0]);
            if (is_array($unserialized)) {
                // Look for 'meta_fields' anywhere inside
                if (isset($unserialized['meta_fields']) && is_array($unserialized['meta_fields'])) {
                    $meta_boxes[] = array(
                        'args' => array('object_type' => 'taxonomy'),
                        'meta_fields' => $unserialized['meta_fields']
                    );
                } elseif (isset($unserialized[0]) && is_array($unserialized[0]) && isset($unserialized[0]['name'])) {
                    // Direct array of fields
                    $meta_boxes[] = array(
                        'args' => array('object_type' => 'taxonomy'),
                        'meta_fields' => $unserialized
                    );
                }
            }
        }
    }

    // 2. Direct DB Fetch for Post Type Built-in Fields
    if ($object_type !== 'term') {
        // From Options
        $jet_cpt_option = get_option('jet_engine_cpt');
        if (is_array($jet_cpt_option)) {
            foreach ($jet_cpt_option as $cpt) {
                $meta_fields = isset($cpt['meta_fields']) ? $cpt['meta_fields'] : array();
                if (!empty($meta_fields)) {
                    $meta_boxes[] = array(
                        'args' => array('object_type' => 'post', 'post_type' => array($post_type), 'title' => 'CPT Built-in Fields (Option)'),
                        'meta_fields' => $meta_fields
                    );
                }
            }
        }
        // From CPT
        $cpt_posts = get_posts(array('post_type' => 'jet-engine', 'posts_per_page' => -1, 'post_status' => 'any', 'suppress_filters' => true));
        foreach ($cpt_posts as $cpt_post) {
            $meta_fields = get_post_meta($cpt_post->ID, '_meta_fields', true);
            if (!empty($meta_fields) && is_array($meta_fields)) {
                $meta_boxes[] = array(
                    'args' => array('object_type' => 'post', 'post_type' => array($post_type), 'title' => 'CPT Built-in Fields (CPT)'),
                    'meta_fields' => $meta_fields
                );
            }
        }
    }

    if (is_array($meta_boxes)) {
        foreach ($meta_boxes as $box) {
                $args = isset($box['args']) && is_array($box['args']) ? $box['args'] : $box;

                $box_type = 'post';
                if (isset($args['meta_box_source'])) {
                    $box_type = $args['meta_box_source'];
                } elseif (isset($args['object_type'])) {
                    $box_type = $args['object_type'];
                } elseif (isset($args['type'])) {
                    $box_type = $args['type'];
                }

                $allowed = array();
                if ($object_type === 'term') {
                    // JetEngine restricts taxonomy boxes in very unpredictable ways.
                    // Bypass all filtering to guarantee fields show up for terms.
                } else {
                    if (isset($args['allowed_post_type'])) $allowed = array_merge($allowed, (array) $args['allowed_post_type']);
                    if (isset($args['allowed_post_types'])) $allowed = array_merge($allowed, (array) $args['allowed_post_types']);
                    if (isset($args['post_type'])) $allowed = array_merge($allowed, (array) $args['post_type']);

                    if (empty($allowed) && !in_array($box_type, array('post', 'post_type'), true)) {
                        continue;
                    }
                    if (!empty($allowed) && !in_array($post_type, $allowed, true)) {
                        continue;
                    }
                }

                $fields = array();
                if (isset($box['meta_fields']) && is_array($box['meta_fields'])) {
                    $fields = $box['meta_fields'];
                } elseif (isset($args['meta_fields']) && is_array($args['meta_fields'])) {
                    $fields = $args['meta_fields'];
                } elseif (isset($box['fields']) && is_array($box['fields'])) {
                    $fields = $box['fields'];
                }

                $normalized = bte_normalize_jet_fields($fields);
                foreach ($normalized as $field) {
                    if (isset($field['type']) && $field['type'] === 'repeater') {
                        continue;
                    }
                    $name = isset($field['name']) ? $field['name'] : '';
                    if ($name === '') {
                        continue;
                    }
                    $field_map[$name] = $field;
                }
            }
        }

    // ULTRA FALLBACK: If nothing was found for terms, forcefully extract ALL fields from ALL Meta Boxes!
    if ($object_type === 'term' && empty($field_map) && is_array($meta_boxes)) {
        foreach ($meta_boxes as $box) {
            $fields = array();
            if (isset($box['meta_fields']) && is_array($box['meta_fields'])) $fields = $box['meta_fields'];
            elseif (isset($box['args']['meta_fields']) && is_array($box['args']['meta_fields'])) $fields = $box['args']['meta_fields'];
            elseif (isset($box['fields']) && is_array($box['fields'])) $fields = $box['fields'];
            
            $normalized = bte_normalize_jet_fields($fields);
            foreach ($normalized as $field) {
                if (isset($field['type']) && $field['type'] === 'repeater') continue;
                $name = isset($field['name']) ? $field['name'] : '';
                if ($name !== '') {
                    $field_map[$name] = $field;
                }
            }
        }
    }

    // 2) CPT Meta Fields API
    if (isset($jet->cpt) && method_exists($jet->cpt, 'get_items')) {
        $items = $jet->cpt->get_items();
        if (is_array($items)) {
            foreach ($items as $item) {
                if (!is_array($item)) {
                    continue;
                }
                if (!isset($item['slug']) || $item['slug'] !== $post_type) {
                    continue;
                }

                $fields = array();
                if (isset($item['meta_fields']) && is_array($item['meta_fields'])) {
                    $fields = $item['meta_fields'];
                }

                $normalized = bte_normalize_jet_fields($fields);
                foreach ($normalized as $field) {
                    if (isset($field['type']) && $field['type'] === 'repeater') {
                        continue;
                    }
                    $name = isset($field['name']) ? $field['name'] : '';
                    if ($name === '') {
                        continue;
                    }
                    $field_map[$name] = $field;
                }
            }
        }
    }

    // 3) ULTIMATE DIRECT DB GRAB FROM wp_termmeta!
    // If we're editing terms, literally scan wp_termmeta for ALL custom fields associated with terms of this taxonomy
    if ($object_type === 'term') {
        global $wpdb;
        $tax_name = sanitize_text_field($post_type);
        
        // Find existing meta keys in wp_termmeta for this specific taxonomy
        $query = $wpdb->prepare("
            SELECT DISTINCT tm.meta_key
            FROM {$wpdb->termmeta} tm
            INNER JOIN {$wpdb->term_taxonomy} tt ON tm.term_id = tt.term_id
            WHERE tt.taxonomy = %s
            AND tm.meta_key NOT LIKE '\_%'
        ", $tax_name);

        $db_keys = $wpdb->get_col($query);
        
        if (is_array($db_keys)) {
            foreach ($db_keys as $key) {
                if ($key === '') continue;
                
                // Exclude long garbage hash fields (usually coordinates caching from Maps plugins)
                if (preg_match('/^[a-f0-9]{32} /i', $key)) continue;

                // If it's already found by JetEngine structural definition, skip
                if (isset($field_map[$key])) continue;

                // Guess field type by pulling distinct values
                $val_query = $wpdb->prepare("
                    SELECT DISTINCT tm.meta_value
                    FROM {$wpdb->termmeta} tm
                    INNER JOIN {$wpdb->term_taxonomy} tt ON tm.term_id = tt.term_id
                    WHERE tt.taxonomy = %s
                    AND tm.meta_key = %s
                    AND tm.meta_value != ''
                    LIMIT 20
                ", $tax_name, $key);
                
                $distinct_vals = $wpdb->get_col($val_query);
                $type = 'text';
                $options = array();

                if (is_array($distinct_vals)) {
                    $distinct_count = count($distinct_vals);
                    // Check for boolean-like first
                    $lower_vals = array_map('strtolower', $distinct_vals);
                    $is_bool = true;
                    foreach ($lower_vals as $v) {
                        if (!in_array($v, array('1', '0', 'yes', 'no', 'true', 'false', 'on', 'off'), true)) {
                            $is_bool = false; break;
                        }
                    }

                    if ($is_bool && $distinct_count > 0 && $distinct_count <= 2) {
                        $type = 'select'; // Treat as select for safety
                        $options = array('1' => 'True (1)', '0' => 'False (0)', 'yes' => 'Yes', 'no' => 'No', 'true' => 'true', 'false' => 'false');
                    } elseif ($distinct_count > 1 && $distinct_count <= 15) {
                        // It's likely a predefined dropdown (select or radio)
                        $type = 'select';
                        foreach ($distinct_vals as $v) {
                            $options[$v] = $v;
                        }
                    }
                }

                // Add it synthetically
                $field_map[$key] = array(
                    'name' => $key,
                    'title' => ucfirst(str_replace('_', ' ', $key)) . ' (From DB)',
                    'type' => $type,
                    'options' => $options
                );
            }
        }
    }

    return array_values($field_map);
}

// قيمة مثال حسب نوع الحقل
function bte_example_value_for_field($field) {
    $type = isset($field['type']) ? $field['type'] : 'text';
    $options = isset($field['options']) && is_array($field['options']) ? $field['options'] : array();

    switch ($type) {
        case 'number':
        case 'integer':
            return 123;
        case 'checkbox':
        case 'switcher':
            return 1;
        case 'checkboxes':
            if (!empty($options)) {
                $first = array_key_first($options);
                return array($first);
            }
            return array();
        case 'radio':
        case 'select':
            if (!empty($options)) {
                return array_key_first($options);
            }
            return 'VALUE';
        case 'date':
            return '2026-01-01';
        case 'datetime':
            return '2026-01-01 10:00:00';
        case 'time':
            return '10:00';
        case 'media':
        case 'gallery':
            return 0;
        case 'textarea':
        case 'wysiwyg':
        case 'html':
            return 'Example text...';
        default:
            return 'VALUE';
    }
}

// وصف نوع الحقل بشكل بسيط (id/text/html/...)
function bte_field_type_label($field) {
    $type = isset($field['type']) ? $field['type'] : 'text';

    switch ($type) {
        case 'number':
        case 'integer':
            return 'number';
        case 'checkbox':
        case 'switcher':
            return 'boolean';
        case 'checkboxes':
            return 'array';
        case 'radio':
        case 'select':
            if (isset($field['options']) && is_array($field['options']) && !empty($field['options'])) {
                $keys = array();
                foreach ($field['options'] as $k => $v) {
                    $keys[] = is_array($v) && isset($v['key']) ? $v['key'] : $k;
                }
                return 'CHOOSE ONE: [' . implode(', ', $keys) . ']';
            }
            return 'select';
        case 'date':
            return 'date';
        case 'datetime':
            return 'datetime';
        case 'time':
            return 'time';
        case 'media':
        case 'gallery':
            return 'id';
        case 'textarea':
            return 'text';
        case 'wysiwyg':
        case 'html':
            return 'html';
        default:
            return 'text';
    }
}

// تطبيع حقول JetEngine لواجهة العرض
function bte_normalize_jet_fields($fields) {
    $result = array();
    if (!is_array($fields)) {
        return $result;
    }

    foreach ($fields as $field) {
        if (!is_array($field)) {
            continue;
        }

        $name = '';
        if (isset($field['name'])) {
            $name = $field['name'];
        } elseif (isset($field['id'])) {
            $name = $field['id'];
        }

        if ($name === '') {
            continue;
        }

        $label = $name;
        if (isset($field['title']) && $field['title'] !== '') {
            $label = $field['title'];
        } elseif (isset($field['label']) && $field['label'] !== '') {
            $label = $field['label'];
        }

        $type = isset($field['type']) ? $field['type'] : 'text';
        $options = array();
        if (isset($field['options']) && is_array($field['options'])) {
            $options = $field['options'];
        }

        // جلب خيارات القاموس إن وجدت
        if (isset($field['options_source']) && $field['options_source'] === 'glossary' && !empty($field['glossary_id'])) {
            $glossary_id = $field['glossary_id'];
            $glossary_fetched = false;

            if (function_exists('jet_engine') && isset(jet_engine()->glossaries)) {
                if (method_exists(jet_engine()->glossaries, 'get_glossary_for_field')) {
                    $glossary_options = jet_engine()->glossaries->get_glossary_for_field($glossary_id);
                    if (is_array($glossary_options) && !empty($glossary_options)) {
                        $options = $glossary_options;
                        $glossary_fetched = true;
                    }
                }
            }

            if (!$glossary_fetched) {
                $glossary_meta = get_option('jet_engine_glossaries', array());
                if (is_array($glossary_meta)) {
                    foreach ($glossary_meta as $gl) {
                        if (isset($gl['id']) && $gl['id'] == $glossary_id) {
                            if (isset($gl['fields']) && is_array($gl['fields'])) {
                                $options = $gl['fields'];
                            }
                            break;
                        }
                    }
                }
            }
        }

        $result[] = array(
            'name' => $name,
            'label' => $label,
            'type' => $type,
            'options' => $options,
        );
    }

    return $result;
}

// تهيئة الإضافة
function bulk_taxonomy_editor_init() {
    return Bulk_Taxonomy_Editor::get_instance();
}
add_action('plugins_loaded', 'bulk_taxonomy_editor_init');

// معالجة طلبات AJAX
add_action('wp_ajax_bte_get_taxonomies', 'bte_ajax_get_taxonomies');
add_action('wp_ajax_bte_get_posts', 'bte_ajax_get_posts');
add_action('wp_ajax_bte_get_terms', 'bte_ajax_get_terms');
add_action('wp_ajax_bte_get_repeaters', 'bte_ajax_get_repeaters');
add_action('wp_ajax_bte_get_api_example', 'bte_ajax_get_api_example');

// تسجيل REST API لإنشاء بوستات وقراءتها
add_action('rest_api_init', function() {
    // مسار لإنشاء أو تحديث البوستات
    register_rest_route('bulk-taxonomy-editor/v1', '/posts', array(
        'methods' => 'POST, PUT, PATCH',
        'callback' => 'bte_rest_create_post',
        'permission_callback' => function() {
            if (!get_option('bte_api_enabled', 1)) {
                return false;
            }

            if (!is_user_logged_in() || !current_user_can('edit_posts')) {
                return false;
            }

            $allowed_roles = (array) get_option('bte_api_allowed_roles', array('administrator', 'editor'));
            if (empty($allowed_roles)) {
                return false;
            }

            $user = wp_get_current_user();
            $has_role = false;
            foreach ($user->roles as $role) {
                if (in_array($role, $allowed_roles, true)) {
                    $has_role = true;
                    break;
                }
            }
            if (!$has_role) {
                return false;
            }

            return true;
        },
    ));

    register_rest_route('bulk-taxonomy-editor/v1', '/auth-check', array(
        'methods' => 'GET',
        'callback' => function() {
            return array(
                'has_php_auth_user' => isset($_SERVER['PHP_AUTH_USER']),
                'has_http_auth_header' => isset($_SERVER['HTTP_AUTHORIZATION']) || isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION']) || isset($_SERVER['AUTHORIZATION']),
                'is_user_logged_in' => is_user_logged_in(),
                'current_user_id' => get_current_user_id(),
            );
        },
        'permission_callback' => '__return_true',
    ));

    register_rest_route('bulk-taxonomy-editor/v1', '/posts/(?P<id>\d+)', array(
        'methods' => 'GET',
        'callback' => 'bte_rest_get_post',
        'permission_callback' => function() {
            if (!get_option('bte_api_enabled', 1)) return false;
            if (!is_user_logged_in() || !current_user_can('edit_posts')) return false;
            return true;
        },
    ));

    // مسار لجلب قائمة البوستات (List)
    register_rest_route('bulk-taxonomy-editor/v1', '/posts', array(
        'methods' => 'GET',
        'callback' => 'bte_rest_get_posts_list',
        'permission_callback' => function() {
            if (!get_option('bte_api_enabled', 1)) return false;
            if (!is_user_logged_in() || !current_user_can('edit_posts')) return false;
            return true;
        },
    ));
});

// دالة للحصول على التصنيفات عبر AJAX
function bte_ajax_get_taxonomies() {
    // التحقق من nonce
    check_ajax_referer('bulk_taxonomy_editor_nonce', 'nonce');

    // التحقق من الصلاحيات
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('You do not have sufficient permissions.', 'bulk-taxonomy-editor')));
    }

    $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : '';

    if (empty($post_type)) {
        wp_send_json_error(array('message' => __('Post type is required.', 'bulk-taxonomy-editor')));
    }

    $lang = isset($_POST['language']) ? sanitize_text_field($_POST['language']) : '';
    if ($lang !== '') {
        do_action('wpml_switch_language', $lang);
    }

    $taxonomies = Bulk_Taxonomy_Editor::get_taxonomies_for_post_type($post_type);

    wp_send_json_success(array('taxonomies' => $taxonomies));
}

// دالة للحصول على البوستات عبر AJAX
function bte_ajax_get_posts() {
    // التحقق من nonce
    check_ajax_referer('bulk_taxonomy_editor_nonce', 'nonce');

    // التحقق من الصلاحيات
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('You do not have sufficient permissions.', 'bulk-taxonomy-editor')));
    }

    $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : '';
    $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
    $paged = isset($_POST['paged']) ? intval($_POST['paged']) : 1;

    if (empty($post_type)) {
        wp_send_json_error(array('message' => __('Post type is required.', 'bulk-taxonomy-editor')));
    }

    $lang = isset($_POST['language']) ? sanitize_text_field($_POST['language']) : '';
    if ($lang !== '') {
        do_action('wpml_switch_language', $lang);
    }

    $object_type = isset($_POST['object_type']) ? sanitize_text_field($_POST['object_type']) : 'post';

    if ($object_type === 'term') {
        $per_page = 20;
        $base_args = array(
            'taxonomy' => $post_type,
            'hide_empty' => false,
            'search' => $search,
            'orderby' => 'term_id',
            'order' => 'ASC',
            'hierarchical' => false,
            'pad_counts' => false,
        );

        $terms = get_terms(array_merge($base_args, array(
            'number' => $per_page,
            'offset' => ($paged - 1) * $per_page,
        )));

        $count_args = array_merge($base_args, array(
            'fields' => 'ids',
        ));
        $total_ids = get_terms($count_args);
        $total = is_array($total_ids) ? count($total_ids) : 0;
        $pages = $total > 0 ? ceil($total / $per_page) : 1;

        $result = array('posts' => $terms, 'pages' => $pages);
    } else {
        $result = Bulk_Taxonomy_Editor::get_posts_for_post_type($post_type, $search, $paged);
    }

    wp_send_json_success($result);
}
add_action('wp_ajax_bte_get_posts', 'bte_ajax_get_posts');

// دالة لجلب كل الآيبديهات دفعة واحدة (تحديد الكل)
function bte_ajax_get_all_matching_ids() {
    check_ajax_referer('bulk_taxonomy_editor_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Permission denied.'));
    }

    $target = isset($_POST['target']) ? sanitize_text_field($_POST['target']) : '';
    $object_type = isset($_POST['object_type']) ? sanitize_text_field($_POST['object_type']) : 'post';
    $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
    $lang = isset($_POST['language']) ? sanitize_text_field($_POST['language']) : '';

    if (empty($target)) {
        wp_send_json_error(array('message' => 'Target is required.'));
    }

    if ($lang !== '') {
        do_action('wpml_switch_language', $lang);
    }

    $ids = array();
    if ($object_type === 'term') {
        $args = array(
            'taxonomy' => $target,
            'hide_empty' => false,
            'search' => $search,
            'fields' => 'ids'
        );
        $ids = get_terms($args);
    } else {
        $args = array(
            'post_type' => $target,
            'post_status' => 'any',
            'posts_per_page' => -1,
            's' => $search,
            'fields' => 'ids'
        );
        $ids = get_posts($args);
    }

    wp_send_json_success(array('ids' => $ids));


}
add_action('wp_ajax_bte_get_all_matching_ids', 'bte_ajax_get_all_matching_ids');

// دالة للحصول على المصطلحات عبر AJAX
function bte_ajax_get_terms() {
    // التحقق من nonce
    check_ajax_referer('bulk_taxonomy_editor_nonce', 'nonce');

    // التحقق من الصلاحيات
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('You do not have sufficient permissions.', 'bulk-taxonomy-editor')));
    }

    $taxonomy = isset($_POST['taxonomy']) ? sanitize_text_field($_POST['taxonomy']) : '';
    $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';

    if (empty($taxonomy)) {
        wp_send_json_error(array('message' => __('Taxonomy is required.', 'bulk-taxonomy-editor')));
    }

    $lang = isset($_POST['language']) ? sanitize_text_field($_POST['language']) : '';
    if ($lang !== '') {
        do_action('wpml_switch_language', $lang);
    }

    $terms = Bulk_Taxonomy_Editor::get_terms_for_taxonomy($taxonomy, $search);

    wp_send_json_success(array('terms' => $terms));
}

// دالة للحصول على حقول الميتا العادية عبر AJAX
function bte_ajax_get_meta_fields() {
    check_ajax_referer('bulk_taxonomy_editor_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permission denied');
    }
    
    $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : '';
    if (empty($post_type)) {
        wp_send_json_error('Missing post type');
    }
    
    $lang = isset($_POST['language']) ? sanitize_text_field($_POST['language']) : '';
    if ($lang !== '') {
        do_action('wpml_switch_language', $lang);
    }

    $object_type = isset($_POST['object_type']) ? sanitize_text_field($_POST['object_type']) : 'post';
    $fields = bte_get_jet_fields_for_post_type($post_type, $object_type);
    wp_send_json_success(array('fields' => $fields));
}
add_action('wp_ajax_bte_get_meta_fields', 'bte_ajax_get_meta_fields');

// دالة للحصول على حقول Repeater عبر AJAX
function bte_ajax_get_repeaters() {
    // التحقق من nonce
    check_ajax_referer('bulk_taxonomy_editor_nonce', 'nonce');

    // التحقق من الصلاحيات
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('You do not have sufficient permissions.', 'bulk-taxonomy-editor')));
    }

    $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : '';

    if (empty($post_type)) {
        wp_send_json_error(array('message' => __('Post type is required.', 'bulk-taxonomy-editor')));
    }

    $lang = isset($_POST['language']) ? sanitize_text_field($_POST['language']) : '';
    if ($lang !== '') {
        do_action('wpml_switch_language', $lang);
    }

    $object_type = isset($_POST['object_type']) ? sanitize_text_field($_POST['object_type']) : 'post';
    $repeaters = bte_get_jet_repeater_fields_for_post_type($post_type, $object_type);

    wp_send_json_success(array('repeaters' => $repeaters));
}

// مثال بيانات API حسب نوع البوست
function bte_ajax_get_api_example() {
    check_ajax_referer('bulk_taxonomy_editor_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('You do not have sufficient permissions.', 'bulk-taxonomy-editor')));
    }

    $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : '';
    if ($post_type === '' || !post_type_exists($post_type)) {
        wp_send_json_error(array('message' => __('Invalid post type.', 'bulk-taxonomy-editor')));
    }

    $example = bte_build_api_example_payload($post_type);
    wp_send_json_success(array('example' => $example));
}

// بناء مثال للـ API حسب نوع البوست
function bte_build_api_example_payload($post_type) {
    $payload = array(
        'post_type' => $post_type,
        'title' => 'Example Title',
        'content' => 'Example content...',
        'excerpt' => 'Example excerpt...',
        'status' => 'draft',
    );

    // Taxonomies (IDs)
    $tax_input = array();
    $taxonomies = get_object_taxonomies($post_type, 'objects');
    foreach ($taxonomies as $taxonomy) {
        if (!$taxonomy->public && !$taxonomy->publicly_queryable) {
            continue;
        }
        $tax_input[$taxonomy->name] = array('id');
    }
    if (!empty($tax_input)) {
        $payload['tax_input'] = $tax_input;
    }

    // JetEngine fields schema (types)
    $meta_schema = array();

    // Repeater fields schema
    $repeaters = bte_get_jet_repeater_fields_for_post_type($post_type);
    if (!empty($repeaters)) {
        foreach ($repeaters as $key => $data) {
            $row = array();
            if (isset($data['fields']) && is_array($data['fields'])) {
                foreach ($data['fields'] as $field) {
                    $field_name = isset($field['name']) ? $field['name'] : '';
                    if ($field_name === '') {
                        continue;
                    }
                    $row[$field_name] = bte_field_type_label($field);
                }
            }
            $meta_schema[$key] = array($row);
        }
    }

    // Non-repeater fields schema
    $fields = bte_get_jet_fields_for_post_type($post_type);
    if (!empty($fields)) {
        foreach ($fields as $field) {
            $name = isset($field['name']) ? $field['name'] : '';
            if ($name === '') {
                continue;
            }
            if (isset($meta_schema[$name])) {
                continue;
            }
            $meta_schema[$name] = bte_field_type_label($field);
        }
    }

    // إضافة مفتاح Rank Math كمثال
    $meta_schema['rank_math_focus_keyword'] = 'text';

    if (!empty($meta_schema)) {
        $payload['meta'] = $meta_schema;
    }

    return $payload;
}

// مساعدة لرفع الصور من روابط
function bte_sideload_image($url, $post_id = 0) {
    if (is_numeric($url)) return intval($url);
    if (filter_var($url, FILTER_VALIDATE_URL) === false) return $url;
    
    $ext = strtolower(pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION));
    if (!in_array($ext, array('jpg', 'jpeg', 'png', 'gif', 'webp'))) return $url;

    if (!function_exists('media_sideload_image')) {
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
    }

    $id = media_sideload_image($url, $post_id, '', 'id');
    return is_wp_error($id) ? $url : $id;
}

// فحص الميتا المصفوفات للصور
function bte_process_meta_images(&$value, $post_id) {
    if (is_array($value)) {
        foreach ($value as $k => &$v) {
            bte_process_meta_images($v, $post_id);
        }
    } elseif (is_string($value) && filter_var($value, FILTER_VALIDATE_URL)) {
        $value = bte_sideload_image($value, $post_id);
    }
}

// قراءة قائمة بوستات (List)
function bte_rest_get_posts_list($request) {
    $post_type = isset($request['post_type']) ? sanitize_text_field($request['post_type']) : 'tours-and-activities';
    $per_page = isset($request['per_page']) ? intval($request['per_page']) : 20;

    $args = array(
        'post_type' => $post_type,
        'post_status' => 'any',
        'posts_per_page' => $per_page,
        'orderby' => 'ID',
        'order' => 'DESC'
    );

    $query = new WP_Query($args);
    $results = array();
    foreach ($query->posts as $p) {
        $results[] = array(
            'id' => $p->ID,
            'title' => $p->post_title,
            'status' => $p->post_status
        );
    }
    return array('success' => true, 'total' => $query->found_posts, 'data' => $results);
}

// قراءة بوست بصيغة الـ JSON المخصصة
function bte_rest_get_post($request) {
    $post_id = intval($request['id']);
    $post = get_post($post_id);
    if (!$post) {
        return new WP_Error('no_post', 'Post not found', array('status' => 404));
    }

    $payload = array(
        'id' => $post->ID,
        'post_type' => $post->post_type,
        'title' => $post->post_title,
        'content' => $post->post_content,
        'excerpt' => $post->post_excerpt,
        'status' => $post->post_status,
        'tax_input' => array(),
        'meta' => array()
    );

    // Taxonomies
    $taxonomies = get_object_taxonomies($post->post_type, 'names');
    foreach ($taxonomies as $tax) {
        $terms = wp_get_post_terms($post->ID, $tax, array('fields' => 'ids'));
        if (!is_wp_error($terms) && !empty($terms)) {
            $payload['tax_input'][$tax] = $terms;
        } else {
            $payload['tax_input'][$tax] = array();
        }
    }

    // Meta (جميع الـ Custom fields باستثناء التي تبدأ بـ _)
    $all_meta = get_post_meta($post_id);
    foreach ($all_meta as $key => $values) {
        if (strpos($key, '_') === 0 && $key !== '_description') continue;
        $val = maybe_unserialize($values[0]);
        $payload['meta'][$key] = $val;
    }

    return array('success' => true, 'data' => $payload);
}

// إنشاء بوست جديد عبر REST API
function bte_rest_create_post($request) {
    $params = $request->get_json_params();
    if (!is_array($params)) {
        $params = $request->get_params();
    }

    $post_id_input = isset($params['id']) ? intval($params['id']) : 0;
    $post_type = isset($params['post_type']) ? sanitize_text_field($params['post_type']) : 'post';
    $title = isset($params['title']) ? sanitize_text_field($params['title']) : '';
    $content = isset($params['content']) ? wp_kses_post($params['content']) : '';
    $excerpt = isset($params['excerpt']) ? wp_kses_post($params['excerpt']) : '';
    $status = isset($params['status']) ? sanitize_text_field($params['status']) : 'draft';
    $author = isset($params['author']) ? intval($params['author']) : get_current_user_id();

    if ($title === '' && $post_id_input === 0) { // شرط العنوان للبوستات الجديدة
        return new WP_Error('bte_missing_title', __('Title is required.', 'bulk-taxonomy-editor'), array('status' => 400));
    }

    if (!post_type_exists($post_type)) {
        return new WP_Error('bte_invalid_post_type', __('Invalid post type.', 'bulk-taxonomy-editor'), array('status' => 400));
    }

    $allowed_post_types = (array) get_option('bte_api_allowed_post_types', array());
    if (!empty($allowed_post_types) && !in_array($post_type, $allowed_post_types, true)) {
        return new WP_Error('bte_post_type_not_allowed', __('Post type not allowed by API settings.', 'bulk-taxonomy-editor'), array('status' => 403));
    }

    $post_data = array();
    
    // إذا كان البوست جديد، يجب التأكد من الحقول الأساسية
    if ($post_id_input === 0) {
        $post_data['post_type'] = $post_type;
        $post_data['post_title'] = $title;
        $post_data['post_content'] = $content;
        $post_data['post_excerpt'] = $excerpt;
        $post_data['post_status'] = $status;
        $post_data['post_author'] = $author;
    } else {
        // في حالة التعديل، نضيف فقط الحقول المُرسلة ولانمسح المتبقي
        $post_data['ID'] = $post_id_input;
        if (isset($params['post_type'])) $post_data['post_type'] = $post_type;
        if (isset($params['title'])) $post_data['post_title'] = $title;
        if (isset($params['content'])) $post_data['post_content'] = $content;
        if (isset($params['excerpt'])) $post_data['post_excerpt'] = $excerpt;
        if (isset($params['status'])) $post_data['post_status'] = $status;
        if (isset($params['author'])) $post_data['post_author'] = $author;
    }

    // التحقق والتعديل إذا تم تمرير ID
    if ($post_id_input > 0) {
        $post_id = wp_update_post($post_data, true);
    } else {
        $post_id = wp_insert_post($post_data, true);
    }

    if (is_wp_error($post_id)) {
        return $post_id;
    }

    // تعيين التصنيفات (tax_input)
    if (isset($params['tax_input']) && is_array($params['tax_input'])) {
        foreach ($params['tax_input'] as $taxonomy => $terms) {
            $taxonomy = sanitize_text_field($taxonomy);
            if (!taxonomy_exists($taxonomy)) {
                continue;
            }

            $term_ids = array();
            if (is_array($terms)) {
                foreach ($terms as $term) {
                    if (is_numeric($term)) {
                        $term_ids[] = intval($term);
                    } else {
                        $term_ids[] = sanitize_text_field($term);
                    }
                }
            }

            if (!empty($term_ids)) {
                wp_set_object_terms($post_id, $term_ids, $taxonomy, false);
            }
        }
    }

    // تعيين الميتا (بما فيها JetEngine)
    if (isset($params['meta']) && is_array($params['meta'])) {
        foreach ($params['meta'] as $meta_key => $meta_value) {
            $meta_key = sanitize_text_field($meta_key);
            if ($meta_key === '') {
                continue;
            }

            // معالجة الصور واستبدال الروابط بالآي ديهات
            bte_process_meta_images($meta_value, $post_id);

            if (is_array($meta_value)) {
                update_post_meta($post_id, $meta_key, $meta_value);
            } else {
                update_post_meta($post_id, $meta_key, wp_unslash($meta_value));
            }
        }
    }

    return array(
        'success' => true,
        'post_id' => $post_id,
        'edit_link' => get_edit_post_link($post_id, 'raw'),
    );
}

// ==========================================
// تسجيل مسارات الـ REST API لإنشاء البوستات
// ==========================================
function bte_register_rest_routes() {
    // 1. المسار لإنشاء أو تعديل بوست
    register_rest_route('bulk-taxonomy-editor/v1', '/posts', array(
        'methods' => 'POST',
        'callback' => 'bte_rest_create_post',
        'permission_callback' => 'bte_rest_check_permissions'
    ));

    // 2. المسار لجلب قائمة البوستات
    register_rest_route('bulk-taxonomy-editor/v1', '/posts', array(
        'methods' => 'GET',
        'callback' => 'bte_rest_get_posts_list',
        'permission_callback' => 'bte_rest_check_permissions'
    ));

    // 3. المسار لجلب تفاصيل بوست معين
    register_rest_route('bulk-taxonomy-editor/v1', '/posts/(?P<id>\d+)', array(
        'methods' => 'GET',
        'callback' => 'bte_rest_get_post',
        'permission_callback' => 'bte_rest_check_permissions'
    ));

    // 4. المسار لجلب التصنيفات المرتبطة بنوع بوست
    register_rest_route('bulk-taxonomy-editor/v1', '/taxonomies', array(
        'methods' => 'GET',
        'callback' => 'bte_rest_get_taxonomies',
        'permission_callback' => 'bte_rest_check_permissions'
    ));

    // 5. المسار لجلب المصطلحات (Categories/Tags/Terms) التابعة لتصنيف معين
    register_rest_route('bulk-taxonomy-editor/v1', '/terms', array(
        'methods' => 'GET',
        'callback' => 'bte_rest_get_terms',
        'permission_callback' => 'bte_rest_check_permissions'
    ));
}
add_action('rest_api_init', 'bte_register_rest_routes');

function bte_rest_get_taxonomies(WP_REST_Request $request) {
    $post_type = $request->get_param('post_type');
    if (empty($post_type)) {
        return new WP_Error('missing_param', __('post_type is required', 'bulk-taxonomy-editor'), array('status' => 400));
    }
    $taxonomies = Bulk_Taxonomy_Editor::get_taxonomies_for_post_type($post_type);
    return rest_ensure_response(array('success' => true, 'data' => $taxonomies));
}

function bte_rest_get_terms(WP_REST_Request $request) {
    $taxonomy = $request->get_param('taxonomy');
    $search = $request->get_param('search') ?: '';
    if (empty($taxonomy)) {
        return new WP_Error('missing_param', __('taxonomy is required', 'bulk-taxonomy-editor'), array('status' => 400));
    }
    $terms = Bulk_Taxonomy_Editor::get_terms_for_taxonomy($taxonomy, $search);
    return rest_ensure_response(array('success' => true, 'data' => $terms));
}

// التحقق من صلاحيات الـ API
function bte_rest_check_permissions(WP_REST_Request $request) {
    // 1. تحقق من تفعيل الـ API من الإعدادات
    if (get_option('bte_api_enabled', 0) != 1) {
        return new WP_Error('disabled', __('API is disabled from settings', 'bulk-taxonomy-editor'), array('status' => 403));
    }
    
    // 2. التحقق من تسجيل الدخول (عن طريق Application Passwords)
    if (!is_user_logged_in()) {
        return new WP_Error('unauthorized', __('You must be authenticated to use this API', 'bulk-taxonomy-editor'), array('status' => 401));
    }

    // 3. التحقق من الصلاحيات والـ Roles
    $user = wp_get_current_user();
    $allowed_roles = get_option('bte_api_allowed_roles', array());
    if (empty($allowed_roles)) {
        return new WP_Error('forbidden', __('No roles allowed in settings', 'bulk-taxonomy-editor'), array('status' => 403));
    }

    $has_role = false;
    foreach ((array) $user->roles as $role) {
        if (in_array($role, $allowed_roles, true)) {
            $has_role = true;
            break;
        }
    }

    if (!$has_role) {
        return new WP_Error('forbidden', __('Your role is not allowed to use this API', 'bulk-taxonomy-editor'), array('status' => 403));
    }

    return true;
}
