jQuery(document).ready(function($) {
    var currentPage = 1;
    var totalPages = 1;
    var selectedPosts = [];
    var currentObjectType = 'post';
    var currentTarget = ''; // Will hold either post_type or taxonomy name

    // تبديل Object Type (بوستات أو تصنيفات)
    $('input[name="object_type"]').on('change', function() {
        currentObjectType = $(this).val();
        selectedPosts = [];
        
        if (currentObjectType === 'term') {
            $('#wrapper-post-type').hide();
            $('#wrapper-taxonomy').show();
            $('#post-type-select').val('');
            $('#taxonomies-section').hide(); // لا يمكن إسناد تصنيفات للتصنيفات
        } else {
            $('#wrapper-post-type').show();
            $('#wrapper-taxonomy').hide();
            $('#taxonomy-mode-select').val('');
            $('#taxonomies-section').show();
        }

        resetUI();
    });

    // إعادة تحميل البيانات عند تغيير اللغة
    $('#language-select').on('change', function() {
        if (currentTarget) {
           triggerLoad();
        }
    });

    // عند تغيير الهدف (نوع البوست أو اسم التصنيف)
    $('#post-type-select, #taxonomy-mode-select').on('change', function() {
        currentTarget = $(this).val();
        triggerLoad();
    });

    function resetUI() {
        selectedPosts = [];
        $('#select-all-posts').prop('checked', false);
        $('#taxonomies-container').html('<p class="description">' + bte_ajax.strings.loading_taxonomies + '</p>');
        $('#repeaters-container').html('<p class="description">' + bte_ajax.strings.loading_repeaters + '</p>');
        $('#posts-container').html('<p class="description">' + bte_ajax.strings.loading_posts + '</p>');
        $('#posts-pagination').hide();
        $('#actions-section').hide();
        
        if (!currentTarget) {
            $('#taxonomies-section').hide();
            $('#meta-fields-section').hide();
            $('#repeaters-section').hide();
            $('#posts-section').hide();
            $('#actions-section').hide();
            $('#action-type-section').hide();
        }
    }

    function triggerLoad() {
        resetUI();
        if (!currentTarget) return;

        if (currentObjectType === 'post') {
            $('#taxonomies-section').show();
        } else {
            $('#taxonomies-section').hide();
        }
        
        $('#meta-fields-section').show();
        $('#repeaters-section').show();
        $('#posts-section').show();

        // 1. جلب التصنيفات المتاحة (فقط للبوستات)
        if (currentObjectType === 'post') {
            $.ajax({
                url: bte_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'bte_get_taxonomies',
                    nonce: bte_ajax.nonce,
                    post_type: currentTarget,
                    language: $('#language-select').length ? $('#language-select').val() : ''
                },
                success: function(response) {
                    if (response.success) {
                        $('#taxonomies-container').empty();
                        $.each(response.data.taxonomies, function(key, value) {
                            var safeId = key.replace(/[^a-z0-9_-]/gi, '_');
                            $('#taxonomies-container').append(
                                '<div class="bte-taxonomy-block" data-taxonomy="' + key + '" data-safe-id="' + safeId + '">' +
                                '<h3 class="bte-taxonomy-title">' + value + '</h3>' +
                                '<div id="terms-' + safeId + '" class="bte-terms"><p class="description">' + bte_ajax.strings.loading_terms + '</p></div>' +
                                '</div>'
                            );

                            loadTermsForTaxonomy(key, safeId, '');
                        });
                        $('#action-type-section').show();
                    } else {
                        $('#taxonomies-container').html('<p class="description">' + bte_ajax.strings.no_taxonomies + '</p>');
                        $('#action-type-section').hide();
                    }
                },
                error: function() {
                    $('#taxonomies-container').html('<p class="description">' + bte_ajax.strings.error_loading_taxonomies + '</p>');
                    $('#action-type-section').hide();
                }
            });
        } else {
            $('#action-type-section').show(); // Show anyway for term editing
        }

        // 2. تحميل الحقول العادية من JetEngine
        $.ajax({
            url: bte_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'bte_get_meta_fields',
                nonce: bte_ajax.nonce,
                post_type: currentTarget,
                object_type: currentObjectType,
                language: $('#language-select').length ? $('#language-select').val() : ''
            },
            success: function(response) {
                if (response.success && response.data.fields && response.data.fields.length > 0) {
                    $('#meta-fields-container').empty();
                    $.each(response.data.fields, function(index, field) {
                        var type = field.type || 'text';
                        var name = field.name || field.id;
                        var label = field.title || field.label || name;
                        var options = field.options || {};
                        var html = '<div class="bte-meta-field-row" style="margin-bottom: 12px;">';
                        html += '<label style="display:inline-block; width:220px; font-weight:bold; vertical-align: top;">' + label + '</label>';
                        
                        var validOptionsCount = 0;
                        var inputName = 'meta_data[' + name + ']';
                        if ((type === 'select' || type === 'radio') && options) {
                            $.each(options, function(k, v) {
                                var optVal = typeof v === 'object' ? (v.key !== undefined ? v.key : (v.value !== undefined ? v.value : k)) : k;
                                var optText = typeof v === 'object' ? (v.label !== undefined ? v.label : (v.value !== undefined ? v.value : v)) : v;
                                if (optVal !== '' || optText !== '') validOptionsCount++;
                            });
                        }

                        if ((type === 'select' || type === 'radio') && validOptionsCount > 0) {
                            html += '<div class="bte-input-wrapper" style="display:inline-block; vertical-align:top;">';
                            html += '<select name="' + inputName + '" class="bte-main-input" style="width: 320px; max-width:100%;"><option value=""></option>';
                            $.each(options, function(k, v) {
                                var optVal = typeof v === 'object' ? (v.key !== undefined ? v.key : (v.value !== undefined ? v.value : k)) : k;
                                var optText = typeof v === 'object' ? (v.label !== undefined ? v.label : (v.value !== undefined ? v.value : v)) : v;
                                if (optVal === '' && optText === '') return;
                                html += '<option value="' + optVal + '">' + optText + '</option>';
                            });
                            html += '</select>';
                            html += '<input type="text" class="bte-manual-input" style="width: 320px; max-width:100%; display:none;" placeholder="Enter value manually">';
                            html += '<br><a href="#" class="bte-toggle-manual" data-name="' + inputName + '" style="font-size:12px; text-decoration:none;">✎ Enter value manually</a>';
                            html += '</div>';
                        } else if (type === 'textarea' || type === 'wysiwyg') {
                            html += '<textarea name="' + inputName + '" style="width: 320px; max-width:100%;" rows="3"></textarea>';
                        } else {
                            html += '<input type="text" name="' + inputName + '" style="width: 320px; max-width:100%;">';
                            if (type === 'select' || type === 'radio') {
                                html += '<br><small style="color:#666; margin-top:5px; display:block;">(' + bte_ajax.strings.no_meta_fields + ' - Enter manually)</small>';
                            }
                        }
                        html += '</div>';
                        $('#meta-fields-container').append(html);
                    });
                } else {
                    $('#meta-fields-container').html('<p class="description">' + bte_ajax.strings.no_meta_fields + '</p>');
                }
            },
            error: function() {
                $('#meta-fields-container').html('<p class="description">' + bte_ajax.strings.error_loading_meta_fields + '</p>');
            }
        });

        // 3. تحميل الريبيترز من JetEngine
        $.ajax({
            url: bte_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'bte_get_repeaters',
                nonce: bte_ajax.nonce,
                post_type: currentTarget,
                object_type: currentObjectType,
                language: $('#language-select').length ? $('#language-select').val() : ''
            },
            success: function(response) {
                if (response.success && response.data.repeaters) {
                    var repeaters = response.data.repeaters;
                    var keys = Object.keys(repeaters);
                    if (keys.length === 0) {
                        $('#repeaters-container').html('<p class="description">' + bte_ajax.strings.no_repeaters + '</p>');
                        return;
                    }

                    $('#repeaters-container').empty();
                    $.each(repeaters, function(key, label) {
                        var data = repeaters[key];
                        var labelText = data && data.label ? data.label : label;
                        var fields = data && data.fields ? data.fields : [];

                        var $block = $('<div>', { 'class': 'bte-repeater-block', 'data-key': key });
                        var $header = $('<div>', { 'class': 'bte-repeater-header' });
                        var $label = $('<label>', { 'class': 'bte-repeater-label' });
                        $label.text(labelText + ' ');
                        $label.append($('<span>', { 'class': 'bte-repeater-key', text: '(' + key + ')' }));

                        var $addBtn = $('<button>', {
                            type: 'button',
                            'class': 'button bte-add-row',
                            text: bte_ajax.strings.add_row
                        });

                        var $tableWrap = $('<div>', { 'class': 'bte-repeater-table-wrap' });
                        var $table = $('<table>', { 'class': 'bte-repeater-table' });
                        var $thead = $('<thead>');
                        var $headRow = $('<tr>');

                        $.each(fields, function(i, field) {
                            $headRow.append($('<th>', { text: field.label || field.name }));
                        });
                        $headRow.append($('<th>', { text: '' }));
                        $thead.append($headRow);

                        var $tbody = $('<tbody>');

                        var $hidden = $('<input>', {
                            type: 'hidden',
                            'class': 'bte-repeater-json',
                            name: 'repeater_data[' + key + ']',
                            value: ''
                        });

                        var $help = $('<p>', { 'class': 'description', text: bte_ajax.strings.repeater_help });

                        $table.append($thead, $tbody);
                        $tableWrap.append($table);
                        $header.append($label, $addBtn);
                        $block.append($header, $tableWrap, $hidden, $help);

                        $block.data('fields', fields);
                        $('#repeaters-container').append($block);

                        addRepeaterRow($block);
                    });
                } else {
                    $('#repeaters-container').html('<p class="description">' + bte_ajax.strings.no_repeaters + '</p>');
                }
            },
            error: function() {
                $('#repeaters-container').html('<p class="description">' + bte_ajax.strings.error_loading_repeaters + '</p>');
            }
        });

        // 4. تحميل البوستات أو التصنيفات
        loadPosts(currentTarget, currentObjectType, '', 1);
    }

    // إضافة صف جديد للريبيتر
    function addRepeaterRow($block) {
        var fields = $block.data('fields') || [];
        var $tbody = $block.find('tbody');
        var $row = $('<tr>');

        $.each(fields, function(i, field) {
            var $cell = $('<td>');
            var $input;
            var type = field.type || 'text';

            if (type === 'select' && field.options) {
                $input = $('<select>', { 'class': 'bte-repeater-field', 'data-name': field.name });
                $.each(field.options, function(optValue, optLabel) {
                    $input.append($('<option>', { value: optValue, text: optLabel }));
                });
            } else if (type === 'textarea') {
                $input = $('<textarea>', { 'class': 'bte-repeater-field', 'data-name': field.name, rows: 2 });
            } else {
                $input = $('<input>', { type: 'text', 'class': 'bte-repeater-field', 'data-name': field.name });
            }

            $cell.append($input);
            $row.append($cell);
        });

        var $removeCell = $('<td>');
        var $removeBtn = $('<button>', {
            type: 'button',
            'class': 'button-link bte-remove-row',
            text: bte_ajax.strings.remove_row
        });
        $removeCell.append($removeBtn);
        $row.append($removeCell);

        $tbody.append($row);
        updateRepeaterJson($block);
    }

    // تحديث JSON المخفي
    function updateRepeaterJson($block) {
        var rows = [];
        $block.find('tbody tr').each(function() {
            var rowData = {};
            var hasValue = false;
            $(this).find('.bte-repeater-field').each(function() {
                var name = $(this).data('name');
                var value = $(this).val();
                rowData[name] = value;
                if (value !== '' && value !== null) {
                    hasValue = true;
                }
            });
            if (hasValue) {
                rows.push(rowData);
            }
        });

        $block.find('.bte-repeater-json').val(JSON.stringify(rows));
    }

    // أحداث الريبيتر
    $('#repeaters-container').on('click', '.bte-add-row', function() {
        var $block = $(this).closest('.bte-repeater-block');
        addRepeaterRow($block);
    });

    $('#repeaters-container').on('click', '.bte-remove-row', function() {
        var $block = $(this).closest('.bte-repeater-block');
        $(this).closest('tr').remove();
        updateRepeaterJson($block);
    });

    $('#repeaters-container').on('input change', '.bte-repeater-field', function() {
        var $block = $(this).closest('.bte-repeater-block');
        updateRepeaterJson($block);
    });

    // تحميل مصطلحات تاكسونومي مع البحث (سيرفر)
    function loadTermsForTaxonomy(taxonomy, safeId, searchTerm) {
        $.ajax({
            url: bte_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'bte_get_terms',
                nonce: bte_ajax.nonce,
                taxonomy: taxonomy,
                search: searchTerm || '',
                language: $('#language-select').length ? $('#language-select').val() : ''
            },
            success: function(termsResponse) {
                var container = $('#terms-' + safeId);
                if (termsResponse.success && termsResponse.data.terms.length > 0) {
                    container.empty();
                    $.each(termsResponse.data.terms, function(index, term) {
                        var termName = (term.name || '').toString();
                        container.append(
                            '<label class="bte-checkbox-label" data-term-name="' + termName.toLowerCase() + '">' +
                            '<input type="checkbox" name="terms[' + taxonomy + '][]" value="' + term.term_id + '"> ' +
                            term.name +
                            '</label>'
                        );
                    });
                } else {
                    container.html('<p class="description">' + bte_ajax.strings.no_terms + '</p>');
                }
            },
            error: function() {
                $('#terms-' + safeId).html('<p class="description">' + bte_ajax.strings.error_loading_terms + '</p>');
            }
        });
    }

    // البحث في المصطلحات (على مستوى كل التاكسونومي)
    var termsSearchTimer = null;
    $('#terms-search').on('keyup', function() {
        var searchTerm = $(this).val().trim();

        if (termsSearchTimer) {
            clearTimeout(termsSearchTimer);
        }

        termsSearchTimer = setTimeout(function() {
            $('#taxonomies-container .bte-taxonomy-block').each(function() {
                var taxonomy = $(this).data('taxonomy');
                var safeId = $(this).data('safe-id');
                if (taxonomy && safeId) {
                    loadTermsForTaxonomy(taxonomy, safeId, searchTerm);
                }
            });
        }, 300);
    });

    // البحث في البوستات
    $('#posts-search').on('keyup', function(e) {
        if (e.keyCode === 13) { // Enter key
            e.preventDefault();
            var searchTerm = $(this).val();
            if (currentTarget) {
                loadPosts(currentTarget, currentObjectType, searchTerm, 1);
            }
        }
    });

    // أزرار التنقل بين الصفحات
    $('#prev-page').on('click', function() {
        if (currentPage > 1) {
            var searchTerm = $('#posts-search').val();
            loadPosts(currentTarget, currentObjectType, searchTerm, currentPage - 1);
        }
    });

    $('#next-page').on('click', function() {
        if (currentPage < totalPages) {
            var searchTerm = $('#posts-search').val();
            loadPosts(currentTarget, currentObjectType, searchTerm, currentPage + 1);
        }
    });

    // تحديد جميع العناصر بشكل استثنائي (سحب للكل)
    $('#select-all-posts').on('change', function() {
        var isChecked = $(this).prop('checked');
        
        if (isChecked) {
            $('#posts-container').prepend('<p class="loading-all-msg" style="color:blue;">Fetching all matching items across all pages...</p>');
            
            // طلب كافة الآيديهات عبر الأجاكس
            $.ajax({
                 url: bte_ajax.ajax_url,
                 type: 'POST',
                 data: { 
                     action: 'bte_get_all_matching_ids', 
                     nonce: bte_ajax.nonce, 
                     target: currentTarget,
                     object_type: currentObjectType,
                     search: $('#posts-search').val(), 
                     language: $('#language-select').length ? $('#language-select').val() : ''
                 },
                 success: function(res) {
                     $('.loading-all-msg').remove();
                     if(res.success && res.data.ids) {
                         selectedPosts = res.data.ids.map(String); // Map to strings
                         // Check visible boxes
                         $('#posts-container input[type="checkbox"]').prop('checked', true);
                         if (selectedPosts.length > 0) $('#actions-section').show();
                     } else {
                         alert('Failed to fetch full items list.');
                     }
                 },
                 error: function() {
                     $('.loading-all-msg').remove();
                     alert('Error calling server to get full items.');
                 }
            });
        } else {
             selectedPosts = [];
             $('#posts-container input[type="checkbox"]').prop('checked', false);
             $('#actions-section').hide();
        }
    });

    // دالة لتحميل البوستات أو المصطلحات بالتصفح
    function loadPosts(target, objType, searchTerm, page) {
        $('#posts-container').html('<p class="description">' + bte_ajax.strings.loading_posts + '</p>');

        $.ajax({
            url: bte_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'bte_get_posts', // Reused for terms with object_type switch backend
                nonce: bte_ajax.nonce,
                post_type: target,
                object_type: objType,
                search: searchTerm,
                paged: page,
                language: $('#language-select').length ? $('#language-select').val() : ''
            },
            success: function(response) {
                if (response.success) {
                    currentPage = page;
                    totalPages = response.data.pages;

                    $('#posts-container').empty();

                    if (response.data.posts.length > 0) {
                        $.each(response.data.posts, function(index, post) {
                            var id = (objType === 'term') ? post.term_id : post.ID;
                            var title = (objType === 'term') ? post.name : post.post_title;
                            var isChecked = $.inArray(id.toString(), selectedPosts) !== -1 ? 'checked' : '';
                            $('#posts-container').append(
                                '<label class="bte-checkbox-label">' +
                                '<input type="checkbox" name="posts[]" value="' + id + '" ' + isChecked + '> ' +
                                title +
                                '</label>'
                            );
                        });

                        $('#posts-pagination').show();
                        $('#page-info').text(bte_ajax.strings.page + ' ' + currentPage + ' ' + bte_ajax.strings.of + ' ' + totalPages);

                        // إذا كنا قد حددنا الكل وأحضرنا جميع الآيديهات، يجب عرض الزر. 
                        // أما إذا قمنا بتبديل الصفحة ولم نحدد الكل برمجياً.
                        
                        if (selectedPosts.length > 0) {
                            $('#actions-section').show();
                            // Optional: If all on this page are physically inside selectedPosts, we could tick the master box, but safer to leave master alone.
                        } else {
                            $('#select-all-posts').prop('checked', false);
                        }
                    } else {
                        $('#posts-container').html('<p class="description">' + bte_ajax.strings.no_posts + '</p>');
                        $('#posts-pagination').hide();
                    }
                } else {
                    $('#posts-container').html('<p class="description">' + bte_ajax.strings.error_loading_posts + '</p>');
                    $('#posts-pagination').hide();
                }
            },
            error: function() {
                $('#posts-container').html('<p class="description">' + bte_ajax.strings.error_loading_posts + '</p>');
                $('#posts-pagination').hide();
            }
        });
    }

    // تحديث قائمة البوستات المحددة عند النقر على مربعات الاختيار في الصفحة
    $('#posts-container').on('change', 'input[type="checkbox"]', function() {
        var postId = $(this).val().toString();

        if ($(this).prop('checked')) {
            if ($.inArray(postId, selectedPosts) === -1) {
                selectedPosts.push(postId);
            }
        } else {
            var index = $.inArray(postId, selectedPosts);
            if (index !== -1) {
                selectedPosts.splice(index, 1);
            }
            // إزالة علامة تحديد الكل لأنك قمت بإلغاء واحد
            $('#select-all-posts').prop('checked', false);
        }

        if (selectedPosts.length > 0) {
            $('#actions-section').show();
        } else {
            $('#actions-section').hide();
        }
    });

    // التحقق من صحة النموذج قبل الإرسال
    $('#bulk-taxonomy-editor-form').on('submit', function(e) {
        if (!currentTarget) {
            e.preventDefault();
            alert(bte_ajax.strings.select_post_type);
            return false;
        }

        var selectedTerms = $('#taxonomies-container input[type="checkbox"]:checked');
        var hasRepeaterData = false;
        $('#repeaters-container .bte-repeater-json').each(function() {
            var val = $(this).val().trim();
            if (val !== '' && val !== '[]') {
                hasRepeaterData = true;
            }
        });

        var hasMetaData = false;
        $('#meta-fields-container input, #meta-fields-container select, #meta-fields-container textarea').each(function() {
            if ($(this).val().trim() !== '') {
                hasMetaData = true;
            }
        });

        if (selectedTerms.length === 0 && !hasRepeaterData && !hasMetaData) {
            e.preventDefault();
            alert(bte_ajax.strings.select_terms_or_repeaters);
            return false;
        }

        if (selectedPosts.length === 0) {
            e.preventDefault();
            alert(bte_ajax.strings.select_posts);
            return false;
        }
        
        if (!confirm(bte_ajax.strings.confirm_update)) {
            e.preventDefault();
            return false;
        }

        // إفراغ الـ Checkboxes الوهمية التي تم رسمها
        $('#posts-container input[type="checkbox"]').prop('disabled', true);
        
        // ضخ كافة العناصر المخزنة برمجيا لتُرسل للسيرفر
        $.each(selectedPosts, function(index, postId) {
            $('<input>').attr({
                type: 'hidden',
                name: 'posts[]',
                value: postId
            }).appendTo('#bulk-taxonomy-editor-form');
        });
    });

    // لو فيه هدف محدد مسبقًا
    if ($('#post-type-select').val()) {
        $('#post-type-select').trigger('change');
    }

    // تبديل إدخال الميتا بين القائمة المنسدلة والحقل النصي
    $(document).on('click', '.bte-toggle-manual', function(e) {
        e.preventDefault();
        var wrapper = $(this).closest('.bte-input-wrapper');
        var select = wrapper.find('.bte-main-input');
        var input = wrapper.find('.bte-manual-input');
        var inputName = $(this).data('name');

        if (select.is(':visible')) {
            select.hide().removeAttr('name').val('');
            input.show().attr('name', inputName).focus();
            $(this).html('← Return to select list');
        } else {
            input.hide().removeAttr('name').val('');
            select.show().attr('name', inputName);
            $(this).html('✎ Enter value manually');
        }
    });

});
