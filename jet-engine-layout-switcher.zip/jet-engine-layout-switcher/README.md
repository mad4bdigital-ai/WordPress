# ChangeLog

## 1.0.1
* FIX: Swiper.js compatibility.
