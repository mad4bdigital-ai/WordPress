<?php
/**
 * Plugin Name: TripKlik Tour Date Filter Assets
 * Description: Loads tour date filter data, Flatpickr locale files, and cruise itinerary frontend flag on tour pages only.
 * Version: 1.0.0
 * Author: OpenAI for Nagy
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( defined( 'TK_TOUR_DATE_FILTER_ASSETS_ENABLED' ) && ! TK_TOUR_DATE_FILTER_ASSETS_ENABLED ) {
    return;
}

if ( ! function_exists( 'tk_tour_date_filter_post_type' ) ) {
    function tk_tour_date_filter_post_type(): string {
        return defined( 'TK_TOUR_DATE_FILTER_POST_TYPE' ) ? (string) TK_TOUR_DATE_FILTER_POST_TYPE : 'tours-and-activities';
    }
}

if ( ! function_exists( 'tk_tour_date_filter_taxonomy' ) ) {
    function tk_tour_date_filter_taxonomy(): string {
        return defined( 'TK_TOUR_DATE_FILTER_TAXONOMY' ) ? (string) TK_TOUR_DATE_FILTER_TAXONOMY : 'schudle-days-of-weak';
    }
}

if ( ! function_exists( 'tk_tour_date_filter_reference_lang' ) ) {
    function tk_tour_date_filter_reference_lang(): string {
        return defined( 'TK_TOUR_DATE_FILTER_REFERENCE_LANG' ) ? (string) TK_TOUR_DATE_FILTER_REFERENCE_LANG : 'en';
    }
}

if ( ! function_exists( 'tk_tour_date_filter_map_term_slug_to_reference' ) ) {
    function tk_tour_date_filter_map_term_slug_to_reference( WP_Term $term, string $taxonomy ): string {
        $reference_lang = tk_tour_date_filter_reference_lang();

        if ( $reference_lang && has_filter( 'wpml_object_id' ) ) {
            $mapped_id = apply_filters( 'wpml_object_id', (int) $term->term_id, $taxonomy, false, $reference_lang );
            if ( $mapped_id ) {
                $mapped = get_term( (int) $mapped_id, $taxonomy );
                if ( $mapped instanceof WP_Term && ! is_wp_error( $mapped ) && $mapped->slug ) {
                    return strtolower( (string) $mapped->slug );
                }
            }
        }

        if ( $reference_lang && function_exists( 'icl_object_id' ) ) {
            $mapped_id = icl_object_id( (int) $term->term_id, $taxonomy, false, $reference_lang );
            if ( $mapped_id ) {
                $mapped = get_term( (int) $mapped_id, $taxonomy );
                if ( $mapped instanceof WP_Term && ! is_wp_error( $mapped ) && $mapped->slug ) {
                    return strtolower( (string) $mapped->slug );
                }
            }
        }

        return strtolower( (string) $term->slug );
    }
}

if ( ! function_exists( 'tk_tour_date_filter_allowed_days' ) ) {
    function tk_tour_date_filter_allowed_days( int $post_id ): array {
        $taxonomy = tk_tour_date_filter_taxonomy();
        if ( ! taxonomy_exists( $taxonomy ) ) {
            return [];
        }

        $terms = get_the_terms( $post_id, $taxonomy );
        if ( empty( $terms ) || is_wp_error( $terms ) ) {
            return [];
        }

        $day_map = [
            'sunday'    => 0,
            'monday'    => 1,
            'tuesday'   => 2,
            'wednesday' => 3,
            'thursday'  => 4,
            'friday'    => 5,
            'saturday'  => 6,
        ];

        $allowed = [];
        foreach ( $terms as $term ) {
            if ( ! $term instanceof WP_Term ) {
                continue;
            }

            $slug = tk_tour_date_filter_map_term_slug_to_reference( $term, $taxonomy );
            if ( isset( $day_map[ $slug ] ) ) {
                $allowed[] = $day_map[ $slug ];
            }
        }

        $allowed = array_values( array_unique( array_map( 'intval', $allowed ) ) );
        sort( $allowed );

        return $allowed;
    }
}

if ( ! function_exists( 'tk_tour_date_filter_enqueue_flatpickr_locales' ) ) {
    function tk_tour_date_filter_enqueue_flatpickr_locales(): void {
        if ( defined( 'TK_TOUR_DATE_FILTER_LOAD_FLATPICKR_LOCALES' ) && ! TK_TOUR_DATE_FILTER_LOAD_FLATPICKR_LOCALES ) {
            return;
        }

        if ( ! wp_script_is( 'flatpickr', 'registered' ) && ! wp_script_is( 'flatpickr', 'enqueued' ) && ! wp_script_is( 'flatpickr', 'done' ) ) {
            return;
        }

        $base    = 'https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/';
        $locales = [ 'ar', 'es', 'it', 'fr', 'de' ];

        foreach ( $locales as $locale ) {
            wp_enqueue_script(
                'flatpickr-locale-' . $locale,
                $base . $locale . '.js',
                [ 'flatpickr' ],
                null,
                true
            );
        }
    }
}

if ( ! function_exists( 'tk_tour_date_filter_enqueue_assets' ) ) {
    function tk_tour_date_filter_enqueue_assets(): void {
        $post_type = tk_tour_date_filter_post_type();

        if ( ! is_singular( $post_type ) ) {
            return;
        }

        $post_id = get_queried_object_id();
        if ( ! $post_id ) {
            return;
        }

        $script_file = defined( 'TK_TOUR_DATE_FILTER_SCRIPT' ) ? (string) TK_TOUR_DATE_FILTER_SCRIPT : 'trip-date-filter.js';
        $script_file = ltrim( $script_file, '/' );
        $script_path = trailingslashit( get_stylesheet_directory() ) . $script_file;
        $script_url  = trailingslashit( get_stylesheet_directory_uri() ) . $script_file;
        $handle      = 'trip-date-filter';

        if ( file_exists( $script_path ) ) {
            wp_enqueue_script(
                $handle,
                $script_url,
                [ 'jquery' ],
                (string) filemtime( $script_path ),
                true
            );
        } else {
            wp_register_script( $handle, false, [ 'jquery' ], null, true );
            wp_enqueue_script( $handle );
        }

        $allowed_days = tk_tour_date_filter_allowed_days( $post_id );
        wp_localize_script( $handle, 'tripDaysData', [
            'allowedDays' => $allowed_days,
        ] );

        $is_cruise = get_post_meta( $post_id, 'cruise_trip_itinerary', true );
        $is_cruise = ( $is_cruise === '1' || $is_cruise === 1 || $is_cruise === true || $is_cruise === 'true' );
        wp_add_inline_script( $handle, 'window.isCruiseTrip = ' . ( $is_cruise ? 'true' : 'false' ) . ';', 'before' );

        tk_tour_date_filter_enqueue_flatpickr_locales();
    }
}

add_action( 'wp_enqueue_scripts', 'tk_tour_date_filter_enqueue_assets', 30 );
