<?php
/**
 * Plugin Name: SEO Read More Elementor Widget
 * Description: SEO-friendly expandable text widget for Elementor with style controls and smooth full-content expansion.
 * Version: 3.0.0
 * Author: OpenAI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'elementor/widgets/register', function( $widgets_manager ) {

	if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
		return;
	}

	if ( ! class_exists( 'SEO_ReadMore_Widget' ) ) {

	class SEO_ReadMore_Widget extends \Elementor\Widget_Base {

		public function get_name() {
			return 'seo_readmore';
		}

		public function get_title() {
			return esc_html__( 'SEO Read More Text', 'seo-readmore-widget' );
		}

		public function get_icon() {
			return 'eicon-editor-paragraph';
		}

		public function get_categories() {
			return [ 'basic' ];
		}

		protected function register_controls() {

			$this->start_controls_section(
				'content_section',
				[
					'label' => esc_html__( 'Content', 'seo-readmore-widget' ),
					'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
				]
			);

			$this->add_control(
				'text_content',
				[
					'label'   => esc_html__( 'Text', 'seo-readmore-widget' ),
					'type'    => \Elementor\Controls_Manager::WYSIWYG,
					'default' => 'Discover the best luxury Egypt tours and carefully crafted Egypt tour packages across Egypt and the Middle East. Explore destinations included in our luxury travel packages, from Egypt tour packages to unforgettable Egypt and Jordan tour packages across the Middle East.',
				]
			);

			$this->add_control(
				'visible_rows',
				[
					'label'       => esc_html__( 'Visible Rows', 'seo-readmore-widget' ),
					'type'        => \Elementor\Controls_Manager::NUMBER,
					'default'     => 2,
					'min'         => 1,
					'max'         => 10,
					'step'        => 1,
					'description' => esc_html__( 'Number of text lines visible before expanding.', 'seo-readmore-widget' ),
				]
			);

			$this->add_control(
				'read_more_text',
				[
					'label'   => esc_html__( 'Read More Label', 'seo-readmore-widget' ),
					'type'    => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Read More', 'seo-readmore-widget' ),
				]
			);

			$this->add_control(
				'read_less_text',
				[
					'label'   => esc_html__( 'Read Less Label', 'seo-readmore-widget' ),
					'type'    => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Read Less', 'seo-readmore-widget' ),
				]
			);

			$this->end_controls_section();

			$this->start_controls_section(
				'style_text_section',
				[
					'label' => esc_html__( 'Text', 'seo-readmore-widget' ),
					'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);

			$this->add_control(
				'text_color',
				[
					'label'     => esc_html__( 'Text Color', 'seo-readmore-widget' ),
					'type'      => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .seo-readmore-content' => 'color: {{VALUE}};',
						'{{WRAPPER}} .seo-readmore-content *' => 'color: inherit;',
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name'     => 'text_typography',
					'selector' => '{{WRAPPER}} .seo-readmore-content',
				]
			);

			$this->add_responsive_control(
				'text_align',
				[
					'label'     => esc_html__( 'Alignment', 'seo-readmore-widget' ),
					'type'      => \Elementor\Controls_Manager::CHOOSE,
					'options'   => [
						'left' => [
							'title' => esc_html__( 'Left', 'seo-readmore-widget' ),
							'icon'  => 'eicon-text-align-left',
						],
						'center' => [
							'title' => esc_html__( 'Center', 'seo-readmore-widget' ),
							'icon'  => 'eicon-text-align-center',
						],
						'right' => [
							'title' => esc_html__( 'Right', 'seo-readmore-widget' ),
							'icon'  => 'eicon-text-align-right',
						],
						'justify' => [
							'title' => esc_html__( 'Justified', 'seo-readmore-widget' ),
							'icon'  => 'eicon-text-align-justify',
						],
					],
					'default'   => 'center',
					'selectors' => [
						'{{WRAPPER}} .seo-readmore' => 'text-align: {{VALUE}};',
					],
				]
			);

			$this->end_controls_section();

			$this->start_controls_section(
				'style_button_section',
				[
					'label' => esc_html__( 'Button', 'seo-readmore-widget' ),
					'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);

			$this->add_responsive_control(
				'button_align',
				[
					'label'     => esc_html__( 'Button Alignment', 'seo-readmore-widget' ),
					'type'      => \Elementor\Controls_Manager::CHOOSE,
					'options'   => [
						'left' => [
							'title' => esc_html__( 'Left', 'seo-readmore-widget' ),
							'icon'  => 'eicon-text-align-left',
						],
						'center' => [
							'title' => esc_html__( 'Center', 'seo-readmore-widget' ),
							'icon'  => 'eicon-text-align-center',
						],
						'right' => [
							'title' => esc_html__( 'Right', 'seo-readmore-widget' ),
							'icon'  => 'eicon-text-align-right',
						],
					],
					'default'   => 'center',
					'selectors' => [
						'{{WRAPPER}} .seo-readmore-btn-wrap' => 'text-align: {{VALUE}};',
					],
				]
			);

			$this->start_controls_tabs( 'button_style_tabs' );

			$this->start_controls_tab(
				'button_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'seo-readmore-widget' ),
				]
			);

			$this->add_control(
				'button_text_color',
				[
					'label'     => esc_html__( 'Text Color', 'seo-readmore-widget' ),
					'type'      => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .seo-readmore-btn' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_bg_color',
				[
					'label'     => esc_html__( 'Background Color', 'seo-readmore-widget' ),
					'type'      => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .seo-readmore-btn' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_border_color',
				[
					'label'     => esc_html__( 'Border Color', 'seo-readmore-widget' ),
					'type'      => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .seo-readmore-btn' => 'border-color: {{VALUE}};',
					],
				]
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'button_hover_tab',
				[
					'label' => esc_html__( 'Hover', 'seo-readmore-widget' ),
				]
			);

			$this->add_control(
				'button_hover_text_color',
				[
					'label'     => esc_html__( 'Text Color', 'seo-readmore-widget' ),
					'type'      => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .seo-readmore-btn:hover' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_hover_bg_color',
				[
					'label'     => esc_html__( 'Background Color', 'seo-readmore-widget' ),
					'type'      => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .seo-readmore-btn:hover' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'button_hover_border_color',
				[
					'label'     => esc_html__( 'Border Color', 'seo-readmore-widget' ),
					'type'      => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .seo-readmore-btn:hover' => 'border-color: {{VALUE}};',
					],
				]
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name'     => 'button_typography',
					'selector' => '{{WRAPPER}} .seo-readmore-btn',
				]
			);

			$this->add_responsive_control(
				'button_padding',
				[
					'label'      => esc_html__( 'Padding', 'seo-readmore-widget' ),
					'type'       => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', 'rem', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .seo-readmore-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'button_border_radius',
				[
					'label'      => esc_html__( 'Border Radius', 'seo-readmore-widget' ),
					'type'       => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em', 'rem' ],
					'selectors'  => [
						'{{WRAPPER}} .seo-readmore-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'button_border_width',
				[
					'label'      => esc_html__( 'Border Width', 'seo-readmore-widget' ),
					'type'       => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px' ],
					'selectors'  => [
						'{{WRAPPER}} .seo-readmore-btn' => 'border-style: solid; border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->end_controls_section();
		}

		protected function render() {
			$settings       = $this->get_settings_for_display();
			$widget_id      = 'seo-readmore-' . $this->get_id();
			$visible_rows   = ! empty( $settings['visible_rows'] ) ? absint( $settings['visible_rows'] ) : 2;
			$read_more_text = ! empty( $settings['read_more_text'] ) ? $settings['read_more_text'] : 'Read More';
			$read_less_text = ! empty( $settings['read_less_text'] ) ? $settings['read_less_text'] : 'Read Less';
			$full_html      = wp_kses_post( $settings['text_content'] );
			?>
			<div
				class="seo-readmore"
				data-visible-rows="<?php echo esc_attr( $visible_rows ); ?>"
				data-more-label="<?php echo esc_attr( $read_more_text ); ?>"
				data-less-label="<?php echo esc_attr( $read_less_text ); ?>"
			>
				<div class="seo-readmore-content-wrap">
					<div class="seo-readmore-content" id="<?php echo esc_attr( $widget_id ); ?>">
						<?php echo $full_html; ?>
					</div>
				</div>

				<div class="seo-readmore-btn-wrap">
					<button
						class="seo-readmore-btn"
						type="button"
						aria-expanded="false"
						aria-controls="<?php echo esc_attr( $widget_id ); ?>"
					>
						<?php echo esc_html( $read_more_text ); ?>
					</button>
				</div>
			</div>
			<?php
		}
	}

	}

	if ( class_exists( 'SEO_ReadMore_Widget' ) ) {
		$widgets_manager->register( new SEO_ReadMore_Widget() );
	}
} );

add_action( 'wp_footer', function() {
	if ( is_admin() ) {
		return;
	}
	?>
	<style>
		.seo-readmore {
			width: 100%;
		}

		.seo-readmore-content-wrap {
			overflow: hidden;
			transition: max-height 0.35s ease;
		}

		.seo-readmore-content {
			display: block;
		}

		.seo-readmore-content > *:first-child {
			margin-top: 0;
		}

		.seo-readmore-content > *:last-child {
			margin-bottom: 0;
		}

		.seo-readmore-btn-wrap {
			margin-top: 12px;
		}

		.seo-readmore-btn {
			display: inline-block;
			cursor: pointer;
			font: inherit;
			background: transparent;
			border: 1px solid currentColor;
			padding: 8px 16px;
			transition: all 0.25s ease;
		}

		.seo-readmore-btn:focus-visible {
			outline: 2px solid currentColor;
			outline-offset: 3px;
		}
	</style>

	<script>
		document.addEventListener('DOMContentLoaded', function () {
			const widgets = document.querySelectorAll('.seo-readmore');

			widgets.forEach(function (widget) {
				const wrap = widget.querySelector('.seo-readmore-content-wrap');
				const content = widget.querySelector('.seo-readmore-content');
				const btn = widget.querySelector('.seo-readmore-btn');

				if (!wrap || !content || !btn) {
					return;
				}

				const visibleRows = parseInt(widget.dataset.visibleRows || '2', 10);
				const readMoreLabel = widget.dataset.moreLabel || 'Read More';
				const readLessLabel = widget.dataset.lessLabel || 'Read Less';

				function getLineHeight(element) {
					const computed = window.getComputedStyle(element);
					let lineHeight = parseFloat(computed.lineHeight);

					if (isNaN(lineHeight)) {
						const fontSize = parseFloat(computed.fontSize) || 16;
						lineHeight = fontSize * 1.4;
					}

					return lineHeight;
				}

				function setCollapsedState() {
					const lineHeight = getLineHeight(content);
					const collapsedHeight = Math.ceil(lineHeight * visibleRows);
					wrap.style.maxHeight = collapsedHeight + 'px';
					btn.textContent = readMoreLabel;
					btn.setAttribute('aria-expanded', 'false');
					widget.classList.remove('open');
				}

				function setExpandedState() {
					wrap.style.maxHeight = content.scrollHeight + 'px';
					btn.textContent = readLessLabel;
					btn.setAttribute('aria-expanded', 'true');
					widget.classList.add('open');
				}

				function initialize() {
					wrap.style.maxHeight = 'none';
					const fullHeight = content.scrollHeight;
					const lineHeight = getLineHeight(content);
					const collapsedHeight = Math.ceil(lineHeight * visibleRows);

					if (fullHeight <= collapsedHeight + 4) {
						wrap.style.maxHeight = 'none';
						btn.style.display = 'none';
						return;
					}

					setCollapsedState();
				}

				btn.addEventListener('click', function () {
					if (widget.classList.contains('open')) {
						setCollapsedState();
					} else {
						setExpandedState();
					}
				});

				window.addEventListener('resize', function () {
					if (widget.classList.contains('open')) {
						wrap.style.maxHeight = content.scrollHeight + 'px';
					} else {
						setCollapsedState();
					}
				});

				initialize();
			});
		});
	</script>
	<?php
} );