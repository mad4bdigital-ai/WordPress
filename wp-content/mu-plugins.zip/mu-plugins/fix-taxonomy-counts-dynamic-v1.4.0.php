<?php
/**
 * Plugin Name: Fix Taxonomy Counts Dynamic - Safe Tools
 * Description: Admin-only taxonomy count repair tools with edit-tags.php inline actions, dry-run cleanup, scoped SQL rebuild, hierarchical rollup rebuild, limited debug output, and optional cache purge.
 * Author: OpenAI
 * Version: 1.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( defined( 'NK_TAX_COUNT_TOOLS_ENABLED' ) && ! NK_TAX_COUNT_TOOLS_ENABLED ) {
    return;
}

if ( ! class_exists( 'NK_Fix_Taxonomy_Counts_Dynamic_Safe' ) ) {
    final class NK_Fix_Taxonomy_Counts_Dynamic_Safe {
        private const CAPABILITY   = 'manage_options';
        private const MENU_SLUG    = 'nk-taxonomy-count-tools';
        private const ACTION_HOOK  = 'nk_tax_count_action';
        private const NONCE_ACTION = 'nk_tax_count_tools';

        private string $current_lang = '';
        private string $current_return_url = '';

        public function __construct() {
            add_action( 'init', [ $this, 'force_count_callback' ], 100 );

            if ( is_admin() ) {
                add_action( 'admin_menu', [ $this, 'register_tools_page' ] );
                add_action( 'admin_notices', [ $this, 'render_edit_tags_inline_tools' ] );
                add_action( 'admin_post_' . self::ACTION_HOOK, [ $this, 'handle_action' ] );
            }
        }

        private function tools_enabled(): bool {
            return ! defined( 'NK_TAX_COUNT_TOOLS_ENABLED' ) || (bool) NK_TAX_COUNT_TOOLS_ENABLED;
        }

        public function register_tools_page(): void {
            if ( ! $this->tools_enabled() || ! current_user_can( self::CAPABILITY ) ) {
                return;
            }

            add_management_page(
                'Taxonomy Count Tools',
                'Taxonomy Count Tools',
                self::CAPABILITY,
                self::MENU_SLUG,
                [ $this, 'render_tools_page' ]
            );
        }

        private function get_context_from_request(): array {
            $taxonomy  = '';
            $post_type = '';

            if ( isset( $_REQUEST['nktc_taxonomy'] ) ) {
                $taxonomy = sanitize_key( wp_unslash( (string) $_REQUEST['nktc_taxonomy'] ) );
            } elseif ( isset( $_REQUEST['taxonomy'] ) ) {
                $taxonomy = sanitize_key( wp_unslash( (string) $_REQUEST['taxonomy'] ) );
            }

            if ( isset( $_REQUEST['nktc_post_type'] ) ) {
                $post_type = sanitize_key( wp_unslash( (string) $_REQUEST['nktc_post_type'] ) );
            } elseif ( isset( $_REQUEST['post_type'] ) ) {
                $post_type = sanitize_key( wp_unslash( (string) $_REQUEST['post_type'] ) );
            }

            $lang = $this->get_lang_from_request();

            if ( $taxonomy && ! taxonomy_exists( $taxonomy ) ) {
                $taxonomy = '';
            }

            if ( $post_type && ! post_type_exists( $post_type ) ) {
                $post_type = '';
            }

            if ( ! $post_type && $taxonomy ) {
                $post_type = $this->guess_post_type_for_taxonomy( $taxonomy );
            }

            return [ 'taxonomy' => $taxonomy, 'post_type' => $post_type, 'lang' => $lang ];
        }

        private function get_context_for_screen(): array {
            $taxonomy  = '';
            $post_type = '';

            if ( isset( $_REQUEST['nktc_taxonomy'] ) ) {
                $taxonomy = sanitize_key( wp_unslash( (string) $_REQUEST['nktc_taxonomy'] ) );
            } elseif ( isset( $_REQUEST['taxonomy'] ) ) {
                $taxonomy = sanitize_key( wp_unslash( (string) $_REQUEST['taxonomy'] ) );
            }

            if ( isset( $_REQUEST['nktc_post_type'] ) ) {
                $post_type = sanitize_key( wp_unslash( (string) $_REQUEST['nktc_post_type'] ) );
            } elseif ( isset( $_REQUEST['post_type'] ) ) {
                $post_type = sanitize_key( wp_unslash( (string) $_REQUEST['post_type'] ) );
            }

            $lang = $this->get_lang_from_request();

            if ( $taxonomy && ! taxonomy_exists( $taxonomy ) ) {
                $taxonomy = '';
            }
            if ( $post_type && ! post_type_exists( $post_type ) ) {
                $post_type = '';
            }

            if ( ! $post_type && $taxonomy ) {
                $post_type = $this->guess_post_type_for_taxonomy( $taxonomy );
            }

            return [ 'taxonomy' => $taxonomy, 'post_type' => $post_type, 'lang' => $lang ];
        }

        private function get_lang_from_request(): string {
            $lang = '';

            if ( isset( $_REQUEST['nktc_lang'] ) ) {
                $lang = sanitize_text_field( wp_unslash( (string) $_REQUEST['nktc_lang'] ) );
            } elseif ( isset( $_REQUEST['lang'] ) ) {
                $lang = sanitize_text_field( wp_unslash( (string) $_REQUEST['lang'] ) );
            }

            $lang = preg_replace( '/[^A-Za-z0-9_\-]/', '', $lang );
            return is_string( $lang ) ? $lang : '';
        }

        private function guess_post_type_for_taxonomy( string $taxonomy ): string {
            $tax = get_taxonomy( $taxonomy );
            if ( ! $tax || empty( $tax->object_type ) || ! is_array( $tax->object_type ) ) {
                return '';
            }

            foreach ( $tax->object_type as $object_type ) {
                if ( post_type_exists( $object_type ) && $object_type !== 'attachment' ) {
                    return (string) $object_type;
                }
            }

            return '';
        }

        public function force_count_callback(): void {
            global $wp_taxonomies;

            $context  = $this->get_context_for_screen();
            $taxonomy = $context['taxonomy'];

            if ( $taxonomy && isset( $wp_taxonomies[ $taxonomy ] ) ) {
                $wp_taxonomies[ $taxonomy ]->update_count_callback = '_update_post_term_count';
            }
        }

        public function render_edit_tags_inline_tools(): void {
            global $pagenow;

            if ( ! $this->tools_enabled() || ! current_user_can( self::CAPABILITY ) ) {
                return;
            }

            if ( 'edit-tags.php' !== (string) $pagenow ) {
                return;
            }

            $context   = $this->get_context_for_screen();
            $taxonomy  = $context['taxonomy'];
            $post_type = $context['post_type'];
            $lang      = $context['lang'];

            if ( ! $taxonomy ) {
                return;
            }

            $return_url = $this->edit_tags_url( $taxonomy, $post_type, $lang );

            echo '<div class="notice notice-info" style="padding:12px 14px;">';
            echo '<p style="margin:0 0 8px;"><strong>Taxonomy Count Tools</strong> — Context from current page: taxonomy <code>' . esc_html( $taxonomy ) . '</code>';
            if ( $post_type ) {
                echo ' | post type <code>' . esc_html( $post_type ) . '</code>';
            }
            if ( $lang ) {
                echo ' | lang <code>' . esc_html( $lang ) . '</code>';
            }
            echo '</p>';
            echo '<div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;">';
            $this->render_action_button( 'recount', 'Recount via WordPress', $taxonomy, $post_type, false, false, $lang, $return_url );
            if ( $post_type ) {
                $this->render_action_button( 'rebuild_sql_counts', 'Rebuild SQL Direct Counts', $taxonomy, $post_type, false, false, $lang, $return_url );
                if ( is_taxonomy_hierarchical( $taxonomy ) ) {
                    $this->render_action_button( 'rebuild_hierarchical_counts', 'Rebuild Hierarchical Rollup Counts', $taxonomy, $post_type, false, false, $lang, $return_url );
                }
            }
            $this->render_action_button( 'debug', 'Debug Relationships', $taxonomy, $post_type, false, false, $lang, $return_url );
            $this->render_action_button( 'cleanup_orphans', 'Dry-run Cleanup Orphans', $taxonomy, $post_type, true, false, $lang, $return_url );
            $this->render_action_button( 'cleanup_orphans', 'Run Cleanup Orphans', $taxonomy, $post_type, false, true, $lang, $return_url );
            echo '<a class="button" href="' . esc_url( $this->tools_url( $taxonomy, $post_type, $lang ) ) . '">Open full tools page</a>';
            echo '</div>';
            echo '<p style="margin:8px 0 0;color:#646970;">Use this directly on taxonomy pages like <code>edit-tags.php?taxonomy={taxonomy}&amp;post_type={post_type}&amp;lang={lang}</code>.</p>';
            echo '</div>';
        }

        public function render_tools_page(): void {
            if ( ! current_user_can( self::CAPABILITY ) ) {
                wp_die( 'Unauthorized request.' );
            }

            $context   = $this->get_context_from_request();
            $taxonomy  = $context['taxonomy'];
            $post_type = $context['post_type'];
            $lang      = $context['lang'];
            $taxes      = get_taxonomies( [ 'show_ui' => true ], 'objects' );
            $post_types = get_post_types( [ 'show_ui' => true ], 'objects' );
            unset( $post_types['attachment'] );

            echo '<div class="wrap"><h1>Taxonomy Count Tools</h1>';
            echo '<p>Use dry-run first. SQL rebuild counts published posts only. Hierarchical rollup includes child terms in parent counts. Orphan cleanup is scoped to the selected taxonomy.</p>';

            echo '<form method="get" action="' . esc_url( admin_url( 'tools.php' ) ) . '">';
            echo '<input type="hidden" name="page" value="' . esc_attr( self::MENU_SLUG ) . '">';
            if ( $lang ) {
                echo '<input type="hidden" name="lang" value="' . esc_attr( $lang ) . '">';
            }
            echo '<table class="form-table" role="presentation">';
            echo '<tr><th><label for="nktc_taxonomy">Taxonomy</label></th><td><select name="nktc_taxonomy" id="nktc_taxonomy">';
            echo '<option value="">Select taxonomy</option>';
            foreach ( $taxes as $slug => $obj ) {
                echo '<option value="' . esc_attr( $slug ) . '" ' . selected( $taxonomy, $slug, false ) . '>' . esc_html( $slug ) . '</option>';
            }
            echo '</select></td></tr>';
            echo '<tr><th><label for="nktc_post_type">Post type</label></th><td><select name="nktc_post_type" id="nktc_post_type">';
            echo '<option value="">Auto / select post type</option>';
            foreach ( $post_types as $slug => $obj ) {
                echo '<option value="' . esc_attr( $slug ) . '" ' . selected( $post_type, $slug, false ) . '>' . esc_html( $slug ) . '</option>';
            }
            echo '</select></td></tr>';
            echo '</table>';
            submit_button( 'Load tools', 'secondary', '', false );
            echo '</form>';

            if ( ! $taxonomy ) {
                echo '</div>';
                return;
            }

            echo '<hr><h2>Selected context</h2>';
            echo '<p>Taxonomy: <code>' . esc_html( $taxonomy ) . '</code> | Post type: <code>' . esc_html( $post_type ?: '(auto)' ) . '</code>' . ( $lang ? ' | Lang: <code>' . esc_html( $lang ) . '</code>' : '' ) . '</p>';
            echo '<p><strong>Note:</strong> SQL rebuild counts published posts only. Hierarchical rollup counts posts assigned to the selected term or any child term.</p>';

            $this->render_action_button( 'recount', 'Recount via WordPress', $taxonomy, $post_type, false, false, $lang );
            if ( $post_type ) {
                $this->render_action_button( 'rebuild_sql_counts', 'Rebuild via SQL Direct Counts', $taxonomy, $post_type, false, false, $lang );
                if ( is_taxonomy_hierarchical( $taxonomy ) ) {
                    $this->render_action_button( 'rebuild_hierarchical_counts', 'Rebuild Hierarchical Rollup Counts', $taxonomy, $post_type, false, false, $lang );
                }
            }
            $this->render_action_button( 'debug', 'Debug Relationships', $taxonomy, $post_type, false, false, $lang );
            $this->render_action_button( 'cleanup_orphans', 'Dry-run Cleanup Orphans', $taxonomy, $post_type, true, false, $lang );
            $this->render_action_button( 'cleanup_orphans', 'Run Cleanup Orphans', $taxonomy, $post_type, false, true, $lang );
            echo '</div>';
        }

        private function render_action_button( string $tool_action, string $label, string $taxonomy, string $post_type, bool $dry_run = false, bool $confirm = false, string $lang = '', string $return_url = '' ): void {
            echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block;margin:0 8px 8px 0;">';
            wp_nonce_field( self::NONCE_ACTION );
            echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION_HOOK ) . '">';
            echo '<input type="hidden" name="nktc_action" value="' . esc_attr( $tool_action ) . '">';
            echo '<input type="hidden" name="nktc_taxonomy" value="' . esc_attr( $taxonomy ) . '">';
            echo '<input type="hidden" name="nktc_post_type" value="' . esc_attr( $post_type ) . '">';
            if ( $lang ) {
                echo '<input type="hidden" name="nktc_lang" value="' . esc_attr( $lang ) . '">';
            }
            if ( $return_url ) {
                echo '<input type="hidden" name="nktc_return_url" value="' . esc_url( $return_url ) . '">';
            }
            if ( $dry_run ) {
                echo '<input type="hidden" name="dry_run" value="1">';
            }
            if ( $confirm ) {
                echo '<input type="hidden" name="confirm_cleanup" value="1">';
            }
            submit_button( $label, $confirm ? 'delete' : 'secondary', '', false, $confirm ? [ 'onclick' => "return confirm('Delete orphaned relationships for this taxonomy? Run dry-run first.');" ] : [] );
            echo '</form>';
        }

        public function handle_action(): void {
            if ( ! is_admin() || ! current_user_can( self::CAPABILITY ) ) {
                wp_die( 'Unauthorized request.' );
            }

            check_admin_referer( self::NONCE_ACTION );

            $context   = $this->get_context_from_request();
            $taxonomy  = $context['taxonomy'];
            $post_type = $context['post_type'];
            $lang      = $context['lang'];
            $action    = isset( $_POST['nktc_action'] ) ? sanitize_key( wp_unslash( (string) $_POST['nktc_action'] ) ) : '';

            $this->current_lang       = $lang;
            $this->current_return_url = $this->get_return_url_from_request( $taxonomy, $post_type, $lang );

            if ( ! $taxonomy ) {
                wp_die( 'No valid taxonomy selected.' );
            }

            switch ( $action ) {
                case 'recount':
                    $this->recount_via_wordpress( $taxonomy, $post_type );
                    break;
                case 'rebuild_sql_counts':
                    $this->rebuild_counts_via_sql( $taxonomy, $post_type );
                    break;
                case 'rebuild_hierarchical_counts':
                    $this->rebuild_hierarchical_counts_via_sql( $taxonomy, $post_type );
                    break;
                case 'cleanup_orphans':
                    $this->cleanup_orphan_relationships( $taxonomy, $post_type, ! empty( $_POST['dry_run'] ), ! empty( $_POST['confirm_cleanup'] ) );
                    break;
                case 'debug':
                    $this->debug_output( $taxonomy, $post_type );
                    break;
                default:
                    wp_die( 'Unknown taxonomy count action.' );
            }
        }

        private function recount_via_wordpress( string $taxonomy, string $post_type ): void {
            $term_ids = get_terms( [ 'taxonomy' => $taxonomy, 'hide_empty' => false, 'fields' => 'ids' ] );
            if ( is_wp_error( $term_ids ) ) {
                wp_die( 'Error loading terms: ' . esc_html( $term_ids->get_error_message() ) );
            }
            if ( ! empty( $term_ids ) ) {
                wp_update_term_count_now( $term_ids, $taxonomy );
                clean_term_cache( $term_ids, $taxonomy, false );
            }
            $this->flush_caches( $taxonomy, $term_ids );
            $this->done_page( 'Recount Complete', 'WordPress recount finished for taxonomy: ' . $taxonomy, $taxonomy, $post_type );
        }

        private function rebuild_counts_via_sql( string $taxonomy, string $post_type ): void {
            global $wpdb;
            if ( ! $post_type ) {
                wp_die( 'No valid post type selected.' );
            }

            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT term_id, term_taxonomy_id FROM {$wpdb->term_taxonomy} WHERE taxonomy = %s",
                $taxonomy
            ), ARRAY_A );

            if ( empty( $rows ) ) {
                wp_die( 'No term_taxonomy rows found.' );
            }

            $statuses            = $this->get_counted_post_statuses( $taxonomy, $post_type );
            $status_placeholders = $this->get_published_status_placeholders( $statuses );
            $updated             = [];
            $term_ids            = [];
            foreach ( $rows as $row ) {
                $term_id          = (int) $row['term_id'];
                $term_taxonomy_id = (int) $row['term_taxonomy_id'];
                $args             = array_merge( [ $term_taxonomy_id, $post_type ], $statuses );
                $count = (int) $wpdb->get_var( $wpdb->prepare(
                    "SELECT COUNT(DISTINCT tr.object_id)
                     FROM {$wpdb->term_relationships} tr
                     INNER JOIN {$wpdb->posts} p ON p.ID = tr.object_id
                     WHERE tr.term_taxonomy_id = %d
                       AND p.post_type = %s
                       AND p.post_status IN ($status_placeholders)",
                    $args
                ) );
                $wpdb->update( $wpdb->term_taxonomy, [ 'count' => $count ], [ 'term_taxonomy_id' => $term_taxonomy_id ], [ '%d' ], [ '%d' ] );
                $updated[ $term_taxonomy_id ] = $count;
                $term_ids[] = $term_id;
            }

            clean_term_cache( array_unique( $term_ids ), $taxonomy, false );
            $this->flush_caches( $taxonomy, $term_ids );

            echo '<div class="wrap"><h1>SQL Rebuild Complete</h1>';
            echo '<p>Counts were rebuilt for taxonomy <code>' . esc_html( $taxonomy ) . '</code> and post type <code>' . esc_html( $post_type ) . '</code>.</p>';
            echo '<p>Counted statuses: <code>' . esc_html( implode( ', ', $statuses ) ) . '</code>.</p><ul>';
            foreach ( $updated as $tt_id => $count ) {
                echo '<li><code>term_taxonomy_id ' . esc_html( (string) $tt_id ) . '</code> → <strong>' . esc_html( (string) $count ) . '</strong></li>';
            }
            echo '</ul><p><a class="button button-primary" href="' . esc_url( $this->action_return_url( $taxonomy, $post_type ) ) . '">Back to tools</a></p></div>';
            exit;
        }

        private function get_published_status_placeholders( array $statuses ): string {
            return implode( ', ', array_fill( 0, count( $statuses ), '%s' ) );
        }

        private function get_counted_post_statuses( string $taxonomy, string $post_type ): array {
            $statuses = apply_filters( 'nk_tax_count_post_statuses', [ 'publish' ], $taxonomy, $post_type );
            if ( ! is_array( $statuses ) || empty( $statuses ) ) {
                $statuses = [ 'publish' ];
            }

            $statuses = array_values( array_unique( array_filter( array_map( 'sanitize_key', $statuses ) ) ) );
            return ! empty( $statuses ) ? $statuses : [ 'publish' ];
        }

        private function collect_descendant_term_ids( int $term_id, array $children_by_parent ): array {
            $ids   = [ $term_id ];
            $stack = $children_by_parent[ $term_id ] ?? [];

            while ( ! empty( $stack ) ) {
                $child_id = (int) array_pop( $stack );
                $ids[]    = $child_id;

                if ( ! empty( $children_by_parent[ $child_id ] ) ) {
                    foreach ( $children_by_parent[ $child_id ] as $grandchild_id ) {
                        $stack[] = (int) $grandchild_id;
                    }
                }
            }

            return array_values( array_unique( array_map( 'intval', $ids ) ) );
        }

        private function rebuild_hierarchical_counts_via_sql( string $taxonomy, string $post_type ): void {
            global $wpdb;

            if ( ! $post_type ) {
                wp_die( 'No valid post type selected.' );
            }

            if ( ! is_taxonomy_hierarchical( $taxonomy ) ) {
                wp_die( 'Selected taxonomy is not hierarchical.' );
            }

            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT term_id, parent, term_taxonomy_id
                 FROM {$wpdb->term_taxonomy}
                 WHERE taxonomy = %s",
                $taxonomy
            ), ARRAY_A );

            if ( empty( $rows ) ) {
                wp_die( 'No term_taxonomy rows found.' );
            }

            $term_to_tt         = [];
            $children_by_parent = [];
            $term_ids           = [];

            foreach ( $rows as $row ) {
                $term_id          = (int) $row['term_id'];
                $parent_id        = (int) $row['parent'];
                $term_taxonomy_id = (int) $row['term_taxonomy_id'];

                $term_to_tt[ $term_id ] = $term_taxonomy_id;
                $children_by_parent[ $parent_id ][] = $term_id;
                $term_ids[] = $term_id;
            }

            $statuses             = $this->get_counted_post_statuses( $taxonomy, $post_type );
            $status_placeholders  = $this->get_published_status_placeholders( $statuses );
            $updated              = [];

            foreach ( $term_ids as $term_id ) {
                $descendant_term_ids = $this->collect_descendant_term_ids( (int) $term_id, $children_by_parent );
                $descendant_tt_ids   = [];

                foreach ( $descendant_term_ids as $descendant_term_id ) {
                    if ( isset( $term_to_tt[ $descendant_term_id ] ) ) {
                        $descendant_tt_ids[] = (int) $term_to_tt[ $descendant_term_id ];
                    }
                }

                if ( empty( $descendant_tt_ids ) || ! isset( $term_to_tt[ $term_id ] ) ) {
                    continue;
                }

                $tt_placeholders = implode( ', ', array_fill( 0, count( $descendant_tt_ids ), '%d' ) );
                $args            = array_merge( $descendant_tt_ids, [ $post_type ], $statuses );
                $sql             = $wpdb->prepare(
                    "SELECT COUNT(DISTINCT tr.object_id)
                     FROM {$wpdb->term_relationships} tr
                     INNER JOIN {$wpdb->posts} p ON p.ID = tr.object_id
                     WHERE tr.term_taxonomy_id IN ($tt_placeholders)
                       AND p.post_type = %s
                       AND p.post_status IN ($status_placeholders)",
                    $args
                );

                $count            = (int) $wpdb->get_var( $sql );
                $term_taxonomy_id = (int) $term_to_tt[ $term_id ];

                $wpdb->update(
                    $wpdb->term_taxonomy,
                    [ 'count' => $count ],
                    [ 'term_taxonomy_id' => $term_taxonomy_id ],
                    [ '%d' ],
                    [ '%d' ]
                );

                $updated[ $term_taxonomy_id ] = $count;
            }

            clean_term_cache( array_unique( $term_ids ), $taxonomy, false );
            $this->flush_caches( $taxonomy, $term_ids );

            echo '<div class="wrap"><h1>Hierarchical Rollup Rebuild Complete</h1>';
            echo '<p>Counts were rebuilt for taxonomy <code>' . esc_html( $taxonomy ) . '</code> and post type <code>' . esc_html( $post_type ) . '</code>.</p>';
            echo '<p>Each parent count includes posts assigned to that parent or any child term. Counted statuses: <code>' . esc_html( implode( ', ', $statuses ) ) . '</code>.</p><ul>';
            foreach ( $updated as $tt_id => $count ) {
                echo '<li><code>term_taxonomy_id ' . esc_html( (string) $tt_id ) . '</code> → <strong>' . esc_html( (string) $count ) . '</strong></li>';
            }
            echo '</ul><p><a class="button button-primary" href="' . esc_url( $this->action_return_url( $taxonomy, $post_type ) ) . '">Back to tools</a></p></div>';
            exit;
        }

        private function cleanup_orphan_relationships( string $taxonomy, string $post_type, bool $dry_run, bool $confirm ): void {
            global $wpdb;

            $count_sql = $wpdb->prepare(
                "SELECT COUNT(*)
                 FROM {$wpdb->term_relationships} tr
                 INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
                 LEFT JOIN {$wpdb->posts} p ON p.ID = tr.object_id
                 WHERE p.ID IS NULL AND tt.taxonomy = %s",
                $taxonomy
            );
            $count = (int) $wpdb->get_var( $count_sql );

            if ( $dry_run || ! $confirm ) {
                $this->done_page( 'Orphan Cleanup Dry Run', 'Orphaned relationships found for taxonomy ' . $taxonomy . ': ' . $count . '. No rows were deleted.', $taxonomy, $post_type );
            }

            $deleted = (int) $wpdb->query( $wpdb->prepare(
                "DELETE tr
                 FROM {$wpdb->term_relationships} tr
                 INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
                 LEFT JOIN {$wpdb->posts} p ON p.ID = tr.object_id
                 WHERE p.ID IS NULL AND tt.taxonomy = %s",
                $taxonomy
            ) );

            $this->flush_caches( $taxonomy, [] );
            $this->done_page( 'Orphan Cleanup Complete', 'Deleted orphaned relationships for taxonomy ' . $taxonomy . ': ' . $deleted, $taxonomy, $post_type );
        }

        private function debug_output( string $taxonomy, string $post_type ): void {
            global $wpdb, $wp_taxonomies;
            $limit = defined( 'NK_TAX_COUNT_DEBUG_LIMIT' ) ? absint( NK_TAX_COUNT_DEBUG_LIMIT ) : 500;
            $limit = $limit > 0 ? min( $limit, 2000 ) : 500;
            $tax   = get_taxonomy( $taxonomy );

            echo '<div class="wrap"><h1>Taxonomy Count Debug</h1>';
            echo '<h2>Registration</h2><pre>';
            print_r( [
                'taxonomy'              => $taxonomy,
                'post_type'             => $post_type,
                'taxonomy_exists'       => taxonomy_exists( $taxonomy ),
                'post_type_exists'      => $post_type ? post_type_exists( $post_type ) : false,
                'object_type'           => $tax ? $tax->object_type : null,
                'update_count_callback' => isset( $wp_taxonomies[ $taxonomy ]->update_count_callback ) ? $wp_taxonomies[ $taxonomy ]->update_count_callback : null,
                'debug_limit'           => $limit,
            ] );
            echo '</pre>';

            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT t.term_id, t.name, t.slug, tt.term_taxonomy_id, tt.taxonomy, tt.count AS stored_count
                 FROM {$wpdb->terms} t
                 INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_id = t.term_id
                 WHERE tt.taxonomy = %s
                 ORDER BY t.name ASC
                 LIMIT %d",
                $taxonomy,
                $limit
            ), ARRAY_A );
            echo '<h2>Stored Term Counts</h2><pre>'; print_r( $rows ); echo '</pre>';

            $relationships = $wpdb->get_results( $wpdb->prepare(
                "SELECT t.name AS term_name, t.slug, tt.term_taxonomy_id, p.ID, p.post_title, p.post_type, p.post_status
                 FROM {$wpdb->term_relationships} tr
                 INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
                 INNER JOIN {$wpdb->terms} t ON t.term_id = tt.term_id
                 INNER JOIN {$wpdb->posts} p ON p.ID = tr.object_id
                 WHERE tt.taxonomy = %s
                 ORDER BY t.name ASC, p.post_type ASC, p.post_status ASC, p.ID DESC
                 LIMIT %d",
                $taxonomy,
                $limit
            ), ARRAY_A );
            echo '<h2>Actual Relationships, limited</h2><pre>'; print_r( $relationships ); echo '</pre>';

            if ( $post_type ) {
                $statuses            = $this->get_counted_post_statuses( $taxonomy, $post_type );
                $status_placeholders = $this->get_published_status_placeholders( $statuses );
                $sql_counts = $wpdb->get_results( $wpdb->prepare(
                    "SELECT t.name AS term_name, t.slug, tt.term_taxonomy_id,
                            COUNT(DISTINCT CASE WHEN p.post_type = %s AND p.post_status IN ($status_placeholders) THEN p.ID END) AS direct_cpt_count,
                            COUNT(DISTINCT p.ID) AS all_related_posts_count
                     FROM {$wpdb->term_taxonomy} tt
                     INNER JOIN {$wpdb->terms} t ON t.term_id = tt.term_id
                     LEFT JOIN {$wpdb->term_relationships} tr ON tr.term_taxonomy_id = tt.term_taxonomy_id
                     LEFT JOIN {$wpdb->posts} p ON p.ID = tr.object_id
                     WHERE tt.taxonomy = %s
                     GROUP BY t.name, t.slug, tt.term_taxonomy_id
                     ORDER BY t.name ASC
                     LIMIT %d",
                    array_merge( [ $post_type ], $statuses, [ $taxonomy, $limit ] )
                ), ARRAY_A );
                echo '<h2>Computed Direct Counts, limited</h2><pre>'; print_r( $sql_counts ); echo '</pre>';

                if ( is_taxonomy_hierarchical( $taxonomy ) ) {
                    $rollup_rows = $this->debug_rollup_counts( $taxonomy, $post_type, $limit );
                    echo '<h2>Computed Hierarchical Rollup Counts, limited</h2><pre>'; print_r( $rollup_rows ); echo '</pre>';
                }
            }

            echo '<p><a class="button button-primary" href="' . esc_url( $this->action_return_url( $taxonomy, $post_type ) ) . '">Back to tools</a></p></div>';
            exit;
        }

        private function debug_rollup_counts( string $taxonomy, string $post_type, int $limit ): array {
            global $wpdb;

            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT t.term_id, t.name, t.slug, tt.parent, tt.term_taxonomy_id, tt.count AS stored_count
                 FROM {$wpdb->terms} t
                 INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_id = t.term_id
                 WHERE tt.taxonomy = %s
                 ORDER BY t.name ASC
                 LIMIT %d",
                $taxonomy,
                $limit
            ), ARRAY_A );

            if ( empty( $rows ) ) {
                return [];
            }

            $all_rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT term_id, parent, term_taxonomy_id
                 FROM {$wpdb->term_taxonomy}
                 WHERE taxonomy = %s",
                $taxonomy
            ), ARRAY_A );

            $term_to_tt         = [];
            $children_by_parent = [];
            foreach ( $all_rows as $row ) {
                $term_id = (int) $row['term_id'];
                $term_to_tt[ $term_id ] = (int) $row['term_taxonomy_id'];
                $children_by_parent[ (int) $row['parent'] ][] = $term_id;
            }

            $statuses            = $this->get_counted_post_statuses( $taxonomy, $post_type );
            $status_placeholders = $this->get_published_status_placeholders( $statuses );
            $out                 = [];

            foreach ( $rows as $row ) {
                $descendant_term_ids = $this->collect_descendant_term_ids( (int) $row['term_id'], $children_by_parent );
                $descendant_tt_ids   = [];

                foreach ( $descendant_term_ids as $descendant_term_id ) {
                    if ( isset( $term_to_tt[ $descendant_term_id ] ) ) {
                        $descendant_tt_ids[] = (int) $term_to_tt[ $descendant_term_id ];
                    }
                }

                if ( empty( $descendant_tt_ids ) ) {
                    $row['computed_rollup_count'] = 0;
                    $row['descendant_terms_seen'] = 0;
                    $out[] = $row;
                    continue;
                }

                $tt_placeholders = implode( ', ', array_fill( 0, count( $descendant_tt_ids ), '%d' ) );
                $args            = array_merge( $descendant_tt_ids, [ $post_type ], $statuses );
                $sql             = $wpdb->prepare(
                    "SELECT COUNT(DISTINCT tr.object_id)
                     FROM {$wpdb->term_relationships} tr
                     INNER JOIN {$wpdb->posts} p ON p.ID = tr.object_id
                     WHERE tr.term_taxonomy_id IN ($tt_placeholders)
                       AND p.post_type = %s
                       AND p.post_status IN ($status_placeholders)",
                    $args
                );

                $row['computed_rollup_count'] = (int) $wpdb->get_var( $sql );
                $row['descendant_terms_seen'] = count( $descendant_term_ids );
                $out[] = $row;
            }

            return $out;
        }

        private function flush_caches( string $taxonomy = '', array $term_ids = [] ): void {
            if ( $taxonomy && function_exists( 'clean_taxonomy_cache' ) ) {
                clean_taxonomy_cache( $taxonomy );
            }
            if ( $taxonomy && ! empty( $term_ids ) ) {
                clean_term_cache( array_map( 'intval', $term_ids ), $taxonomy, false );
            }
            if ( defined( 'NK_TAX_COUNT_ALLOW_FULL_CACHE_PURGE' ) && NK_TAX_COUNT_ALLOW_FULL_CACHE_PURGE ) {
                if ( function_exists( 'wp_cache_flush' ) ) {
                    wp_cache_flush();
                }
                do_action( 'litespeed_purge_all' );
            }
        }

        private function get_return_url_from_request( string $taxonomy, string $post_type, string $lang = '' ): string {
            $fallback = $this->tools_url( $taxonomy, $post_type, $lang );

            if ( empty( $_POST['nktc_return_url'] ) ) {
                return $fallback;
            }

            $url = esc_url_raw( wp_unslash( (string) $_POST['nktc_return_url'] ) );
            return wp_validate_redirect( $url, $fallback );
        }

        private function action_return_url( string $taxonomy, string $post_type ): string {
            if ( $this->current_return_url ) {
                return $this->current_return_url;
            }

            return $this->tools_url( $taxonomy, $post_type, $this->current_lang );
        }

        private function done_page( string $title, string $message, string $taxonomy, string $post_type ): void {
            $back_url = $this->action_return_url( $taxonomy, $post_type );

            echo '<div class="wrap"><h1>' . esc_html( $title ) . '</h1><p>' . esc_html( $message ) . '</p>';
            echo '<p><a class="button button-primary" href="' . esc_url( $back_url ) . '">Back to current taxonomy page</a> ';
            echo '<a class="button" href="' . esc_url( $this->tools_url( $taxonomy, $post_type, $this->current_lang ) ) . '">Open full tools page</a></p></div>';
            exit;
        }

        private function tools_url( string $taxonomy, string $post_type, string $lang = '' ): string {
            $args = [
                'page'           => self::MENU_SLUG,
                'nktc_taxonomy'  => $taxonomy,
                'nktc_post_type' => $post_type,
            ];

            if ( $lang ) {
                $args['lang'] = $lang;
            }

            return add_query_arg( $args, admin_url( 'tools.php' ) );
        }

        private function edit_tags_url( string $taxonomy, string $post_type, string $lang = '' ): string {
            $args = [ 'taxonomy' => $taxonomy ];

            if ( $post_type ) {
                $args['post_type'] = $post_type;
            }

            if ( $lang ) {
                $args['lang'] = $lang;
            }

            return add_query_arg( $args, admin_url( 'edit-tags.php' ) );
        }
    }

    new NK_Fix_Taxonomy_Counts_Dynamic_Safe();
}
