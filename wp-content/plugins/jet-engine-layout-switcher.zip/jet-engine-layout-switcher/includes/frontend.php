<?php
namespace Jet_Engine_Layout_Switcher;

class Frontend {

	private $current_template = array();

	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_scripts' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_styles' ) );

		add_action( 'jet-engine/listings/preview-scripts', array( $this, 'enqueue_preview_scripts' ) );

		add_filter( 'jet-engine/listing/render/default-settings',  array( $this, 'update_listing_default_settings' ) );
		add_filter( 'jet-engine/listing/grid/nav-widget-settings', array( $this, 'update_listing_nav_widget_settings' ), 10, 2 );

		add_action( 'wp_ajax_jet_engine_switch_layout',        array( $this, 'switch_layout' ) );
		add_action( 'wp_ajax_nopriv_jet_engine_switch_layout', array( $this, 'switch_layout' ) );

		add_filter( 'jet-engine/listing/render/jet-listing-grid/settings', array( $this, 'maybe_apply_layout_settings' ) );
		// The AJAX handler can build its render settings before the
		// before-call-handler hook updates $_REQUEST. Apply the authorized
		// target to the actual render settings too, not only the nav receipt.
		add_filter( 'jet-engine/listing/render/jet-listing-grid/settings', array( $this, 'apply_authorized_render_layout' ), 30 );

		add_filter( 'jet-engine/listing/listing-id',          array( $this, 'setup_layout_listing' ), 0, 2 );
		add_filter( 'jet-engine/listing/listing-id',          array( $this, 'authorized_listing_id_for_switch' ), 20, 2 );
		add_filter( 'jet-engine/listing/container-classes',   array( $this, 'update_container_classes' ), 0, 2 );
		add_filter( 'jet-engine/listing/grid/add-query-data', array( $this, 'add_query_data' ), 10, 2 );

		add_action( 'jet-engine/query-builder/query/after-query-setup', array( $this, 'set_filtered_query_on_switch_layout' ) );
		add_filter( 'jet-engine/listing/grid/posts-query-args',         array( $this, 'update_query_on_switch_layout' ), 10, 3 );

		add_action( 'jet-engine/ajax-handlers/before-call-handler', array( $this, 'apply_authorized_ajax_layout' ), 5, 2 );

		// JetThemeCore compatibility hooks
		add_action( 'jet-theme-core/theme-builder/render/location/before', array( $this, 'set_current_template' ), 10, 3 );

		$locations = array(
			'header', 'footer', 'single', 'page', 'archive', 'products-archive', 'products-card',
			'account-page', 'products-checkout-endpoint', 'single-product', 'products-checkout',
		);

		foreach ( $locations as $location ) {
			add_filter( "jet-theme-core/theme-builder/render/{$location}-location/after", array( $this, 'reset_current_template' ) );
		}

		add_filter( 'jet-engine-layout-switcher/current-post-id', array( $this, 'maybe_update_current_post_id' ) );
	}

	/** Match Render's slug without loading its frontend-only render base in AJAX. */
	private function get_authorized_layout_slug( array $layout ) {
		if ( ! empty( $layout['slug'] ) ) $value = $layout['slug'];
		elseif ( ! empty( $layout['label'] ) ) $value = $layout['label'];
		elseif ( ! empty( $layout['_id'] ) ) $value = 'layout-' . $layout['_id'];
		elseif ( ! empty( $layout['id'] ) ) $value = 'layout-' . $layout['id'];
		else $value = 'layout-' . md5( json_encode( $layout ) );
		return str_replace( ' ', '-', preg_replace( '/[^a-z0-9\\s\\-\\_]/', '', remove_accents( strtolower( (string) $value ) ) ) );
	}

	/** Resolve a layout from its published owner after core request validation. */
	public function apply_authorized_ajax_layout( $handler, $request ) {
		if ( empty( $request['switch_layout'] ) || 'get_listing' !== ( $request['handler'] ?? '' ) ) return;
		$settings = is_array( $request['widget_settings'] ?? null ) ? $request['widget_settings'] : array();
		$result = $this->resolve_authorized_ajax_layout( $request, $settings );
		if ( is_wp_error( $result ) ) wp_send_json_error( 'Invalid declared layout' );
		$_REQUEST['widget_settings'] = $result;
	}

	/** The client supplies a selector only, never a new authorized configuration. */
	public function resolve_authorized_ajax_layout( array $request, array $settings ) {
		$fail = new \WP_Error( 'invalid_declared_layout', 'Invalid declared layout' );
		$document_id = absint( $request['layout_document'] ?? 0 );
		$widget_id = is_scalar( $request['layout_widget'] ?? null ) ? (string) $request['layout_widget'] : '';
		$slug = is_scalar( $request['layout_slug'] ?? null ) ? (string) $request['layout_slug'] : '';
		if ( ! $document_id || 'publish' !== get_post_status( $document_id ) || ! $widget_id || ! $slug ) return $fail;
		$nodes = json_decode( (string) get_post_meta( $document_id, '_elementor_data', true ), true );
		if ( ! is_array( $nodes ) ) return $fail;
		$widget = null; $switchers = array();
		$walk = function( $items ) use ( &$walk, &$widget, &$switchers, $widget_id ) {
			foreach ( $items as $node ) {
				if ( ( $node['id'] ?? '' ) === $widget_id && 'jet-listing-grid' === ( $node['widgetType'] ?? '' ) ) $widget = $node['settings'] ?? array();
				if ( 'jet-engine-layout-switcher' === ( $node['widgetType'] ?? '' ) && (string) ( $node['settings']['widget_id'] ?? '' ) === $widget_id ) $switchers[] = $node['settings'];
				if ( ! empty( $node['elements'] ) ) $walk( $node['elements'] );
			}
		};
		$walk( $nodes );
		if ( ! $widget || (string) ( $settings['_id'] ?? '' ) !== $widget_id ||
			absint( $widget['lisitng_id'] ?? 0 ) !== absint( $settings['lisitng_id'] ?? 0 ) ||
			(string) ( $widget['custom_query_id'] ?? '' ) !== (string) ( $settings['custom_query_id'] ?? '' ) ) return $fail;
		$selected = null;
		foreach ( $switchers as $switcher ) foreach ( (array) ( $switcher['layouts'] ?? array() ) as $layout ) {
			if ( $this->get_authorized_layout_slug( $layout ) === $slug ) { $selected = $layout; break 2; }
		}
		if ( ! $selected ) return $fail;
		$target = ! empty( $selected['is_default_layout'] ) ? absint( $widget['lisitng_id'] ) : absint( $selected['lisitng_id'] ?? $widget['lisitng_id'] );
		if ( ! $target || 'publish' !== get_post_status( $target ) || 'jet-engine' !== get_post_type( $target ) || absint( $request['layout_listing'] ?? 0 ) !== $target ) return $fail;
		$settings['_layout_listing'] = $target;
		// Only authored presentation keys can alter the validated base payload.
		foreach ( array( '', '_widescreen', '_laptop', '_tablet_extra', '_tablet', '_mobile', '_mobile_extra' ) as $suffix ) {
			foreach ( array( 'columns', 'column_min_width' ) as $prefix ) {
				$key = $prefix . $suffix;
				if ( isset( $selected[$key] ) && is_scalar( $selected[$key] ) && is_numeric( $selected[$key] ) ) $settings[$key] = $selected[$key];
			}
		}
		return $settings;
	}

	/**
	 * Resolve only an existing published Elementor switcher target for actual
	 * JetEngine rendering. The user-supplied listing ID is NEVER authoritative.
	 */
	public function apply_authorized_render_layout( $settings ) {
		if ( ! is_array( $settings ) || empty( $_REQUEST['switch_layout'] ) ||
			( $_REQUEST['handler'] ?? '' ) !== 'get_listing' ||
			! isset( $settings['_id'] ) || ! isset( $_REQUEST['layout_widget'] ) ||
			(string) $settings['_id'] !== (string) $_REQUEST['layout_widget'] ) {
			return $settings;
		}
		$base = $_REQUEST['widget_settings'] ?? array();
		if ( ! is_array( $base ) ) { return $settings; }
		$authorized = $this->resolve_authorized_ajax_layout( $_REQUEST, $base );
		if ( is_wp_error( $authorized ) || empty( $authorized['_layout_listing'] ) ) {
			return $settings;
		}
		$settings['_layout_listing'] = absint( $authorized['_layout_listing'] );
		return $settings;
	}

	/**
	 * JetEngine can resolve listing ID before the render/settings hook runs.
	 * Guarantee the target template on the real listing-ID boundary, too.
	 * Never switch nested card listings or an unknown Elementor widget.
	 */
	public function authorized_listing_id_for_switch( $listing_id, $settings ) {
		if ( empty( $_REQUEST['switch_layout'] ) ||
			( $_REQUEST['handler'] ?? '' ) !== 'get_listing' ||
			! is_array( $settings ) ||
			(string) ( $settings['_id'] ?? '' ) !== (string) ( $_REQUEST['layout_widget'] ?? '' ) ) {
			return $listing_id;
		}
		$base = $_REQUEST['widget_settings'] ?? array();
		if ( ! is_array( $base ) ||
			absint( $base['lisitng_id'] ?? 0 ) !== absint( $settings['lisitng_id'] ?? 0 ) ) {
			return $listing_id;
		}
		$resolved = $this->resolve_authorized_ajax_layout( $_REQUEST, $base );
		if ( is_wp_error( $resolved ) || empty( $resolved['_layout_listing'] ) ) {
			return $listing_id;
		}
		return absint( $resolved['_layout_listing'] );
	}

	public function register_scripts() {
		wp_register_script(
			'jet-engine-layout-switcher',
			JET_ENGINE_LAYOUT_SWITCHER_URL . 'assets/js/layout-switcher.js',
			array( 'jquery', 'jet-engine-frontend' ),
			JET_ENGINE_LAYOUT_SWITCHER_VERSION . '-' . filemtime( JET_ENGINE_LAYOUT_SWITCHER_PATH . 'assets/js/layout-switcher.js' ),
			true
		);
	}

	public function register_styles() {
		wp_register_style(
			'jet-engine-layout-switcher',
			JET_ENGINE_LAYOUT_SWITCHER_URL . 'assets/css/layout-switcher.css',
			array(),
			JET_ENGINE_LAYOUT_SWITCHER_VERSION,
		);
	}

	public function enqueue_preview_scripts() {
		wp_enqueue_style( 'jet-engine-layout-switcher' );
		//wp_enqueue_script( 'jet-engine-layout-switcher' );
	}

	public function update_listing_default_settings( $settings ) {
		$settings['_id'] = '';
		$settings['_layout_listing'] = '';
		return $settings;
	}

	public function update_listing_nav_widget_settings( $result, $settings ) {
		$result['_id'] = ! empty( $settings['_id'] ) ? $settings['_id'] : '';
		$result['_layout_listing'] = ! empty( $settings['_layout_listing'] ) ? $settings['_layout_listing'] : '';
		return $result;
	}

	public function switch_layout() {
		$widget_id = ! empty( $_REQUEST['widget_id'] ) ? $_REQUEST['widget_id'] : false;
		$layout    = ! empty( $_REQUEST['layout'] ) ? $_REQUEST['layout'] : false;
		$view      = ! empty( $_REQUEST['view'] ) ? $_REQUEST['view'] : '';

		if ( empty( $widget_id ) || empty( $layout ) ) {
			wp_send_json_error();
		}

		$cookie_val = array(
			'layout' => $layout,
			'view'   => $view,
		);

		setcookie(
			'jet_engine_layout_' . esc_attr( $widget_id ),
			json_encode( $cookie_val ),
			time() + MONTH_IN_SECONDS,
			COOKIEPATH ? COOKIEPATH : '/',
			COOKIE_DOMAIN,
			( false !== strstr( get_option( 'home' ), 'https:' ) && is_ssl() ),
			true
		);

		wp_send_json_success();
	}

	public function maybe_apply_layout_settings( $settings ) {

		if ( ! empty( $settings['lazy_load'] ) ) {
			return $settings;
		}

		// Break on load more
		if ( jet_engine()->listings->is_listing_ajax( 'listing_load_more' ) ) {
			return $settings;
		}

		// Break on switch layout
		if ( ! empty( $_REQUEST['switch_layout'] ) ) {
			return $settings;
		}

		$widget_id = ! empty( $settings['_id'] ) ? $settings['_id'] : false;

		// Get the widget id on lazy load
		if ( ! $widget_id && ! empty( $_REQUEST['action'] ) && 'jet_engine_ajax' === $_REQUEST['action']
			 && ! empty( $_REQUEST['handler'] ) && 'get_listing' === $_REQUEST['handler']
			 && ! empty( $_REQUEST['element_id'] )
		) {
			$widget_id = $_REQUEST['element_id'];
		}

		if ( ! $widget_id ) {
			return $settings;
		}

		$cookie_key = 'jet_engine_layout_' . esc_attr( $widget_id );

		if ( ! isset( $_COOKIE[ $cookie_key ] ) ) {
			return $settings;
		}

		$cookie_value = isset( $_COOKIE[ $cookie_key ] ) ? json_decode( wp_unslash( $_COOKIE[ $cookie_key ] ), true ) : false;

		if ( empty( $cookie_value ) || empty( $cookie_value['layout'] ) ) {
			return $settings;
		}

		$view = ! empty( $cookie_value['view'] ) ? $cookie_value['view'] : 'elementor';
		$view_instance = jet_engine_layout_switcher()->get_view( $view );

		if ( ! $view_instance ) {
			return $settings;
		}

		if ( $view_instance->is_edit_mode() ) {
			return $settings;
		}

		$relevant_switcher = $view_instance->find_relevant_switcher_on_page( $widget_id );

		if ( ! $relevant_switcher ) {
			return $settings;
		}

		$layouts = ! empty( $relevant_switcher['layouts'] ) ? $relevant_switcher['layouts'] : array();

		if ( empty( $layouts ) ) {
			return $settings;
		}

		$layout_settings = array();

		foreach ( $layouts as $layout ) {
			$slug = Render::get_prepared_slug( $layout );

			if ( $cookie_value['layout'] === $slug ) {
				$layout_settings = $layout;
				break;
			}
		}

		if ( empty( $layout_settings ) ) {
			return $settings;
		}

		if ( ! empty( $layout_settings['is_default_layout'] ) ) {
			return $settings;
		}

		if ( ! empty( $layout_settings['lisitng_id'] ) ) {
			$settings['_layout_listing'] = (int) $layout_settings['lisitng_id'];
		}

		$not_allowed_keys_to_merge = array(
			'label',
			'slug',
			'icon',
			'icon_url',
			'is_default_layout',
			'lisitng_id' // to prevent rewrite initial listing.
		);
		
		foreach ( $not_allowed_keys_to_merge as $not_allowed_key ) {
			if ( isset( $layout_settings[ $not_allowed_key ] ) ) {
				unset( $layout_settings[ $not_allowed_key ] );
			}
		}

		return array_merge( $settings, $layout_settings );
	}

	public function setup_layout_listing( $listing_id, $settings ) {

		if ( ! empty( $settings['_layout_listing'] ) ) {
			return (int) $settings['_layout_listing'];
		}

		return $listing_id;
	}

	public function update_container_classes( $classes, $settings ) {

		if ( empty( $settings['_layout_listing'] ) ) {
			return $classes;
		}

		$initial_listing_id = $settings['lisitng_id'];

		$classes = array_filter( $classes, function( $class ) use ( $initial_listing_id ) {
			return 'jet-listing-grid--' . $initial_listing_id !== $class;
		} );

		$classes[] = 'jet-listing-grid--' . absint( $settings['_layout_listing'] );

		return $classes;
	}

	public function add_query_data( $add_query_data, $render ) {

		if ( $add_query_data ) {
			return $add_query_data;
		}

		if ( ! empty( $render->listing_query_id ) ) {
			return $add_query_data;
		}

		if ( ! function_exists( 'jet_smart_filters' ) ) {
			return $add_query_data;
		}

		if ( jet_engine()->listings->is_listing_ajax() && ! empty( $_REQUEST['switch_layout'] ) ) {
			return true;
		}

		if ( $this->is_filters_request() ) {
			return true;
		}

		return $add_query_data;
	}

	public function is_filters_request() {

		if ( ! empty( $_REQUEST['action'] ) && 'jet_smart_filters' === $_REQUEST['action'] && ! empty( $_REQUEST['provider'] ) ) {
			return true;
		}

		if ( ! empty( $_REQUEST['jet-smart-filters'] ) ) {
			return true;
		}

		if ( ! empty( $_REQUEST['jsf'] ) ) {
			return true;
		}

		return false;
	}

	public function set_filtered_query_on_switch_layout( $query ) {

		if ( ! jet_engine()->listings->is_listing_ajax() ) {
			return;
		}

		if ( empty( $_REQUEST['switch_layout'] ) || empty( $_REQUEST['listing_query_id'] ) ) {
			return;
		}

		$l_query_id = intval( $_REQUEST['listing_query_id'] );
		$query_id   = intval( $query->id );

		if ( $l_query_id !== $query_id ) {
			return;
		}

		if ( function_exists( 'jet_smart_filters' ) && ! empty( $_REQUEST['filtered_query'] ) ) {
			$filtered_query = jet_smart_filters()->query->get_query_from_request( $_REQUEST['filtered_query'] );

			if ( empty( $filtered_query['jet_smart_filters'] ) && ! empty( $_REQUEST['filter_provider'] ) ) {
				$filtered_query['jet_smart_filters'] = esc_attr( $_REQUEST['filter_provider'] );
			}

			if ( ! empty( $filtered_query ) ) {
				foreach ( $filtered_query as $prop => $value ) {
					$query->set_filtered_prop( $prop, $value );
				}
			}
		}

		// Load more props
		if ( ! empty( $_REQUEST['loadMorePages'] ) && ! empty( $query->final_query['posts_per_page'] ) ) {
			$first_page = intval( $_REQUEST['loadMorePages']['first'] );
			$last_page  = intval( $_REQUEST['loadMorePages']['last'] );

			$per_page    = absint( $query->final_query['posts_per_page'] );
			$offset      = ( $first_page - 1 ) * $per_page;
			$items_count = ( $last_page - $first_page + 1 ) * $per_page;

			$query->set_filtered_prop( '_page', 1 );
			$query->set_filtered_prop( 'offset', $offset );
			$query->set_filtered_prop( 'posts_per_page', $items_count );
		}
	}

	public function update_query_on_switch_layout( $args, $render, $settings ) {

		if ( ! jet_engine()->listings->is_listing_ajax() ) {
			return $args;
		}

		if ( empty( $_REQUEST['switch_layout'] ) ) {
			return $args;
		}

		if ( empty( $_REQUEST['query'] ) || empty( $_REQUEST['widget_settings'] ) ) {
			return $args;
		}

		if ( ! isset( $settings['_id'] ) || ! isset( $_REQUEST['widget_settings']['_id'] ) ) {
			return $args;
		}

		if ( $settings['_id'] !== $_REQUEST['widget_settings']['_id'] ) {
			return $args;
		}

		$args = wp_unslash( $_REQUEST['query'] );

		if ( isset( $args['suppress_filters'] ) ) {
			$args['suppress_filters'] = filter_var( $args['suppress_filters'], FILTER_VALIDATE_BOOLEAN );
		}

		return $args;
	}

	public function set_current_template( $location, $template_id, $content_type ) {
		$this->current_template = array(
			'template_id'  => $template_id,
			'location'     => $location,
			'content_type' => $content_type,
		);
	}

	public function reset_current_template() {
		$this->current_template = array();
	}

	public function maybe_update_current_post_id( $post_id ) {

		if ( empty( $this->current_template ) ) {
			return $post_id;
		}

		if ( empty( $this->current_template['template_id'] ) ) {
			return $post_id;
		}

		return $this->current_template['template_id'];
	}

}
