<?php
/**
 * Silence is golden
 */
