Changelog
=========

1.2.0 (2023-03-22)
- Updated How To videos
- Added Lithuanian language translations
- Updated assets
- Redirect from Hostinger dashboard into plugin

1.3.0 (2023-04-11)
- Autocomplete onboarding steps
- Redirect Hosting clients by segment
- Hide logo upload step if theme not support
- Updated How To videos
- Updated translations
- Updated onboarding steps

1.4.0 (2023-04-17)
- Added new "Add product" step
- Adjusted onboarding steps by website type
- Updated logo upload step
- Autocomplete site title step on settings change

1.4.1 (2023-05-15)
- Fix site health session warning

1.5.0 (2023-05-23)
- Add onboarding steps autocomplete date

1.6.0 (2023-06-08)
- Add plugin update feature

1.6.1 (2023-06-13)
- Fixed unused assets
- Fixed maintenance mode cache

1.6.2 (2023-06-15)
- Fixed maintenance mode conflicts with other plugins

1.6.3 (2023-07-11)
- Add AI assistant

1.6.4 (2023-08-08)
- Add additional AI assistant buttons

1.6.5 (2023-08-14)
- Add translations

1.6.6 (2023-08-17)
- Add additional submenu items

1.6.7 (2023-09-08)
- Bugfixes
- Redirect all users from hPanel
- Text changes

1.7.0 (2023-09-08)
- Add CSAT survey

1.7.1 (2023-09-20)
- Add additional request header

1.7.2 (2023-09-22)
- Hide notices in Hostinger page

1.8.0 (2023-09-27)
- Additional amplitude events

1.8.1 (2023-10-03)
- Remove video iframes

1.8.2 (2023-10-05)
- Adjust CSAT survey

1.8.3 (2023-10-13)
- Add domain connection step
- Hide preview banner

1.8.4 (2023-10-20)
- Added regenerate website tab
- Style corrections

1.8.5 (2023-10-20)
- Text corrections

1.8.6 (2023-10-23)
- Translations

1.8.7 (2023-10-30)
- Add WooCommerce onboarding survey

1.8.8 (2023-11-13)
- Bugfixes

1.8.9 (2023-11-14)
- Added onboarding survey
- Fix onboarding steps duplicates

1.9.0 (2023-11-15)
- Fix survey transients

1.9.1 (2023-11-15)
- Add translations

1.9.2 (2023-11-19)
- Fixes

1.9.3 (2023-11-21)
- Fixed RTL survey issues
- Added survey close button

1.9.4 (2023-11-23)
- Fix survey requests

1.9.5 (2023-11-27)
- Hide notices in Hostinger page
- Remove surveys

1.9.6 (2023-12-01)
- Added filter for tabs / tab content

1.9.7 (2023-12-13)
- Added tests, adjusted assets loading
- Fixed maintenance security issue

1.9.8 (2023-12-14)
- Version mismatch fix

1.9.9 (2023-12-18)
- Fixed assets load on subfolder installations

2.0.0 (2024-01-10)
- Increased minimal WordPress version

2.0.1 (2024-01-16)
- Added onboarding step for affiliate plugin

2.0.2 (2024-01-19)
- Updated internal services

2.0.3 (2024-01-19)
- Fixes
- Added promotional banner

2.0.4 (2024-02-02)
- Added jump to hPanel
- Redesign tabs section

2.0.5 (2024-02-06)
- Added surveys

2.0.6 (2024-02-09)
- Added affiliate surveys
- Internal services improvements

2.0.7 (2024-02-13)
- Survey adjustments

2.0.8 (2024-02-14)
- Fixed files loading

2.0.9 (2024-02-20)
- Astra theme compatibility
- Internal services improvements

2.1.0 (2024-03-04)
- Lower WordPress version requirement
- Added "Omnisend" plugin upgrade promo message

2.1.1 (2024-03-08)
- Changed "Omnisend" promo appearance conditions

2.1.2 (2024-03-13)
- Removed sessions

2.1.3 (2024-03-14)
- Refactored codebase

2.1.4 (2024-03-14)
- Removed vendors

2.1.5 (2024-03-16)
- Fixed Namespace issues

2.1.6 (2024-03-18)
- CSS fixes

2.1.7 (2024-03-27)
- Improved internal services
- Added links to hPanel in admin bar
- Fixed hPanel redirect to subdomain

2.1.8 (2024-03-29)
- Assets compatibility fix

2.1.9 (2024-04-03)
- CSAT survey improvements

2.2.0 (2024-04-15)
- Compatibility fixes

2.2.1 (2024-04-16)
- Fixed loading issues

2.2.2 (2024-04-17)
- "Omnisend" authentication fix

2.2.3 (2024-05-08)
- Increased minimum PHP version

2.2.4 (2024-05-13)
- Update prebuilt websites

3.0.0 (2024-05-30)
- Renamed plugin to Hostinger Tools
- Added check WordPress and PHP versions
- Added ability to enable/disable maintenance mode and get bypass link
- Added ability to enable/disable XML-RPC
- Added ability to force redirects to HTTPS and WWW URLs
- Moved Onboarding steps and Learning section to separate plugin Hostinger Easy Onboarding

3.0.1 (2024-06-06)
- Added skeleton loader for UI
- Removed hPanel links from admin bar menu

3.0.2 (2024-06-19)
- Updated menu package

3.0.3 (2024-07-02)
- Added tests

3.0.4 (2024-07-09)
- Vendor autoload fix

3.0.5 (2024-07-24)
- PHP version card change
- Translations

3.0.6 (2024-07-30)
- Added CLI commands descriptions

3.0.7 (2024-07-31)
- Added plugin split notice to plugin UI

3.0.8 (2024-08-27)
- Updated recommended PHP version

3.0.9 (2024-08-04)
- Added conditional check for maintenance class CLI

3.0.10 (2024-09-11)
- Update packages

3.0.11 (2024-09-13)
- Fix logo visibility

3.0.12 (2024-10-01)
- Fix maintenance mode cache issue

3.0.13 (2024-10-09)
- Fix `force www` row not being shown when user is not eligible to adjust it

3.0.14 (2024-10-11)
- Add tutorial link

3.0.15 (2024-10-18)
- WooCommerce coming soon mode cache flush

3.0.16 (2024-10-22)
- Fix cache LiteSpeed cleaning

3.0.17 (2024-10-24)
- Updated plugin URL by locale

3.0.18 (2024-11-08)
- Remove unused assets
- Remove flush cache duplicates

3.0.19 (2024-11-13)
- Dismiss plugin split notice after close

3.0.20 (2024-12-03)
- Updated packages

3.0.21 (2024-12-09)
- Added recommended PHP version

3.0.22 (2025-01-08)
- Added preview website link in navbar

3.0.23 (2025-02-07)
- Added ability to enable or disable Authorize application page

3.0.24 (2025-02-10)
- Fixed bypass input field visibility

3.0.25 (2025-02-10)
- Added new translations

3.0.26 (2025-02-10)
- Fixed settings update

3.0.27 (2025-02-11)
- Fixed bypass code regeneration

3.0.28 (2025-02-12)
- Added correct reseller link to PHP update

3.0.29 (2025-02-21)
- Update packages

3.0.30 (2025-02-24)
- Enhanced WordPress application security settings

3.0.31 (2025-02-24)
- Fixed assets load issue

3.0.32 (2025-03-04)
- Updated compatibility

3.0.33 (2024-04-04)
- Remove hardcoded references

3.0.34 (2024-04-10)
- Add preview and site edit buttons

3.0.35 (2024-04-28)
- Add edit site button support for block themes

3.0.36 (2024-04-29)
- Style corrections

3.0.37 (2024-05-12)
- Remove unused assets
- Fixed Jetpack autoloader issue
- Added LLMS.txt generation functionality
- Added few new Spanish locales (es_AR, es_CO, es_MX)

3.0.38 (2025-06-09)
- Tweaks the UI for PHP and WordPress version under Tools
- Fallback to Site URL when no Blog Title is set in LLMS.txt
- Clear cache on settings change

3.0.39 (2025-06-12)
- Updated logic to detect 3rd Party LLMs files
- Updated UI and Copy for LLMS section
- Add support for WooCommerce products in LLMS.txt
- Added check for main plugin class to prevent class not found issues
- Update readme.txt tags

3.0.40 (2025-06-17)
- Added latest translations
- Provide visual feedback to user when changing settings 
- Fixed www urls rewrite

3.0.41 (2025-06-19)
- Update translations for ES, MX and CO

3.0.42 (2025-07-03)
- Menu translations 

3.0.43 (2025-07-22)
- Add Web2MCP feature
- Fix Settings state on failure
- Bump dependencies version

3.0.44 (2025-07-23)
- Update translations

3.0.45 (2025-07-28)
- Update WP helper package

3.0.46 (2025-08-05)
- Fixed empty lines in llms.txt


3.0.47 (2025-08-08)
- Add MCP choice
- Updated translations

3.0.48 (2025-08-21)
- Support for MCP optional entry in llms.txt
- Add Learn More in MCP section
- Generate llms.txt entries in the background

3.0.49 (2025-09-05)
- Removed warnings
- UI improvements
- Assets optimization


3.0.50 (2025-09-15)
- Remove plugin split banner

3.0.51 (2025-09-18)
- Feature: Added Cli command for AI discovery features

3.0.52 (2025-09-30)

- Fix:  Settings route
- Dev: Fix release updater
- Tweak: Bump dependencies

3.0.53 (2025-10-09)

- Feature: Learn more destination link changed in LLMS section

3.0.54 (2025-11-20)

- Feature: Update readme
- Fix: Security issue

3.0.55 (2025-12-02)

- Feature: Bump up WP Tested up to Flag
- Dev: Add code automation workflow
- Dev: Bump up package versions

3.0.56 (2025-12-09)

- Feature: Add CTA to copy Web2Agent URL to clipboard

3.0.57 (2026-01-06)

- Tweak: Implement PHP Compat WP
- Feature: Remove MCP settings
- Fix: LLMS file overwrite

3.0.58 (2026-02-10)

- Fix: Minimum php version notice

3.0.59 (2026-03-03)

- Fix: XML RPC disable settings not working
- Fix: Prevent LLMS warning when LLMS is disabled
- Tweak: Bumps up required php version in readme.txt

3.0.60 (2026-03-10)

- Tweak: Update dependencies

3.0.61 (2026-03-31)

- Tweak: Update dependencies
- Dev: Release Workflow Automation

3.0.62 (2026-04-02)

- Tweak:  Update dependencies
- Dev: Update Release automation workflow

3.0.63 (2026-04-07)

- Tweak: Update dependencies

3.0.64 (2026-04-08)

- Dev: Update Deployment Workflow Automations

3.0.65 (2026-04-08)

- Version bump: PATCH

3.0.66 (2026-04-29)

- Feature: Enable application passwords
- Dev: Update Deployment Workflow Automations
- Tweak: Update dependencies
