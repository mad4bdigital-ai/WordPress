<?php
/**
 * Plugin Name: WP All Import - JetEngine Automagic JSON Repeater
 * Description: Automatically converts any valid JSON string imported via WP All Import into a JetEngine repeater format. No UI needed, no functions to type. Just use the standard Custom Fields block!
 * Version: 3.0.0
 * Author: Custom Dev
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'pmxi_saved_post', 'jetengine_automagic_repeater_formatter', 10, 3 );

function jetengine_automagic_repeater_formatter( $post_id, $xml_node, $is_update ) {
    // Get all custom fields for the imported post
    $all_meta = get_post_meta( $post_id );

    foreach ( $all_meta as $meta_key => $meta_values ) {
        if ( ! isset( $meta_values[0] ) ) continue;
        
        $raw_value = $meta_values[0];

        // 1. Automagic Taxonomy Assignment by ID (No prefix needed)
        // If the meta key exactly matches a registered taxonomy name
        if ( taxonomy_exists( $meta_key ) ) {
            
            // Allow multiple IDs separated by commas, pipes, semicolons, or spaces
            $term_ids = preg_split( '/[,|;\s]+/', $raw_value, -1, PREG_SPLIT_NO_EMPTY );
            // Convert to integers
            $term_ids = array_map( 'intval', array_map( 'trim', $term_ids ) );
            // Filter out empty/0 values
            $term_ids = array_filter( $term_ids );
            
            if ( ! empty( $term_ids ) ) {
                // Assign terms natively (false means it will replace existing terms, true would append)
                wp_set_object_terms( $post_id, $term_ids, $meta_key, false );
            }
            
            // Clean up the temporary meta field so it doesn't pollute the database
            delete_post_meta( $post_id, $meta_key );
            continue; // Move to next field
        }

        // 2. Automagic JSON Repeater Converter
        // Clean slashes
            $clean_string = stripslashes( $raw_value );

            // Check if it looks like a JSON object or array
            $trimmed = trim( $clean_string );
            if ( strpos( $trimmed, '{' ) === 0 || strpos( $trimmed, '[' ) === 0 ) {
                
                // Attempt to decode
                $decoded = json_decode( $clean_string, true );
                
                // If it's a valid array/object, we format it for JetEngine
                if ( is_array( $decoded ) ) {
                    $formatted_value = serialize( array_values( $decoded ) );
                    
                    // Update the database directly with the serialized array
                    global $wpdb;
                    $wpdb->update( 
                        $wpdb->postmeta, 
                        array( 'meta_value' => $formatted_value ), 
                        array( 'post_id' => $post_id, 'meta_key' => $meta_key ) 
                    );
                }
            }
        }
    
    // Clean cache
    clean_post_cache( $post_id );
}
