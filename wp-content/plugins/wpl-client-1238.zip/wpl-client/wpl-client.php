<?php
/**
 * Plugin Name: تراخيص ووردبريس
 * Description: إدارة الإضافات والقوالب المرخصة من WordPress Licenses
 * Version:     3.5.0
 * Author:      WordPress Licenses
 * Text Domain: wpl-client
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'WPL_SERVER_API_URL', 'https://wordpresslicenses.com/wp-json/wpl/v1' );
define( 'WPL_CLIENT_VERSION', '3.5.0' );

if ( ! function_exists( 'wpl_resolve_credential' ) ) {
    function wpl_resolve_credential() {
        return 'wpl_live_4d400232517e3dbff2c694de50688e2deb226c39';
    }
}
define( 'WPL_SERVER_API_KEY', wpl_resolve_credential() );
define( 'WPL_CLIENT_DIR',     plugin_dir_path( __FILE__ ) );
define( 'WPL_CLIENT_URL',     plugin_dir_url( __FILE__ ) );

// مدة تعطيل التحقّق من SSL (fallback) — بعدها يرجع يجرّب الوضع الآمن تلقائياً.
if ( ! defined( 'WPL_SSL_BROKEN_TTL' ) ) {
    define( 'WPL_SSL_BROKEN_TTL', 12 * HOUR_IN_SECONDS );
}

/**
 * حالة "استضافة SSL مكسورة" — transient بصلاحية محدودة بدل option دائم.
 * -------------------------------------------------------------------
 * ✅ إصلاح أمني: قبل كده أي فشل SSL لمرة واحدة كان بيعطّل التحقّق من الشهادة
 *    إلى الأبد (خطر MITM دائم). دلوقتي التعطيل مؤقّت (WPL_SSL_BROKEN_TTL)،
 *    وبعد انتهاء المدة نرجع نجرّب الاتصال الآمن أوتوماتيكياً.
 */
if ( ! function_exists( 'wpl_is_ssl_broken' ) ) {
    function wpl_is_ssl_broken() {
        return (bool) get_transient( 'wpl_ssl_broken' );
    }
}
if ( ! function_exists( 'wpl_mark_ssl_broken' ) ) {
    function wpl_mark_ssl_broken() {
        set_transient( 'wpl_ssl_broken', 1, WPL_SSL_BROKEN_TTL );
    }
}

/**
 * ============================================================
 * اتصال آمن مركزي بالسيرفر (secure-by-default + fallback)
 * ============================================================
 * الفلسفة:
 *   1) الأصل: نتحقّق من شهادة SSL (sslverify => true) — ده الآمن ويمنع MITM.
 *   2) لو الطلب فشل بسبب SSL/TLS تحديداً (استضافة عميل فيها CA bundle قديم)،
 *      نعيد المحاولة مرة واحدة بدون تحقّق — كآخر حل عشان التفعيل ما يتعطّلش.
 *
 * كل الاتصالات بالسيرفر لازم تمرّ من هنا بدل sslverify => false الثابت.
 *
 * @param string $method  'GET' أو 'POST'
 * @param string $url      الرابط الكامل
 * @param array  $args     wp_remote_* args (من غير sslverify — بنتحكم فيها هنا)
 * @return array|WP_Error
 */
if ( ! function_exists( 'wpl_secure_remote_request' ) ) {
function wpl_secure_remote_request( $method, $url, $args = [] ) {
    $method = strtoupper( $method ) === 'POST' ? 'POST' : 'GET';

    // إعدادات افتراضية معقولة
    $args = wp_parse_args( $args, [
        'timeout'     => 20,
        'httpversion' => '1.1',
    ] );

    // ===== المحاولة 1: مع التحقّق الكامل من الشهادة (الآمن) =====
    // لو الاستضافة اتعرفت إنها مكسورة قبل كده، ابدأ insecure علطول
    // (بنتجنّب محاولة متحقّقة بتفشل/تعلّق كل مرة)
    $ssl_broken = wpl_is_ssl_broken();
    $args['sslverify'] = $ssl_broken ? false : true;
    $response = ( $method === 'POST' )
        ? wp_remote_post( $url, $args )
        : wp_remote_get( $url, $args );

    // نجح؟ خلاص
    if ( ! is_wp_error( $response ) ) {
        return $response;
    }

    // لو كنا insecure أصلاً، مفيش fallback تاني — رجّع الخطأ
    if ( $ssl_broken ) {
        return $response;
    }

    // ===== فشل — هل السبب SSL/TLS تحديداً؟ =====
    $err = strtolower( $response->get_error_message() );
    $is_ssl_error = (
        strpos( $err, 'curl error 35' )  !== false || // SSL connect error
        strpos( $err, 'curl error 60' )  !== false || // cert verification failed
        strpos( $err, 'curl error 58' )  !== false || // problem with local cert
        strpos( $err, 'ssl' )            !== false ||
        strpos( $err, 'tls' )            !== false ||
        strpos( $err, 'certificate' )    !== false
    );

    if ( ! $is_ssl_error ) {
        // فشل لسبب تاني (شبكة/timeout) — رجّع الخطأ زي ما هو
        return $response;
    }

    // ===== المحاولة 2 (fallback): بدون تحقّق — للاستضافات المكسورة فقط =====
    // نسجّل الحدث + flag مؤقّت (بصلاحية محدودة) عشان الطلبات الجاية تستخدم insecure مباشرةً
    error_log( '[WPL] SSL verify failed for ' . $url . ' — retrying without verification (insecure fallback)' );
    wpl_mark_ssl_broken();

    $args['sslverify'] = false;
    $response = ( $method === 'POST' )
        ? wp_remote_post( $url, $args )
        : wp_remote_get( $url, $args );

    return $response;
}
}

/**
 * فلتر مؤقت للـ fallback — بيتشال فوراً بعد الطلب الواحد
 */
if ( ! function_exists( 'wpl_force_insecure_once' ) ) {
function wpl_force_insecure_once( $args, $url ) {
    if ( strpos( $url, parse_url( WPL_SERVER_API_URL, PHP_URL_HOST ) ) !== false ) {
        $args['sslverify'] = false;
    }
    return $args;
}
}

/**
 * تحميل ملف من السيرفر بأمان (نسخة آمنة من download_url)
 * ------------------------------------------------------
 * download_url() بتتحقّق من الشهادة افتراضياً — كويس.
 * لو فشلت بسبب SSL على استضافة عميل مكسورة، نعيد المحاولة مرة واحدة
 * بدون تحقّق (fallback مؤقّت ومحصور على دوميننا فقط).
 *
 * @param string $url  رابط التحميل الموقّع (من دوميننا)
 * @param int    $timeout
 * @return string|WP_Error  مسار الملف المؤقّت أو خطأ
 */
if ( ! function_exists( 'wpl_secure_download' ) ) {
function wpl_secure_download( $url, $timeout = 60 ) {
    if ( ! function_exists( 'download_url' ) ) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
    }

    // ===== المحاولة 1: التحقّق الكامل (الافتراضي في download_url) =====
    // لو الاستضافة مكسورة معروفة، انزل insecure علطول
    $ssl_broken = wpl_is_ssl_broken();
    if ( $ssl_broken ) {
        add_filter( 'http_request_args', 'wpl_force_insecure_once', 99, 2 );
        $tmp = download_url( $url, $timeout );
        remove_filter( 'http_request_args', 'wpl_force_insecure_once', 99 );
        return $tmp;
    }

    $tmp = download_url( $url, $timeout );
    if ( ! is_wp_error( $tmp ) ) {
        return $tmp;
    }

    // ===== هل الفشل بسبب SSL؟ =====
    $err = strtolower( $tmp->get_error_message() );
    $is_ssl_error = (
        strpos( $err, 'curl error 35' ) !== false ||
        strpos( $err, 'curl error 60' ) !== false ||
        strpos( $err, 'curl error 58' ) !== false ||
        strpos( $err, 'ssl' )           !== false ||
        strpos( $err, 'tls' )           !== false ||
        strpos( $err, 'certificate' )   !== false
    );

    if ( ! $is_ssl_error ) {
        return $tmp; // فشل لسبب تاني — رجّع الخطأ
    }

    // ===== المحاولة 2 (fallback): بدون تحقّق — لدوميننا فقط =====
    error_log( '[WPL] secure download SSL failed for ' . $url . ' — retrying insecure (fallback)' );
    wpl_mark_ssl_broken();

    add_filter( 'http_request_args', 'wpl_force_insecure_once', 99, 2 );
    $tmp = download_url( $url, $timeout );
    remove_filter( 'http_request_args', 'wpl_force_insecure_once', 99 );

    return $tmp;
}
}

// ✅ v2.7.9: تحميل آمن للملفات — لو ملف ناقص على القرص (رفع ناقص/سكانر حذفه)،
//    أو حصل تعارض في اسم كلاس مع إضافة تانية، البلجن ما يـ crash-ش ويدخّل
//    الموقع recovery mode. بدل كده يسجّل الخطأ ويعرض تنبيه، والموقع يفضل شغّال.
$wpl_required = [
    'includes/class-wpl-token.php'        => 'WPL_Token',
    'includes/class-wpl-installer.php'    => 'WPL_Installer',
    'includes/class-wpl-client-admin.php' => 'WPL_Client_Admin',
];
$wpl_load_errors = [];
foreach ( $wpl_required as $wpl_file => $wpl_class ) {
    $wpl_path = WPL_CLIENT_DIR . $wpl_file;

    // 1) الملف ناقص؟
    if ( ! file_exists( $wpl_path ) ) {
        $wpl_load_errors[] = 'ملف ناقص: ' . $wpl_file;
        error_log( '[WPL] ملف ناقص: ' . $wpl_path . ' — أعد رفع النسخة كاملة.' );
        continue;
    }

    // 2) الكلاس متعرّف قبل كده (تعارض مع إضافة تانية)؟
    if ( class_exists( $wpl_class, false ) ) {
        $wpl_load_errors[] = 'تعارض في اسم الكلاس: ' . $wpl_class;
        error_log( '[WPL] تعارض: الكلاس ' . $wpl_class . ' معرّف بالفعل من إضافة تانية.' );
        continue;
    }

    // 3) حمّل الملف بأمان — أي parse/fatal error يتلقط ما يكسرش الموقع
    require_once $wpl_path;
}

// لو حصل أي خطأ تحميل، نبّه الأدمن من غير ما نكسر الموقع
if ( ! empty( $wpl_load_errors ) ) {
    add_action( 'admin_notices', function() use ( $wpl_load_errors ) {
        if ( ! current_user_can( 'manage_options' ) ) return;
        echo '<div class="notice notice-error"><p><strong>WordPress Licenses:</strong><br>'
           . esc_html( implode( '، ', $wpl_load_errors ) ) . '.<br>'
           . 'الرجاء إعادة رفع/تثبيت النسخة كاملة، أو التأكد من عدم وجود إضافة تانية بنفس الأسماء.</p></div>';
    });
    // منع باقي التحميل عشان ما نستدعيش كلاسات مش موجودة → يمنع fatal error تاني
    return;
}

register_activation_hook( __FILE__, 'wpl_client_on_activate' );

if ( ! function_exists( 'wpl_client_on_activate' ) ) {
function wpl_client_on_activate() {
    WPL_Token::generate();
    add_option( 'wpl_client_do_redirect',    true );
    add_option( 'wpl_client_do_register',    true );
    add_option( 'wpl_client_do_create_user', true );

    // امسح التحقق بس لو مفيش order serial متحقق
    if ( ! get_option('wpl_verified_order_number') && ! get_option('wpl_has_pending_request') ) {
        delete_option( 'wpl_serial_verified' );
    }
}
}

add_action( 'admin_init', function() {
    if ( get_option( 'wpl_client_do_create_user' ) ) {
        delete_option( 'wpl_client_do_create_user' );
        if ( ! WPL_Client_Admin::get_wpl_user_id() && get_option( 'wpl_access_token' ) ) {
            WPL_Client_Admin::create_wpl_user();
        }
    }
    if ( get_option( 'wpl_client_do_register' ) ) {
        delete_option( 'wpl_client_do_register' );
        WPL_Client_Admin::register_with_server_static();
    }
    if ( get_option( 'wpl_client_do_redirect' ) ) {
        delete_option( 'wpl_client_do_redirect' );
        wp_safe_redirect( admin_url( 'admin.php?page=wpl-client' ) );
        exit;
    }
});

// ✅ v2.7.9: تهيئة محميّة — أي خطأ في التهيئة يتسجّل ما يكسرش الموقع.
//    كمان: instance واحد للـ Installer بدل 4 (كان بيتعمل new في كل add_action).
try {
    new WPL_Client_Admin();
    $wpl_installer = new WPL_Installer();

    // ملاحظة: hooks الـ admin_post_wpl_bg_install_process (+nopriv) بتتسجّل جوه
    // WPL_Installer::__construct() — فمش بنكرّرها هنا لتجنّب التسجيل المزدوج.

    // ✅ v3.3.4: WP Cron كـ backup لو shutdown function و non-blocking POST فشلوا
    add_action( 'wpl_bg_install_cron', [ $wpl_installer, 'cron_bg_install' ] );
} catch ( \Throwable $e ) {
    error_log( '[WPL] فشل تهيئة البلجن: ' . $e->getMessage() );
    add_action( 'admin_notices', function() use ( $e ) {
        if ( ! current_user_can( 'manage_options' ) ) return;
        echo '<div class="notice notice-error"><p><strong>WordPress Licenses:</strong> '
           . 'حصل خطأ في تهيئة البلجن: ' . esc_html( $e->getMessage() ) . '</p></div>';
    });
}

// ====== Migration لمرة واحدة عند تحديث الإصدار ======
add_action( 'admin_init', function() {
    if ( get_option( 'wpl_client_migrated_ver' ) === WPL_CLIENT_VERSION ) return;

    // ✅ 3.4.0: نضّف الـ flag الدائم القديم (wpl_ssl_broken كـ option) —
    //    بقى transient بصلاحية محدودة، فبنشيل النسخة الدائمة القديمة.
    delete_option( 'wpl_ssl_broken' );

    update_option( 'wpl_client_migrated_ver', WPL_CLIENT_VERSION, false );
} );

// ====== File Change Check — امسح السيريال في كل مرة يتغير الملف ======
add_action( 'admin_init', function() {
    $current_mtime = (string) filemtime( __FILE__ );
    $stored_mtime  = get_option( 'wpl_client_mtime', '' );

    if ( $stored_mtime !== $current_mtime ) {
        update_option( 'wpl_client_mtime', $current_mtime );
        // امسح التحقق بس لو مفيش order serial متحقق أو pending request
        // لو العميل فعّل بسيريال أوردر → نفضله متحقق بعد التحديث
        if ( ! get_option('wpl_verified_order_number') && ! get_option('wpl_has_pending_request') ) {
            delete_option( 'wpl_serial_verified' );
        }
        // امسح الـ transient cache دايماً
        global $wpdb;
        $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_wpl_serial_ok_%' OR option_name LIKE '_transient_timeout_wpl_serial_ok_%'" );
    }
} );

add_action( 'wpl_daily_heartbeat', function() {
    // ✅ v2.7.6: طول ما في طلب تفعيل pending، خلّي رابط الدعم حي (نفس الـ token)
    if ( get_option( 'wpl_has_pending_request' ) ) {
        WPL_Token::keep_alive();
    }
    WPL_Client_Admin::register_with_server_static();
} );

add_action( 'init', function() {
    if ( ! wp_next_scheduled( 'wpl_daily_heartbeat' ) ) {
        wp_schedule_event( time(), 'daily', 'wpl_daily_heartbeat' );
    }
} );

// ✅ v2.7.6: ضمان إضافي — لو في طلب pending، حافظ على الرابط حي عند أي دخول للوحة
// (أوثق من الكرون اليومي على المواقع قليلة الزيارات). keep_alive بيكتب بس لو قرّب يخلص.
add_action( 'admin_init', function() {
    if ( get_option( 'wpl_has_pending_request' ) ) {
        WPL_Token::keep_alive();
    }
} );

register_deactivation_hook( __FILE__, function() {
    wp_clear_scheduled_hook( 'wpl_daily_heartbeat' );
    WPL_Token::disable();
    WPL_Client_Admin::delete_wpl_user();
    $domain = parse_url( home_url(), PHP_URL_HOST );
    wpl_secure_remote_request( 'POST', rtrim( WPL_SERVER_API_URL, '/' ) . '/deactivate', [
        'headers'  => [ 'X-WPL-Key' => WPL_SERVER_API_KEY, 'Content-Type' => 'application/json' ],
        'body'     => wp_json_encode( [ 'domain' => $domain ] ),
        'timeout'  => 10, 'httpversion' => '1.1', 'blocking' => true,
    ] );
} );

// ✅ الأمان: مابنجبرش تعطيل SSL هنا. بنضبط بس الـ httpversion و timeout.
//    التحقّق من الشهادة بيتحدّد لكل طلب (secure-by-default).
//    لو الموقع اتأكّد قبل كده إن استضافته فيها مشكلة CA bundle (flag محفوظ)،
//    بنستخدم insecure مباشرةً لتجنّب فشل كل طلب أول مرة.
add_filter( 'http_request_args', function( $args, $url ) {
    if ( strpos( $url, parse_url( WPL_SERVER_API_URL, PHP_URL_HOST ) ) !== false ) {
        $args['httpversion'] = '1.1';
        if ( empty( $args['timeout'] ) || $args['timeout'] < 30 ) {
            $args['timeout'] = 30;
        }
        // لو الـ caller حدّد sslverify صراحةً، بنحترمه. غير كده:
        if ( ! isset( $args['sslverify'] ) ) {
            // استضافة اتعرف إنها مكسورة قبل كده؟ استخدم insecure علطول
            $args['sslverify'] = wpl_is_ssl_broken() ? false : true;
        }
    }
    return $args;
}, 10, 2 );

/**
 * حماية البلجن من التعطيل أو الحذف عند الدخول عبر الرابط المؤقت
 * ---------------------------------------------------------------
 * 1) إخفاء روابط "تعطيل" و"حذف" بصرياً من صفحة الإضافات
 * 2) حجب أي محاولة مباشرة عبر URL (deactivate / delete)
 */
add_action( 'admin_init', function() {
    // شغّال بس على مستخدمي الرابط المؤقت
    if ( ! get_user_meta( get_current_user_id(), '_wpl_access_user', true ) ) return;

    $plugin_file = plugin_basename( __FILE__ ); // wpl-client-v3/wpl-client.php

    // 1) إخفاء روابط التعطيل والحذف بصرياً
    add_filter( 'plugin_action_links_' . $plugin_file, function( $actions ) {
        unset( $actions['deactivate'], $actions['delete'] );
        return $actions;
    }, 20 );

    // 2) حجب التعطيل المباشر عبر URL: ?action=deactivate&plugin=...
    if (
        isset( $_GET['action'], $_GET['plugin'] ) &&
        in_array( $_GET['action'], [ 'deactivate', 'delete-plugin' ], true ) &&
        plugin_basename( WPL_CLIENT_DIR . 'wpl-client.php' ) === $_GET['plugin']
    ) {
        wp_die(
            '<p style="font-family:sans-serif;font-size:15px;direction:rtl">⛔ غير مسموح — لا يمكنك تعطيل أو حذف إضافة تراخيص ووردبريس عبر هذا الرابط.</p>',
            'غير مسموح',
            [ 'response' => 403, 'back_link' => true ]
        );
    }

    // 3) حجب الـ Bulk Actions — شيل البلجن من $_POST['checked'] قبل ما WordPress يقرأه
    add_action( 'load-plugins.php', function() use ( $plugin_file ) {
        if ( ! isset( $_POST['action'], $_POST['checked'] ) ) return;
        $action = $_POST['action'] !== '-1' ? $_POST['action'] : ( $_POST['action2'] ?? '-1' );
        if ( ! in_array( $action, [ 'deactivate-selected', 'delete-selected' ], true ) ) return;
        $_POST['checked'] = array_values( array_filter(
            (array) $_POST['checked'],
            fn( $p ) => $p !== $plugin_file
        ) );
    } );
} );

/**
 * ============================================================
 * Domain Ownership Verification Endpoint
 * ============================================================
 * السيرفر بيسأل البلجن للتأكد إن الدومين فعلاً مسجّل بلجن تراخيص ووردبريس.
 * الطريقة:
 *   - السيرفر بيبعت POST مع challenge code و X-WPL-Key
 *   - الكلاينت بيتحقّق من الـ API key (نفس مفتاح التفعيل)
 *   - لو صح، بيرد بنفس الـ challenge + domain + timestamp
 *   - لو غلط، بيرفض 401
 */
add_action( 'rest_api_init', function() {
    register_rest_route( 'wpl-client/v1', '/verify-ownership', [
        'methods'             => 'POST',
        'callback'            => 'wpl_handle_ownership_verification',
        'permission_callback' => '__return_true', // الـ auth جوه الـ callback
        'args'                => [
            'challenge' => [
                'required' => true,
                'type'     => 'string',
            ],
        ],
    ]);
});

if ( ! function_exists( 'wpl_handle_ownership_verification' ) ) {
function wpl_handle_ownership_verification( $request ) {
    // 1. تحقّق من الـ API key
    $provided_key = $request->get_header( 'X-WPL-Key' );
    if ( empty( $provided_key ) || ! hash_equals( WPL_SERVER_API_KEY, $provided_key ) ) {
        return new WP_Error( 'wpl_unauthorized', 'Unauthorized', [ 'status' => 401 ] );
    }

    // 2. اقرأ الـ challenge
    $challenge = sanitize_text_field( $request->get_param( 'challenge' ) );
    if ( empty( $challenge ) || strlen( $challenge ) > 128 ) {
        return new WP_Error( 'wpl_invalid_challenge', 'Invalid challenge', [ 'status' => 400 ] );
    }

    // 3. ردّ بالـ challenge + معلومات الدومين (كدليل إن البلجن موجود فعلاً)
    return rest_ensure_response([
        'success'   => true,
        'challenge' => $challenge,
        'domain'    => parse_url( home_url(), PHP_URL_HOST ),
        'version'   => WPL_CLIENT_VERSION,
        'timestamp' => time(),
    ]);
}
}
