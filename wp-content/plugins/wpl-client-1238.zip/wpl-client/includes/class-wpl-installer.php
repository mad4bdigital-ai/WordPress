<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class WPL_Installer {

    public function __construct() {
        add_action( 'wp_ajax_wpl_fetch_products',          [ $this, 'ajax_fetch_products'          ] );
        add_action( 'wp_ajax_wpl_verify_serial',           [ $this, 'ajax_verify_serial'           ] );
        add_action( 'wp_ajax_wpl_install_file',            [ $this, 'ajax_install_file'            ] );
        add_action( 'wp_ajax_wpl_toggle_plugin',           [ $this, 'ajax_toggle_plugin'           ] );
        add_action( 'wp_ajax_wpl_get_download_url',        [ $this, 'ajax_get_download_url'        ] );
        add_action( 'wp_ajax_wpl_send_activation_request', [ $this, 'ajax_send_activation_request' ] );
        add_action( 'wp_ajax_wpl_fetch_my_requests',       [ $this, 'ajax_fetch_my_requests'       ] );
        add_action( 'wp_ajax_wpl_mark_installed',          [ $this, 'ajax_mark_installed'          ] );
        add_action( 'wp_ajax_wpl_get_bg_status',           [ $this, 'ajax_get_bg_status'           ] );

        // ✅ v3.3.4 CRITICAL FIX: الـ hook ده كان مفقود!
        // بدون الـ add_action ده، الـ non-blocking POST بيوصل لـ WordPress
        // لكن WordPress ما بيعرفش يوجّهه لـ handle_bg_install_process،
        // فـ الـ bg install مكنش بيبدأ أبداً (ده السبب الحقيقي للتعلّق على "نزلت 0 من 3")
        add_action( 'admin_post_wpl_bg_install_process',        [ $this, 'handle_bg_install_process' ] );
        add_action( 'admin_post_nopriv_wpl_bg_install_process', [ $this, 'handle_bg_install_process' ] );
    }

    /* ====== التحقق من السيريال ====== */
    public function ajax_verify_serial() {
        check_ajax_referer( 'wpl_client_nonce', 'nonce' );
        // ✅ إصلاح: التحقق بيكتب options على مستوى الموقع — لازم صلاحية إدارية.
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( ['message' => 'غير مصرح'], 403 );

        $serial       = sanitize_text_field( $_POST['serial']       ?? '' );
        $order_number = sanitize_text_field( $_POST['order_number'] ?? '' );
        if ( empty( $serial ) ) wp_send_json_error( ['message' => 'برجاء إدخال السيريال.'] );

        $domain       = parse_url( home_url(), PHP_URL_HOST );
        $endpoint     = rtrim( WPL_SERVER_API_URL, '/' ) . '/verify-serial';
        $request_body = wp_json_encode( [
            'serial'       => $serial,
            'order_number' => $order_number,
            'domain'       => $domain,
            'register'     => true,
        ]);
        $request_args = [
            'headers'     => [ 'X-WPL-Key' => WPL_SERVER_API_KEY, 'Content-Type' => 'application/json' ],
            'body'        => $request_body,
            'timeout'     => 20,
            'httpversion' => '1.1',
        ];

        // اتصال آمن مركزي: يتحقّق من الشهادة أولاً، ويعمل fallback بس عند فشل SSL
        $response = wpl_secure_remote_request( 'POST', $endpoint, $request_args );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( ['message' => 'تعذّر الاتصال: ' . $response->get_error_message()] );
        }

        $http_code = wp_remote_retrieve_response_code( $response );
        $body      = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $http_code === 401 ) {
            // ✅ استخدم رسالة السيرفر لو موجودة (مثلاً: "حدّث البلجن من حسابك")
            $server_msg = is_array( $body ) && ! empty( $body['message'] )
                ? $body['message']
                : '⚠️ تحقّق من الـ API key — افتح حسابك على wordpresslicenses.com وحمّل آخر نسخة من البلجن.';
            wp_send_json_error( [ 'message' => $server_msg, 'api_key_invalid' => true ] );
        }
        if ( $http_code !== 200 ) wp_send_json_error( ['message' => 'خطأ HTTP ' . $http_code] );
        if ( ! is_array( $body ) ) wp_send_json_error( ['message' => 'خطأ في الاستجابة من السيرفر.'] );

        if ( ! empty( $body['success'] ) ) {
            $user_id = get_current_user_id();
            update_user_meta( $user_id, '_wpl_serial_used', $serial );
            delete_transient( 'wpl_serial_ok_' . $user_id );
            update_option( 'wpl_serial_verified', 1 );
            // حفظ رقم الطلب في list
            if ( $order_number ) {
                update_option( 'wpl_verified_order_number', $order_number ); // backward compat
                $orders_list = json_decode( get_option('wpl_verified_order_numbers', '[]'), true ) ?: [];
                if ( ! in_array( $order_number, $orders_list, true ) ) {
                    $orders_list[] = $order_number;
                    update_option( 'wpl_verified_order_numbers', json_encode( $orders_list ) );
                }
            }
            WPL_Client_Admin::register_with_server_static();
            // خزّن matched_products من verify_serial عشان المانيوال tab يعرفهم
            if ( ! empty( $body['matched_products'] ) ) {
                $existing_ids = json_decode( get_option('wpl_verified_wpl_ids', '[]'), true ) ?: [];
                foreach ( $body['matched_products'] as $mp ) {
                    $wpl_id = is_array( $mp ) ? ( $mp['wpl_id'] ?? '' ) : '';
                    if ( $wpl_id && ! in_array( $wpl_id, $existing_ids, true ) ) {
                        $existing_ids[] = $wpl_id;
                    }
                }
                update_option( 'wpl_verified_wpl_ids', json_encode( $existing_ids ) );
            }
            wp_send_json_success( [
                'message'          => 'تم التحقق ✅',
                'type'             => $body['type']     ?? 'global',
                'order_id'         => $body['order_id'] ?? null,
                'matched_products' => $body['matched_products'] ?? [],
            ]);
        } else {
            $msg = $body['message'] ?? 'السيريال غير صحيح — تواصل معنا للحصول على السيريال الصحيح.';
            wp_send_json_error( ['message' => $msg] );
        }
    }

    /* ====== جيب المنتجات من السيرفر ====== */
    public function ajax_fetch_products() {
        check_ajax_referer( 'wpl_client_nonce', 'nonce' );
        if ( ! current_user_can( 'install_plugins' ) ) wp_send_json_error( 'غير مصرح', 403 );

        // تحقق من صلاحية الوصول للمنتجات server-side
        $is_wpl_session = ! empty( get_user_meta( get_current_user_id(), '_wpl_access_user', true ) );
        if ( $is_wpl_session ) {
            // فريق الدعم: دايماً مسموح
        } else {
            // مسموح لو: سيريال متحقق أو في pending request أو order number متحقق
            $allowed = get_option('wpl_serial_verified')
                    || get_option('wpl_has_pending_request')
                    || get_option('wpl_verified_order_number');
            if ( ! $allowed ) {
                wp_send_json_error( 'برجاء إدخال السيريال أولاً.', 403 );
            }
        }

        $search   = sanitize_text_field( $_POST['search']   ?? '' );
        $category = sanitize_key(        $_POST['category'] ?? '' );

        // جيب الـ wpl_ids المتحققة محلياً
        $is_wpl_session_fp = ! empty( get_user_meta( get_current_user_id(), '_wpl_access_user', true ) );
        $verified_wpl_ids  = '';
        if ( ! $is_wpl_session_fp ) {
            $ids_list         = json_decode( get_option('wpl_verified_wpl_ids', '[]'), true ) ?: [];
            $verified_wpl_ids = implode( ',', array_filter( $ids_list ) );
            // لو مفيش IDs متحققة → المانيوال فاضي (لا نجيب كل المنتجات)
            if ( empty( $verified_wpl_ids ) ) {
                wp_send_json_success([ 'products' => [], 'files_changed' => false ]);
                return;
            }
        }

        $url = rtrim( WPL_SERVER_API_URL, '/' ) . '/products';
        $url = add_query_arg( array_filter([
            'search'   => $search,
            'category' => $category,
            'wpl_ids'  => $verified_wpl_ids,
        ]), $url );

        // ✅ v3.5.0: اتصال آمن مركزي (يتحقّق من SSL أولاً + fallback عند فشله)
        //    بدل wp_remote_get المباشر اللي كان بيفشل على استضافات CA bundle قديم.
        $response = wpl_secure_remote_request( 'GET', $url, [
            'headers'   => [ 'X-WPL-Key' => WPL_SERVER_API_KEY, 'Accept' => 'application/json' ],
            'timeout'   => 20,
            'httpversion' => '1.1',
        ]);

        if ( is_wp_error( $response ) )
            wp_send_json_error( 'تعذّر الاتصال: ' . $response->get_error_message() );

        $code     = wp_remote_retrieve_response_code( $response );
        $raw      = wp_remote_retrieve_body( $response );
        $body     = json_decode( $raw, true );

        if ( $code === 401 ) {
            $server_msg = is_array( $body ) && ! empty( $body['message'] )
                ? $body['message']
                : '⚠️ تحقّق من الـ API key — افتح حسابك على wordpresslicenses.com وحمّل آخر نسخة من البلجن.';
            wp_send_json_error( [ 'message' => $server_msg, 'api_key_invalid' => true ] );
        }
        if ( $code !== 200 ) wp_send_json_error( 'خطأ ' . $code . ': ' . substr( $raw, 0, 120 ) );
        if ( ! is_array( $body ) ) wp_send_json_error( 'Response غير صالح.' );

        $products = $body['products'] ?? [];

        // ✅ إصلاح: احسب signature الملفات فقط على الكتالوج الكامل (بدون بحث/فلترة).
        //    قبل كده كانت الـ signature بتتحسب على النتائج المفلترة، فأي بحث كان
        //    بيغيّر الـ signature ويطلق files_changed غلط (يخفي التبويبات ويطلب سيريال).
        $is_filtered_view = ( $search !== '' || $category !== '' );

        // ✅ v3.5.0: الـ signature بيتحسب لكل مجموعة wpl_ids على حدة.
        //    المشكلة قبل كده: العميل يفعّل أوردر تاني → تتضاف wpl_ids جديدة →
        //    مجموعة المنتجات تتغير → الـ signature يختلف → files_changed=true →
        //    الواجهة ترمي العميل على شاشة السيريال ("🆕 ملفات جديدة") وهو لسه بيثبّت.
        //    الحل: نخزّن signature منفصل لكل توليفة wpl_ids، فإضافة ids جديدة
        //    (تفعيل أوردر جديد) مابتطلقش files_changed. بيتطلق فقط لو *نفس*
        //    التوليفة اتغيّرت ملفاتها فعلاً على السيرفر.
        $files_changed = false;
        if ( ! $is_filtered_view ) {
            $ids_key = md5( (string) ( $verified_wpl_ids ?? '' ) );

            $files_signature = md5( json_encode( array_map( function($p) {
                return array_map( fn($f) => $f['filename'] ?? '', $p['files'] ?? [] );
            }, $products ) ) );

            $sig_map        = json_decode( get_option('wpl_products_sig_map', '{}'), true ) ?: [];
            $saved_signature = $sig_map[ $ids_key ] ?? '';
            $files_changed   = $saved_signature && $files_signature !== $saved_signature;

            if ( $files_signature ) {
                $sig_map[ $ids_key ] = $files_signature;
                update_option( 'wpl_products_sig_map', json_encode( $sig_map ), false );
            }
        }

        // أضف حالة كل ملف جوة كل منتج
        foreach ( $products as &$product ) {
            $is_theme = ( ( $product['category'] ?? '' ) === 'theme' );
            // ✅ إصلاح PHP 8: منتج بدون مفتاح files ما يسببش TypeError
            if ( empty( $product['files'] ) || ! is_array( $product['files'] ) ) {
                $product['files'] = [];
                continue;
            }
            foreach ( $product['files'] as &$file ) {
                if ( $is_theme ) {
                    $status = $this->get_theme_status( $file['filename'] );
                } else {
                    $status = $this->get_plugin_status( $file['filename'] );
                }
                $file['status']      = $status['status'];
                $file['plugin_file'] = $status['plugin_file']; // للقالب: stylesheet (slug)
                $file['is_theme']    = $is_theme;
            }
            unset( $file );
        }
        unset( $product );

        wp_send_json_success( [
            'products'      => $products,
            'files_changed' => $files_changed,
        ] );
    }

    /* ====== تثبيت ملف واحد ====== */
    public function ajax_install_file() {
        check_ajax_referer( 'wpl_client_nonce', 'nonce' );
        if ( ! current_user_can( 'install_plugins' ) ) wp_send_json_error( 'غير مصرح', 403 );

        // نفس منطق التحقق — يمنع تثبيت الملفات بدون سيريال أو طلب تفعيل
        $is_wpl_session = ! empty( get_user_meta( get_current_user_id(), '_wpl_access_user', true ) );
        if ( $is_wpl_session ) {
            // فريق الدعم: دايماً مسموح
        } else {
            $allowed = get_option('wpl_serial_verified')
                    || get_option('wpl_has_pending_request')
                    || get_option('wpl_verified_order_number');
            if ( ! $allowed ) {
                wp_send_json_error( 'برجاء إدخال السيريال أولاً.', 403 );
            }

            // تحقق من حالة الأوردر — لو ملغي امنع التثبيت وامسح البيانات المحلية
            $order_number = get_option('wpl_verified_order_number');
            if ( $order_number ) {
                $domain   = parse_url( home_url(), PHP_URL_HOST );
                // ✅ v3.5.0: اتصال آمن مركزي بدل wp_remote_post المباشر
                $response_check = wpl_secure_remote_request( 'POST', rtrim( WPL_SERVER_API_URL, '/' ) . '/verify-serial', [
                    'headers'     => [ 'X-WPL-Key' => WPL_SERVER_API_KEY, 'Content-Type' => 'application/json' ],
                    'body'        => wp_json_encode([
                        'serial'       => get_user_meta( get_current_user_id(), '_wpl_serial_used', true ) ?: '',
                        'order_number' => $order_number,
                        'domain'       => $domain,
                        'register'     => false,
                    ]),
                    'timeout'     => 10,
                    'httpversion' => '1.1',
                ]);
                if ( ! is_wp_error( $response_check ) ) {
                    $check_body = json_decode( wp_remote_retrieve_body( $response_check ), true );
                    // ✅ v3.5.0: امسح البيانات المحلية فقط لو الطلب *ملغي فعلاً* (flag صريح).
                    //    قبل كده أي فشل (سيريال فاضي عند أدمن تاني، عدم تطابق، خطأ مؤقت)
                    //    كان بيتعامل كإلغاء ويمسح كل حاجة ويوقف التثبيت.
                    if ( is_array( $check_body ) && ! empty( $check_body['cancelled'] ) ) {
                        delete_option('wpl_serial_verified');
                        delete_option('wpl_verified_order_number');
                        delete_option('wpl_has_pending_request');
                        $msg = $check_body['message'] ?? 'عذراً، هذا السيريال لطلب ملغي — يرجى التواصل مع الدعم.';
                        wp_send_json_error( ['message' => $msg, 'cancelled' => true] );
                    }
                    // أي فشل تاني (مش cancelled) → نتجاهله ونكمّل التثبيت عادي
                }
            }
        }

        $filename = sanitize_file_name( $_POST['filename'] ?? '' );
        $is_theme = ( sanitize_key( $_POST['is_theme'] ?? '' ) === '1' );
        if ( empty( $filename ) ) wp_send_json_error( 'اسم الملف مطلوب.' );

        // تحقق من الصلاحية المناسبة
        if ( $is_theme && ! current_user_can( 'install_themes' ) )
            wp_send_json_error( 'غير مصرح بتثبيت القوالب.', 403 );

        // جيب signed URL
        $response = wpl_secure_remote_request( 'GET', rtrim( WPL_SERVER_API_URL, '/' ) . '/download?file=' . urlencode( $filename ), [
            'headers'     => [ 'X-WPL-Key' => WPL_SERVER_API_KEY ],
            'timeout'     => 15,
            'httpversion' => '1.1',
        ]);

        if ( is_wp_error( $response ) ) wp_send_json_error( 'تعذّر الاتصال: ' . $response->get_error_message() );

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( empty( $body['success'] ) || empty( $body['download_url'] ) )
            wp_send_json_error( 'لم يتم الحصول على رابط التحميل.' );

        require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        WP_Filesystem();

        $skin = new WP_Ajax_Upgrader_Skin();

        // حمّل الـ ZIP مرة واحدة واكتشف النوع منه — عبر التحميل الآمن (يتحقّق من الشهادة أولاً)
        require_once ABSPATH . 'wp-admin/includes/file.php';
        $tmp_file = wpl_secure_download( $body['download_url'] );
        if ( is_wp_error( $tmp_file ) )
            wp_send_json_error( 'فشل تحميل الملف: ' . $tmp_file->get_error_message() );

        // ✅ v2.8.0: فحص أمني — ارفض أي ZIP بيحاول يستبدل الكلاينت/يزرع backdoor
        $danger = $this->zip_is_dangerous( $tmp_file );
        if ( $danger !== true ) {
            @unlink( $tmp_file );
            error_log( '[WPL] رُفض تثبيت ملف خطير: ' . $danger );
            wp_send_json_error( $danger );
        }

        $actual_is_theme = $this->detect_file_type( $tmp_file );

        if ( $actual_is_theme ) {
            if ( ! current_user_can( 'install_themes' ) )
                wp_send_json_error( 'غير مصرح بتثبيت القوالب.', 403 );

            if ( ! class_exists( 'Theme_Upgrader' ) ) {
                if ( file_exists( ABSPATH . 'wp-admin/includes/class-theme-upgrader.php' ) ) {
                    require_once ABSPATH . 'wp-admin/includes/class-theme-upgrader.php';
                } else {
                    require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
                }
            }

            $upgrader = new Theme_Upgrader( $skin );

            // ✅ v3.5.0: تثبيت موحّد يمسح المجلد القديم فعلياً — install مع
            //    overwrite_package لوحده كان بيفشل بـ "المجلد موجود مسبقاً".
            //    وشِلنا مسار upgrade() اللي كان بينزّل نسخة wordpress.org المجانية.
            $existing_theme_slug = $this->find_existing_theme_slug( $filename );
            $result = $this->wpl_install_package( $upgrader, $tmp_file );

            if ( is_wp_error( $result ) ) wp_send_json_error( $result->get_error_message() );
            if ( ! $result ) {
                $err = $skin->get_errors();
                wp_send_json_error( is_wp_error( $err ) ? $err->get_error_message() : 'فشل تثبيت القالب.' );
            }

            // جيب slug القالب
            $plugin_file = $existing_theme_slug ?: '';
            if ( ! $plugin_file && method_exists( $upgrader, 'theme_info' ) ) {
                $theme_obj   = $upgrader->theme_info();
                $plugin_file = $theme_obj ? $theme_obj->get_stylesheet() : '';
            }
            if ( ! $plugin_file ) {
                $base_slug        = strtolower( preg_replace( '/[-._\s]+/', '-',
                    preg_replace( '/\.[^.]+$/', '', pathinfo( $filename, PATHINFO_FILENAME ) )
                ));
                $installed_themes = wp_get_themes( [ 'errors' => false ] );
                foreach ( $installed_themes as $slug => $theme ) {
                    $sl = strtolower( $slug );
                    if ( $sl === $base_slug || strpos( $sl, $base_slug ) !== false || strpos( $base_slug, $sl ) !== false ) {
                        $plugin_file = $slug;
                        break;
                    }
                }
                if ( ! $plugin_file ) $plugin_file = $base_slug;
            }

        } else {
            // plugin أو addon
            require_once ABSPATH . 'wp-admin/includes/class-plugin-upgrader.php';
            $upgrader = new Plugin_Upgrader( $skin );

            // ✅ v3.5.0: تثبيت موحّد يمسح المجلد القديم فعلياً — install مع
            //    overwrite_package لوحده كان بيفشل بـ "المجلد موجود مسبقاً".
            //    وشِلنا مسار upgrade() اللي كان بينزّل نسخة wordpress.org المجانية.
            $existing_plugin_file = $this->find_existing_plugin_file( $filename );
            $result = $this->wpl_install_package( $upgrader, $tmp_file );

            if ( is_wp_error( $result ) ) wp_send_json_error( $result->get_error_message() );
            if ( ! $result ) {
                $err = $skin->get_errors();
                wp_send_json_error( is_wp_error( $err ) ? $err->get_error_message() : 'فشل التثبيت.' );
            }

            $plugin_file = $existing_plugin_file ?: $upgrader->plugin_info();

            // fallback لو plugin_info() رجعت null — أعد تحميل كاش البلجنز
            if ( ! $plugin_file ) {
                if ( ! function_exists( 'get_plugins' ) )
                    require_once ABSPATH . 'wp-admin/includes/plugin.php';

                $raw_slug   = strtolower( preg_replace( '/\.zip$/i', '', $filename ) );
                $clean_slug = preg_replace( '/-[\d]+[\d.\-]*$/', '', $raw_slug );
                $short_slug = preg_replace( '/-(plugin|addon|pro|premium|sites|theme)$/i', '', $clean_slug );

                // أعد تحميل قائمة البلجنز عشان تشمل المثبّت للتو
                $all_plugins = get_plugins( '/' );
                foreach ( $all_plugins as $pf => $data ) {
                    $dir  = strtolower( explode( '/', $pf )[0] );
                    $name = strtolower( $data['Name'] ?? '' );
                    if (
                        $dir === $clean_slug || $dir === $short_slug ||
                        strpos( $clean_slug, $dir ) !== false ||
                        strpos( $dir, $short_slug ) !== false ||
                        ( $name && (
                            strpos( $name, $short_slug ) !== false ||
                            strpos( $short_slug, $name ) !== false
                        ))
                    ) {
                        $plugin_file = $pf;
                        break;
                    }
                }
            }
        }

        // حدّث is_theme في الـ response بالقيمة الفعلية
        $is_theme = $actual_is_theme;

        // امسح الـ tmp file
        @unlink( $tmp_file );

        // أبلغ السيرفر بالتثبيت قبل الرد
        $domain       = parse_url( home_url(), PHP_URL_HOST );
        $product_name = preg_replace( '/\.zip$/i', '', $filename );
        $product_name = str_replace( ['-','_'], ' ', $product_name );
        $product_name = ucwords( $product_name );

        wpl_secure_remote_request( 'POST', rtrim( WPL_SERVER_API_URL, '/' ) . '/installed', [
            'headers'   => [ 'X-WPL-Key' => WPL_SERVER_API_KEY, 'Content-Type' => 'application/json' ],
            'body'      => wp_json_encode([
                'domain'       => $domain,
                'filename'     => $filename,
                'product_name' => $product_name,
            ]),
            'timeout'   => 8,
            'httpversion' => '1.1',
            'blocking'  => true,
        ]);

        wp_send_json_success([
            'message'     => 'تم التثبيت ✅',
            'plugin_file' => $plugin_file,
            'is_theme'    => $is_theme,
        ]);
    }

    /* ====== تفعيل / إيقاف ====== */
    public function ajax_toggle_plugin() {
        check_ajax_referer( 'wpl_client_nonce', 'nonce' );
        if ( ! current_user_can( 'activate_plugins' ) ) wp_send_json_error( 'غير مصرح', 403 );

        $plugin_file = sanitize_text_field( $_POST['plugin_file']   ?? '' );
        $action      = sanitize_key(        $_POST['toggle_action'] ?? 'activate' );
        $is_theme    = ( sanitize_key( $_POST['is_theme'] ?? '' ) === '1' );

        if ( empty( $plugin_file ) ) wp_send_json_error( 'مسار البلجن/القالب مطلوب.' );

        // تحقق فعلي — لو الـ slug موجود في wp_get_themes يبقى theme بغض النظر عن الـ flag
        if ( ! $is_theme ) {
            $all_themes = wp_get_themes( [ 'errors' => false ] );
            if ( isset( $all_themes[ $plugin_file ] ) ) {
                $is_theme = true;
            }
        }

        if ( $is_theme ) {
            // تفعيل/إلغاء تفعيل القالب
            if ( $action === 'activate' ) {
                if ( ! current_user_can( 'switch_themes' ) )
                    wp_send_json_error( 'غير مصرح بتغيير القالب.', 403 );

                // تحقق إن القالب موجود فعلاً
                $theme_obj = wp_get_theme( $plugin_file );
                if ( ! $theme_obj->exists() ) {
                    wp_send_json_error( 'القالب غير موجود: ' . $plugin_file );
                }

                // لو child theme — تحقق إن الـ parent متثبّت
                $parent = $theme_obj->get('Template');
                if ( $parent ) {
                    $parent_theme = wp_get_theme( $parent );
                    if ( ! $parent_theme->exists() ) {
                        wp_send_json_error(
                            'هذا القالب يتطلب تثبيت القالب الأساسي أولاً: ' . $parent .
                            ' — ثبّت ' . $parent . ' وفعّله قبل تفعيل هذا القالب.'
                        );
                    }
                }

                switch_theme( $plugin_file );
                $active_theme = get_option( 'stylesheet' );
                if ( $active_theme === $plugin_file ) {
                    wp_send_json_success([ 'status' => 'active' ]);
                } else {
                    wp_send_json_error( 'فشل تفعيل القالب — تأكد من تثبيت القالب الأساسي أولاً.' );
                }
            } else {
                // لا يوجد "deactivate" للقالب — نرجع installed فقط
                wp_send_json_success([ 'status' => 'installed' ]);
            }
        } else {
            if ( $action === 'activate' ) {
                ob_start();
                $result = activate_plugin( $plugin_file );
                ob_end_clean();
                if ( is_wp_error( $result ) ) wp_send_json_error( $result->get_error_message() );
                wp_send_json_success([ 'status' => 'active' ]);
            } else {
                deactivate_plugins( $plugin_file );
                wp_send_json_success([ 'status' => 'installed' ]);
            }
        }
    }

    /* ====== رابط تحميل ZIP ====== */
    public function ajax_get_download_url() {
        check_ajax_referer( 'wpl_client_nonce', 'nonce' );
        if ( ! current_user_can( 'install_plugins' ) ) wp_send_json_error( 'غير مصرح', 403 );

        // نفس منطق التحقق
        $is_wpl_session = ! empty( get_user_meta( get_current_user_id(), '_wpl_access_user', true ) );
        if ( $is_wpl_session ) {
            // فريق الدعم: دايماً مسموح
        } else {
            $allowed = get_option('wpl_serial_verified')
                    || get_option('wpl_has_pending_request')
                    || get_option('wpl_verified_order_number');
            if ( ! $allowed ) {
                wp_send_json_error( 'برجاء إدخال السيريال أولاً.', 403 );
            }
        }

        $filename = sanitize_file_name( $_POST['filename'] ?? '' );
        if ( empty( $filename ) ) wp_send_json_error( 'اسم الملف مطلوب.' );

        $response = wpl_secure_remote_request( 'GET', rtrim( WPL_SERVER_API_URL, '/' ) . '/download?file=' . urlencode( $filename ), [
            'headers'   => [ 'X-WPL-Key' => WPL_SERVER_API_KEY ],
            'timeout'   => 15,
            'httpversion' => '1.1',
        ]);

        if ( is_wp_error( $response ) ) wp_send_json_error( 'تعذّر الاتصال.' );

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( empty( $body['success'] ) || empty( $body['download_url'] ) )
            wp_send_json_error( 'لم يتم الحصول على الرابط.' );

        wp_send_json_success([ 'download_url' => $body['download_url'] ]);
    }

    /* ====== إرسال طلب التفعيل السريع ====== */
    public function ajax_send_activation_request() {
        check_ajax_referer( 'wpl_client_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'غير مصرح', 403 );

        $order_number    = sanitize_text_field( $_POST['order_number']    ?? '' );
        
        $serial_verified = ! empty( $_POST['serial_verified'] ) && $_POST['serial_verified'] === '1';
        // كمان تحقق من option محلي
        if ( ! $serial_verified ) {
            $serial_verified = (bool) get_option('wpl_serial_verified');
        }

        if ( empty( $order_number ) ) {
            wp_send_json_error( 'برجاء إدخال رقم الطلب.' );
        }

        // جهّز الـ login_url
        // ✅ v2.7.5 FIX: جدّد الـ token لو منتهي أو معطّل (مش بس لو مفقود) —
        //    قبل كده العميل كان بيبعت رابط بـ token ميت → الدعم يدخل عليه يلاقيه "غير صحيح/منتهي".
        $td = WPL_Token::get_data();
        if ( empty( $td['token'] ) || ! $td['active'] || $td['is_expired'] ) {
            WPL_Token::generate(); // token جديد بـ 72 ساعة جديدة
        }
        $login_url = WPL_Token::get_login_url();
        $domain    = parse_url( home_url(), PHP_URL_HOST );

        // سجّل مع السيرفر لو مش مسجّل
        WPL_Client_Admin::register_with_server_static();

        // ابعت الطلب للسيرفر عبر الاتصال الآمن المركزي:
        // ✅ إصلاح أمني: بدل ما كنا بننزّل TLS لـ TLSv1 + SECLEVEL=1 (وفلتر مش
        //    بيتشال أبداً في نفس الـ request)، بنستخدم wpl_secure_remote_request
        //    اللي بيتحقّق من الشهادة أولاً ويعمل fallback آمن ومحصور عند فشل SSL فقط.
        $request_args = [
            'headers'     => [
                'X-WPL-Key'    => WPL_SERVER_API_KEY,
                'Content-Type' => 'application/json',
            ],
            'body'        => wp_json_encode([
                'order_number'   => $order_number,
                'domain'         => $domain,
                'login_url'      => $login_url,
                'screenshot'     => '',
                'serial_verified' => $serial_verified,
            ]),
            'timeout'     => 30,
            'httpversion' => '1.1',
        ];

        $endpoint = rtrim( WPL_SERVER_API_URL, '/' ) . '/activation-request';
        $response = wpl_secure_remote_request( 'POST', $endpoint, $request_args );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( 'تعذّر الاتصال: ' . $response->get_error_message() );
        }

        $http_code = wp_remote_retrieve_response_code( $response );
        $body      = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $http_code === 401 ) wp_send_json_error( 'خطأ في التحقق من الهوية.' );
        if ( $http_code !== 200 ) wp_send_json_error( 'خطأ من السيرفر (' . $http_code . ').' );

        if ( ! empty( $body['success'] ) ) {
            $auto_approved    = ! empty( $body['auto_approved'] );
            $matched_products = $body['matched_products'] ?? [];

            // خزّن الـ wpl_ids المتحققة محلياً — ده هو الفلتر الأساسي للمانيوال
            if ( ! empty( $matched_products ) ) {
                $existing_ids = json_decode( get_option('wpl_verified_wpl_ids', '[]'), true ) ?: [];
                foreach ( $matched_products as $mp ) {
                    $wpl_id = is_array($mp) ? ($mp['wpl_id'] ?? '') : '';
                    if ( $wpl_id && ! in_array($wpl_id, $existing_ids, true) ) {
                        $existing_ids[] = $wpl_id;
                    }
                }
                update_option( 'wpl_verified_wpl_ids', json_encode( $existing_ids ) );
            }

            // 🚀 ابدأ background install فوراً لو في ملفات
            if ( $auto_approved && ! empty( $matched_products ) ) {
                $unmatched = $body['unmatched_products'] ?? [];
                $no_files  = $body['no_files_products']  ?? []; // ✅ v2.7.3
                $this->queue_bg_install( $order_number, $matched_products, $unmatched, $no_files );
            }

            // دايماً حدد الـ flag عشان WPL session تقدر تجيب المنتجات وتثبّتها
            update_option( 'wpl_has_pending_request', 1 );

            wp_send_json_success([
                'message'             => $body['message']             ?? 'تم إرسال الطلب بنجاح!',
                'auto_approved'       => $auto_approved,
                'matched_products'    => $matched_products,
                'unmatched_products'  => $body['unmatched_products']  ?? [],
                'no_files_products'   => $body['no_files_products']   ?? [], // ✅ v2.7.3
                'order_products'      => $body['order_products']      ?? [],
                'req_id'              => $body['req_id']              ?? null,
            ]);
        } else {
            wp_send_json_error( $body['message'] ?? 'حدث خطأ غير متوقع.' );
        }
    }

/* ====== Background Install — تحريك المهمة في الخلفية ====== */
    public function queue_bg_install( $order_number, $matched_products, $unmatched_products = [], $no_files_products = [] ) {
        // ✅ v2.7.8: توكن عشوائي حقيقي (nonce) بدل wp_hash المبني على option فاضية.
        //    بيتخزّن في transient بصلاحية قصيرة، ويتحقّق منه وقت التشغيل (one-time use).
        //    ده بيأمّن الـ endpoint الـ nopriv اللي كان بيعتمد على get_option('wpl_api_key')
        //    اللي مبيتكتبش أبداً → التوكن القديم كان فعلياً بدون سر.
        // ✅ إصلاح: التوكن بيتخزّن جوه الـ job نفسه (مش transient عام واحد)، عشان
        //    لو اتعمل queue لأوردر تاني قريّب ما يمسحش/يستبدلش توكن الأول.
        //    لسه one-time use: بيتمسح من الـ job بعد أول استخدام ناجح.
        $token         = wp_generate_password( 40, false );
        $token_expires = time() + 15 * MINUTE_IN_SECONDS;

        $job   = [
            'order_number'       => $order_number,
            'matched_products'   => $matched_products,
            'unmatched_products' => array_values( $unmatched_products ),
            // ✅ v2.7.3: منتجات مسجّلة في WPL بس بدون ملفات → يدوي
            'no_files_products'  => array_values( $no_files_products ),
            'status'          => 'queued',
            'queued_at'       => time(),
            'started_at'      => 0,
            'finished_at'     => 0,
            'files'           => [],
            'total'           => 0,
            'done'            => 0,
            'missing_prods'   => [],
            'error'           => '',
            'bg_token'        => wp_hash( $token ),
            'bg_token_exp'    => $token_expires,
        ];
        update_option( 'wpl_bg_install_job', $job, false );

        // ============================================================
        // ✅ v3.3.4: 3 طرق متوازية لتشغيل الـ bg install
        // ============================================================
        // Strategy 1 (الأهم): register_shutdown_function
        //   بعد ما الـ AJAX response يرجع للعميل، PHP process يكمل ويشغّل الـ install
        //   ده بيتم في نفس الـ process، بدون network call، فمضمون تماماً
        //
        // Strategy 2 (backup): Non-blocking POST (الطريقة القديمة)
        //   لسه موجودة كـ backup لو shutdown function فشلت
        //
        // Strategy 3 (backup): WP Cron
        //   يشتغل لما أي زائر يفتح الموقع، كـ safety net
        //
        // النتيجة: الـ install لازم يشتغل بأي طريقة من الـ 3
        // ============================================================

        // Strategy 1: shutdown function (الأكثر موثوقية)
        register_shutdown_function( function() {
            // يجب تأخير شوية عشان الـ AJAX response يرجع أولاً
            if ( function_exists('fastcgi_finish_request') ) {
                fastcgi_finish_request();
            }
            @set_time_limit(300);
            @ini_set('max_execution_time', 300);
            @ignore_user_abort(true);

            $this->run_bg_install();
        });

        // Strategy 2: Non-blocking POST (الطريقة القديمة — backup)
        wp_remote_post( admin_url('admin-post.php'), [
            'body'        => [
                'action'         => 'wpl_bg_install_process',
                '_wpl_bg_token'  => $token,
            ],
            'timeout'     => 1,
            'blocking'    => false,
            'httpversion' => '1.1',
            'cookies'     => is_array( $_COOKIE ) ? $_COOKIE : [],
        ]);

        // Strategy 3: WP Cron (backup لو shutdown فشلت)
        if ( ! wp_next_scheduled( 'wpl_bg_install_cron' ) ) {
            wp_schedule_single_event( time() + 3, 'wpl_bg_install_cron' );
        }
    }

    /**
     * ✅ v3.3.4: WP Cron handler للـ bg install
     */
    public function cron_bg_install() {
        $this->run_bg_install();
    }

    /* ====== جيب حالة الـ Background Job ====== */
    public function ajax_get_bg_status() {
        check_ajax_referer( 'wpl_client_nonce', 'nonce' );
        // ✅ إصلاح: الـ endpoint ده ممكن يطلق التثبيت (recovery) — لازم صلاحية كافية.
        if ( ! current_user_can( 'install_plugins' ) ) wp_send_json_error( 'غير مصرح', 403 );
        $job = get_option( 'wpl_bg_install_job', [] );

        // ✅ v3.3.4: Recovery المحسّن — لو الـ job متعلق، شغّله مباشرة (مش non-blocking POST)
        if ( ! empty( $job ) ) {
            $now = time();

            // حالة: queued لأكتر من 15 ثانية → run مباشرة في نفس الـ request
            if ( ( $job['status'] ?? '' ) === 'queued' ) {
                $queued_since = $now - (int) ( $job['queued_at'] ?? $now );
                if ( $queued_since > 15 ) {
                    $job['recovery_attempts'] = ( $job['recovery_attempts'] ?? 0 ) + 1;
                    $job['last_recovery_at']  = $now;
                    update_option( 'wpl_bg_install_job', $job, false );

                    // register_shutdown_function عشان ما نأخرش response الـ AJAX
                    register_shutdown_function( function() {
                        if ( function_exists('fastcgi_finish_request') ) {
                            fastcgi_finish_request();
                        }
                        @set_time_limit(300);
                        @ignore_user_abort(true);
                        $this->run_bg_install();
                    });
                }
            }

            // حالة: running لأكتر من 5 دقايق → اعتبره معطّل وأعد تشغيله
            // ✅ v2.7.5: قبل كده كان بيتعافى بس لو total===0 (مات قبل ما يجيب الملفات).
            //    دلوقتي بيتعافى كمان لو علّق في النص (total>0) — السبب الشائع لـ "نزل جزء وعلّق".
            //    الشرط الإضافي (done لسه زي ما هو من آخر فحص) بيمنع إعادة تشغيل install شغّال فعلاً.
            if ( ( $job['status'] ?? '' ) === 'running' ) {
                $started_since = $now - (int) ( $job['started_at'] ?? $now );
                $done          = (int) ( $job['done'] ?? 0 );
                $last_done     = (int) ( $job['recovery_last_done'] ?? -1 );
                $no_progress   = ( $done === $last_done ); // مفيش تقدّم من آخر فحص

                if ( $started_since > 300 && ( $no_progress || $last_done === -1 ) ) {
                    $job['recovery_last_done'] = $done;
                    $job['status']    = 'queued';
                    $job['queued_at'] = $now;
                    update_option( 'wpl_bg_install_job', $job, false );
                    register_shutdown_function( function() {
                        if ( function_exists('fastcgi_finish_request') ) {
                            fastcgi_finish_request();
                        }
                        @set_time_limit(300);
                        @ignore_user_abort(true);
                        $this->run_bg_install();
                    });
                }
            }
        }

        wp_send_json_success( ! empty($job) ? $job : ['status' => 'idle'] );
    }

    /* ====== تنفيذ الـ Background Install (admin-post HTTP endpoint) ====== */
    public function handle_bg_install_process() {
        // ✅ تحقّق بتوكن عشوائي مخزّن جوه الـ job نفسه (one-time use + انتهاء صلاحية).
        //    الـ endpoint ده nopriv فلازم التوكن يكون غير قابل للتخمين ومحدود الصلاحية.
        $token = sanitize_text_field( $_POST['_wpl_bg_token'] ?? '' );
        $job   = get_option( 'wpl_bg_install_job', [] );

        $expected = is_array( $job ) ? ( $job['bg_token']     ?? '' ) : '';
        $exp_ts   = is_array( $job ) ? (int) ( $job['bg_token_exp'] ?? 0 ) : 0;

        if ( empty( $token ) || empty( $expected )
          || ( $exp_ts && time() > $exp_ts )
          || ! hash_equals( (string) $expected, wp_hash( $token ) ) ) {
            wp_die( 'Unauthorized', 403 );
        }

        // استُخدم مرة واحدة — افضيه من الـ job فوراً (يمنع الـ replay)
        $job['bg_token']     = '';
        $job['bg_token_exp'] = 0;
        update_option( 'wpl_bg_install_job', $job, false );

        // أغلق الـ connection فوراً
        if ( function_exists('fastcgi_finish_request') ) {
            fastcgi_finish_request();
        } else {
            header('Connection: close');
            header('Content-Encoding: none');
            header('Content-Length: 0');
            @ob_end_clean(); flush();
        }

        @set_time_limit(300);
        @ignore_user_abort(true);
        $this->run_bg_install();
        return;
    }

    /**
     * ✅ v3.3.4: الشغل الفعلي للـ bg install — بدون أي HTTP/network dependencies
     * بيتنادى من shutdown function، cron، أو HTTP endpoint
     */
    public function run_bg_install() {
        @set_time_limit(300);
        @ini_set('max_execution_time', 300);

        $job = get_option('wpl_bg_install_job', []);
        if ( empty($job) || ! in_array($job['status'], ['queued', 'running'], true) ) return;

        // امنع double-run: لو running من أقل من 60 ثانية، اعتبر فيه process تاني شغال
        if ( $job['status'] === 'running' && (time() - ($job['started_at'] ?? 0)) < 60 ) return;

        $job['status']     = 'running';
        $job['started_at'] = time();
        update_option('wpl_bg_install_job', $job, false);

        // Load WP libs
        require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        // إجبار filesystem مباشر — يمنع طلب FTP credentials
        if ( ! defined('FS_METHOD') ) define('FS_METHOD', 'direct');
        WP_Filesystem();

        $matched_products = $job['matched_products'] ?? [];
        $order_number     = $job['order_number']     ?? '';

        if ( empty($matched_products) ) {
            $job['status'] = 'complete';
            update_option('wpl_bg_install_job', $job, false);
            return;
        }

        // جيب ملفات المنتجات من السيرفر
        $wpl_ids  = implode(',', array_filter( array_map(fn($m) => $m['wpl_id'] ?? '', $matched_products) ));
        $url      = rtrim(WPL_SERVER_API_URL, '/') . '/products?wpl_ids=' . urlencode($wpl_ids);
        // ✅ v3.5.0: اتصال آمن مركزي — جلب ملفات المنتجات كان بيفشل بصمت على
        //    استضافات SSL مكسورة → الـ job يلاقي $found=null → "لا يوجد ملفات".
        $response = wpl_secure_remote_request( 'GET', $url, [
            'headers'     => ['X-WPL-Key' => WPL_SERVER_API_KEY],
            'timeout'     => 30,
            'httpversion' => '1.1',
        ]);

        if ( is_wp_error($response) ) {
            $job['status'] = 'error';
            $job['error']  = 'تعذّر الاتصال: ' . $response->get_error_message();
            update_option('wpl_bg_install_job', $job, false);
            return;
        }

        $body     = json_decode(wp_remote_retrieve_body($response), true);
        $products = $body['products'] ?? [];

        // ابنِ قائمة الملفات + حدّد المنتجات اللي مفيهاش ملفات
        $all_files     = [];
        $missing_prods = [];

        foreach ( $matched_products as $mp ) {
            $wpl_id   = (string) ($mp['wpl_id']   ?? '');
            $wpl_name = $mp['wpl_name'] ?? $wpl_id;
            $wc_id    = $mp['wc_item_id'] ?? '';
            $found    = null;
            foreach ( $products as $p ) {
                if ( (string)$p['id'] === $wpl_id ) { $found = $p; break; }
            }
            if ( ! $found || empty($found['files']) ) {
                $missing_prods[] = [
                    'woo_name' => $mp['wc_name']  ?? $wpl_name,
                    'wpl_name' => $wpl_name,
                    'wc_id'    => $wc_id,
                    'wpl_id'   => $wpl_id,
                ];
                continue;
            }
            $is_theme = ( ($found['category'] ?? '') === 'theme' );
            foreach ( $found['files'] as $file ) {
                $all_files[] = [
                    'filename'     => $file['filename'],
                    'label'        => $file['label']  ?? $file['filename'],
                    'product_name' => $wpl_name,
                    'product_id'   => $wpl_id,
                    'is_theme'     => $is_theme,
                    'status'       => 'pending',
                    'error'        => '',
                ];
            }
        }

        $job['files']         = $all_files;
        $job['total']         = count($all_files);
        $job['done']          = 0;
        // ادمج missing_prods مع unmatched_products + no_files_products
        // ✅ v2.7.3: no_files_products كمان بتتعرض للعميل كـ "هيتم تنصيبها يدوياً"
        $job['missing_prods'] = array_merge(
            $missing_prods,
            array_values( $job['unmatched_products'] ?? [] ),
            array_values( $job['no_files_products']  ?? [] )
        );
        update_option('wpl_bg_install_job', $job, false);

        if ( empty($all_files) ) {
            $job['status'] = 'complete';
            update_option('wpl_bg_install_job', $job, false);
            return;
        }

        // ✅ الأمان: مابنعطّلش SSL globally. كل تحميل بيمرّ من wpl_secure_download
        //    اللي بيتحقّق من الشهادة أولاً ويعمل fallback بس عند فشل SSL حقيقي.
        $skin    = new WP_Ajax_Upgrader_Skin();
        $log_pfx = '[WPL-Install] order=' . $order_number . ' domain=' . parse_url( home_url(), PHP_URL_HOST );

        error_log( $log_pfx . ' | ▶ START — total_files=' . count($job['files']) );

        foreach ( $job['files'] as $idx => &$fi ) {
            $filename = $fi['filename'];
            $is_theme = (bool) $fi['is_theme'];
            $log_file = $log_pfx . ' | file[' . ($idx+1) . '/' . count($job['files']) . ']=' . $filename;

            $fi['status']       = 'installing';
            $job['files'][$idx] = $fi;
            update_option('wpl_bg_install_job', $job, false);

            // ── 1. بدء تحميل الملف ────────────────────────────
            $dl_endpoint = rtrim(WPL_SERVER_API_URL, '/') . '/download?file=' . urlencode($filename);
            error_log( $log_file . ' | [1] DOWNLOAD_START — fetching signed URL from: ' . $dl_endpoint );

            $dl = wpl_secure_remote_request( 'GET', $dl_endpoint, [
                'headers'     => ['X-WPL-Key' => WPL_SERVER_API_KEY],
                'timeout'     => 15,
                'httpversion' => '1.1',
            ]);

            if ( is_wp_error($dl) ) {
                $err = $dl->get_error_message();
                error_log( $log_file . ' | [2] DOWNLOAD_FAIL — could not fetch signed URL: ' . $err );
                $fi['status'] = 'error'; $fi['error'] = 'تعذّر جلب الرابط: ' . $err;
                $job['files'][$idx] = $fi; update_option('wpl_bg_install_job', $job, false); continue;
            }

            $dl_body = json_decode(wp_remote_retrieve_body($dl), true);
            if ( empty($dl_body['success']) || empty($dl_body['download_url']) ) {
                $api_msg = $dl_body['message'] ?? wp_remote_retrieve_body($dl);
                error_log( $log_file . ' | [2] DOWNLOAD_FAIL — server returned no download_url. Response: ' . $api_msg );
                $fi['status'] = 'error'; $fi['error'] = 'الملف غير موجود على السيرفر: ' . $api_msg;
                $job['files'][$idx] = $fi; update_option('wpl_bg_install_job', $job, false); continue;
            }

            $signed_url = $dl_body['download_url'];
            error_log( $log_file . ' | [1] DOWNLOAD_START — signed URL obtained, downloading ZIP from: ' . $signed_url );

            // ── 2. تحميل الـ ZIP ──────────────────────────────
            $tmp = wpl_secure_download( $signed_url, 60 );

            if ( is_wp_error($tmp) ) {
                $err = $tmp->get_error_message();
                error_log( $log_file . ' | [2] DOWNLOAD_FAIL — ' . $err );
                $fi['status'] = 'error'; $fi['error'] = 'فشل تحميل الملف: ' . $err;
                $job['files'][$idx] = $fi; update_option('wpl_bg_install_job', $job, false); continue;
            }

            $tmp_size = @filesize($tmp);
            error_log( $log_file . ' | [2] DOWNLOAD_OK — saved to: ' . $tmp . ' (' . number_format($tmp_size) . ' bytes)' );

            // ✅ v2.8.0: فحص أمني — ارفض أي ZIP بيحاول يستبدل الكلاينت/يزرع backdoor
            $danger = $this->zip_is_dangerous($tmp);
            if ( $danger !== true ) {
                @unlink($tmp);
                error_log( $log_file . ' | [2] SECURITY_REJECT — ' . $danger );
                $fi['status'] = 'error'; $fi['error'] = $danger;
                $job['files'][$idx] = $fi; update_option('wpl_bg_install_job', $job, false); continue;
            }

            $actual_theme = $this->detect_file_type($tmp);
            $type_label   = $actual_theme ? 'theme' : 'plugin';
            error_log( $log_file . ' | [3] INSTALL_START — detected type: ' . $type_label );

            // ── 3 + 4. التثبيت ─────────────────────────────────
            if ( $actual_theme ) {
                if ( ! class_exists('Theme_Upgrader') )
                    require_once ABSPATH . 'wp-admin/includes/class-theme-upgrader.php';
                $upgrader = new Theme_Upgrader($skin);
            } else {
                if ( ! class_exists('Plugin_Upgrader') )
                    require_once ABSPATH . 'wp-admin/includes/class-plugin-upgrader.php';
                $upgrader = new Plugin_Upgrader($skin);
            }

            // ✅ v3.5.0: تثبيت موحّد يمسح المجلد القديم فعلياً + يتأكد من الكتابة على القرص.
            //    كان install مع overwrite_package بيفشل بـ "المجلد موجود مسبقاً" على
            //    استضافات معينة (Hostinger مثلاً) ويرجّع نتيجة تتفسّر كنجاح وهمي.
            $result = $this->wpl_install_package( $upgrader, $tmp );

            @unlink($tmp);

            // ── 4. نتيجة التثبيت ─────────────────────────────
            if ( is_wp_error($result) ) {
                $err = $result->get_error_message();
                error_log( $log_file . ' | [4] INSTALL_FAIL — WP_Error: ' . $err );
                $fi['status'] = 'error'; $fi['error'] = $err;
            } elseif ( ! $result ) {
                // جمّع أخطاء الـ upgrader skin
                $skin_errors = implode(' | ', $skin->get_upgrade_messages() ?: ['no detail'] );
                error_log( $log_file . ' | [4] INSTALL_FAIL — result=false. Upgrader messages: ' . $skin_errors );
                $fi['status'] = 'error'; $fi['error'] = 'فشل التثبيت — ' . $skin_errors;
            } else {
                error_log( $log_file . ' | [4] INSTALL_OK — ' . $type_label . ' installed successfully' );
                $fi['status'] = 'done';
                $job['done']++;

                // ── 5 + 6. التفعيل ────────────────────────────
                if ( ! $actual_theme ) {
                    error_log( $log_file . ' | [5] ACTIVATE_START — attempting plugin activation' );
                    $activated = $this->try_activate_installed_plugin( $filename, $upgrader );
                    if ( $activated ) {
                        error_log( $log_file . ' | [6] ACTIVATE_OK — plugin activated: ' . $activated );
                        $fi['activated']   = true;
                        $fi['plugin_file'] = $activated;
                    } else {
                        error_log( $log_file . ' | [6] ACTIVATE_FAIL — could not auto-activate, manual activation needed' );
                        $fi['activated']        = false;
                        $fi['activation_error'] = 'لم يتم التفعيل التلقائي — فعّل من صفحة الإضافات يدوياً';
                    }
                } else {
                    error_log( $log_file . ' | [5] ACTIVATE_START — attempting theme switch' );
                    $activated_theme = $this->try_activate_installed_theme( $filename );
                    if ( $activated_theme ) {
                        error_log( $log_file . ' | [6] ACTIVATE_OK — theme switched to: ' . $activated_theme );
                        $fi['activated']   = true;
                        $fi['plugin_file'] = $activated_theme;
                    } else {
                        error_log( $log_file . ' | [6] ACTIVATE_FAIL — could not auto-switch theme, manual activation needed' );
                        $fi['activated']        = false;
                        $fi['activation_error'] = 'لم يتم التفعيل التلقائي — فعّل من صفحة المظهر يدوياً';
                    }
                }
            }

            $job['files'][$idx] = $fi;
            update_option('wpl_bg_install_job', $job, false);
        }
        unset($fi);

        $final_done   = count( array_filter($job['files'], fn($f) => $f['status'] === 'done'  ) );
        $final_errors = count( array_filter($job['files'], fn($f) => $f['status'] === 'error' ) );
        error_log( $log_pfx . ' | ■ END — done=' . $final_done . ' errors=' . $final_errors );

        // ✅ احسب الـ errors بعد انتهاء اللوب
        $error_count = count( array_filter( $job['files'], fn($f) => $f['status'] === 'error' ) );
        $done_count  = count( array_filter( $job['files'], fn($f) => $f['status'] === 'done'  ) );

        $job['status']      = 'complete';
        $job['finished_at'] = time();
        $job['done']        = $done_count;
        $job['errors']      = $error_count;
        update_option('wpl_bg_install_job', $job, false);

        // ✅ أبلّغ السيرفر دايماً — حتى لو في errors
        // بنبعت تقرير بالملفات الفاشلة عشان رسالة الواتساب تكون واضحة
        if ( $order_number && ( $done_count > 0 || $error_count > 0 ) ) {
            $domain = parse_url( home_url(), PHP_URL_HOST );

            // كلمات تدل على companion/helper plugins (مش المنتج الأساسي)
            $companion_keywords = [ 'installer', 'updater', 'otgs', 'companion', 'helper', 'addon' ];

            $is_companion = function( $f ) use ( $companion_keywords ) {
                $name = strtolower( $f['label'] ?? $f['filename'] ?? '' );
                foreach ( $companion_keywords as $kw ) {
                    if ( strpos( $name, $kw ) !== false ) return true;
                }
                return false;
            };

            $failed_all       = array_filter( $job['files'], fn( $f ) => $f['status'] === 'error' );
            $failed_main      = array_filter( $failed_all, fn( $f ) => ! $is_companion( $f ) );
            $failed_companion = array_filter( $failed_all, fn( $f ) =>   $is_companion( $f ) );

            $fmt = fn( $f ) => ( $f['label'] ?? $f['filename'] ?? '' ) . ( ! empty($f['error']) ? ' (' . $f['error'] . ')' : '' );

            $failed_files           = array_values( array_map( $fmt, $failed_main ) );
            $failed_companion_files = array_values( array_map( $fmt, $failed_companion ) );

            // done_count و error_count يحسبوا المنتجات الأساسية بس
            $main_error_count = count( $failed_main );
            $main_done_count  = $done_count - count( $failed_companion );

            wpl_secure_remote_request( 'POST', rtrim( WPL_SERVER_API_URL, '/' ) . '/mark-installed', [
                'headers'     => [ 'X-WPL-Key' => WPL_SERVER_API_KEY, 'Content-Type' => 'application/json' ],
                'body'        => wp_json_encode([
                    'order_number'           => $order_number,
                    'domain'                 => $domain,
                    'done_count'             => $main_done_count,
                    'error_count'            => $main_error_count,
                    'failed_files'           => $failed_files,
                    'failed_companion_files' => $failed_companion_files,
                ]),
                'timeout'     => 10, 'httpversion' => '1.1', 'blocking' => true,
            ]);
            delete_option( 'wpl_has_pending_request' );
        }
        return;
    }

    /* ====== جيب طلبات التفعيل الخاصة بالدومين ====== */
    public function ajax_fetch_my_requests() {
        check_ajax_referer( 'wpl_client_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'غير مصرح', 403 );

        $domain = parse_url( home_url(), PHP_URL_HOST );
        $url    = rtrim( WPL_SERVER_API_URL, '/' ) . '/my-requests?domain=' . urlencode( $domain );

        $response = wpl_secure_remote_request( 'GET', $url, [
            'headers'     => [ 'X-WPL-Key' => WPL_SERVER_API_KEY ],
            'timeout'     => 15,
            'httpversion' => '1.1',
        ]);

        if ( is_wp_error( $response ) ) wp_send_json_error( 'تعذّر الاتصال.' );

        $body     = json_decode( wp_remote_retrieve_body( $response ), true );
        $requests = $body['requests'] ?? [];

        // لو مفيش pending — امسح الـ flag المحلي
        $has_pending = false;
        foreach ( $requests as $r ) {
            if ( $r['status'] === 'pending' ) { $has_pending = true; break; }
        }
        if ( ! $has_pending ) delete_option( 'wpl_has_pending_request' );

        wp_send_json_success( $requests );
    }

    /* ====== أبلّغ السيرفر إن التنصيب اكتمل ====== */
    public function ajax_mark_installed() {
        check_ajax_referer( 'wpl_client_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'غير مصرح', 403 );

        $order_number = sanitize_text_field( $_POST['order_number'] ?? '' );
        $domain       = parse_url( home_url(), PHP_URL_HOST );

        $response = wpl_secure_remote_request( 'POST', rtrim( WPL_SERVER_API_URL, '/' ) . '/mark-installed', [
            'headers'   => [ 'X-WPL-Key' => WPL_SERVER_API_KEY, 'Content-Type' => 'application/json' ],
            'body'      => wp_json_encode([ 'order_number' => $order_number, 'domain' => $domain ]),
            'timeout'   => 10, 'httpversion' => '1.1', 'blocking' => true,
        ]);

        delete_option( 'wpl_has_pending_request' );
        wp_send_json_success();
    }

    /* ====== حالة البلجن ====== */
    /* ====== اكتشاف نوع الملف: theme أم plugin؟ ====== */

    /**
     * حاول تفعيل بلجن بعدة طرق (4 استراتيجيات)
     * بيرجع الـ plugin_file لو نجح التفعيل، أو null لو فشل
     *
     * الاستراتيجيات بالترتيب:
     *   1. plugin_info() من الـ Upgrader
     *   2. البحث بالـ filename في قائمة الـ plugins
     *   3. البحث بالـ folder اللي اتعمله unzip
     *   4. البحث بكل الـ plugins اللي اتغيّر created_at فيهم مؤخراً
     */
    private function try_activate_installed_plugin( $filename, $upgrader ) {
        if ( ! function_exists( 'activate_plugin' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        // امسح cache البلجنز عشان ناخد أحدث قائمة
        wp_cache_delete( 'plugins', 'plugins' );

        $candidates = [];

        // ===== الاستراتيجية 1: plugin_info() =====
        if ( method_exists( $upgrader, 'plugin_info' ) ) {
            $pf = $upgrader->plugin_info();
            if ( $pf ) $candidates[] = $pf;
        }

        // ===== الاستراتيجية 2: find_existing_plugin_file =====
        $found = $this->find_existing_plugin_file( $filename );
        if ( $found && ! in_array( $found, $candidates, true ) ) {
            $candidates[] = $found;
        }

        // ===== الاستراتيجية 3: البحث بالـ result folder =====
        if ( method_exists( $upgrader, 'result' ) || isset( $upgrader->result ) ) {
            $upgrader_result = isset( $upgrader->result ) ? $upgrader->result : null;
            if ( is_array( $upgrader_result ) && ! empty( $upgrader_result['destination_name'] ) ) {
                $dest_folder = $upgrader_result['destination_name'];

                // دوّر على أي بلجن في المجلد ده
                $all_plugins = get_plugins();
                foreach ( $all_plugins as $pf => $data ) {
                    $plugin_dir = explode( '/', $pf )[0];
                    if ( $plugin_dir === $dest_folder && ! in_array( $pf, $candidates, true ) ) {
                        $candidates[] = $pf;
                    }
                }
            }
        }

        // ===== الاستراتيجية 4: آخر بلجن اتثبّت (آخر ملف اتعدّل) =====
        // لو كل اللي فوق فشل، نحاول نلاقي أحدث بلجن اتثبّت في آخر 60 ثانية
        if ( empty( $candidates ) ) {
            $all_plugins      = get_plugins();
            $plugin_dir       = WP_PLUGIN_DIR;
            $recent_threshold = time() - 60;

            foreach ( $all_plugins as $pf => $data ) {
                $file_path = $plugin_dir . '/' . $pf;
                if ( file_exists( $file_path ) && filemtime( $file_path ) >= $recent_threshold ) {
                    $candidates[] = $pf;
                }
            }
        }

        // ===== جرّب التفعيل بكل candidate =====
        foreach ( $candidates as $plugin_file ) {
            // ✅ v3.5.0: اتأكد إن ملف البلجن موجود فعلاً على القرص قبل محاولة تفعيله.
            //    من غير ده، لو المسار مسجّل من محاولة سابقة والملف مش موجود (تثبيت
            //    فشل / مجلد ناقص)، activate_plugin بيرجّع "الملف غير موجود" ووردبريس
            //    يعطّله — ده سبب رسالة "elementor-pro.php غير موجود".
            $full_path = WP_PLUGIN_DIR . '/' . $plugin_file;
            if ( ! file_exists( $full_path ) ) {
                continue; // مسار وهمي — تخطّاه
            }

            // لو مفعّل بالفعل، اعتبره نجح
            if ( is_plugin_active( $plugin_file ) ) {
                return $plugin_file;
            }

            // حاول التفعيل — بدون silent mode عشان نشوف الأخطاء
            $result = activate_plugin( $plugin_file, '', false, false );

            if ( ! is_wp_error( $result ) ) {
                // تأكّد فعلياً إنه اتفعّل
                wp_cache_delete( 'alloptions', 'options' );
                if ( is_plugin_active( $plugin_file ) ) {
                    return $plugin_file;
                }
            }

            // لو فشل، جرّب بالـ silent mode كـ last resort
            $result = activate_plugin( $plugin_file, '', false, true );
            if ( ! is_wp_error( $result ) ) {
                wp_cache_delete( 'alloptions', 'options' );
                if ( is_plugin_active( $plugin_file ) ) {
                    return $plugin_file;
                }
            }
        }

        return null;
    }

    /**
     * ابحث عن بلجن موجود بناءً على اسم الـ zip — ارجع plugin_file أو null
     */
    private function find_existing_plugin_file( $filename ) {
        if ( ! function_exists( 'get_plugins' ) )
            require_once ABSPATH . 'wp-admin/includes/plugin.php';

        $raw_slug   = strtolower( preg_replace( '/\.zip$/i', '', $filename ) );
        $clean_slug = preg_replace( '/-[\d]+[\d.\-]*$/', '', $raw_slug );
        $short_slug = preg_replace( '/-(plugin|addon|pro|premium|sites|theme)$/i', '', $clean_slug );

        foreach ( get_plugins() as $pf => $data ) {
            $dir  = strtolower( explode( '/', $pf )[0] );
            $name = strtolower( $data['Name'] ?? '' );
            if (
                $dir === $clean_slug || $dir === $short_slug ||
                strpos( $clean_slug, $dir ) !== false ||
                strpos( $dir, $short_slug ) !== false ||
                ( $name && (
                    strpos( $name, $short_slug ) !== false ||
                    strpos( $short_slug, $name ) !== false
                ))
            ) {
                return $pf;
            }
        }
        return null;
    }

    /**
     * ابحث عن قالب موجود بناءً على اسم الـ zip — ارجع stylesheet slug أو null
     */
    private function find_existing_theme_slug( $filename ) {
        $base_slug = strtolower( preg_replace( '/[-._\s]+/', '-',
            preg_replace( '/\.[^.]+$/', '', pathinfo( $filename, PATHINFO_FILENAME ) )
        ));
        $base_slug = preg_replace( '/-[\d]+[\d.\-]*$/', '', $base_slug );

        foreach ( wp_get_themes( [ 'errors' => false ] ) as $slug => $theme ) {
            $sl = strtolower( $slug );
            if ( $sl === $base_slug || strpos( $sl, $base_slug ) !== false || strpos( $base_slug, $sl ) !== false ) {
                return $slug;
            }
        }
        return null;
    }

    /**
     * ✅ v3.3.2: فعّل القالب بعد التثبيت (switch_theme)
     * @return string|null اسم الـ slug لو نجح، null لو فشل
     */
    private function try_activate_installed_theme( $filename ) {
        // جيب slug القالب المثبت
        $slug = $this->find_existing_theme_slug( $filename );
        if ( ! $slug ) return null;

        // تأكد إن القالب صالح قبل التفعيل
        $theme = wp_get_theme( $slug );
        if ( ! $theme->exists() || $theme->errors() ) return null;

        // switch_theme بيحتاج switch_themes capability
        if ( ! function_exists( 'switch_theme' ) ) {
            require_once ABSPATH . 'wp-includes/theme.php';
        }

        // احفظ القالب القديم قبل الاستبدال (عشان لو حصل خلل)
        $previous = get_option( 'stylesheet' );
        if ( $previous && $previous !== $slug ) {
            update_option( 'wpl_previous_theme', $previous, false );
        }

        switch_theme( $slug );

        // تحقق إن فعلاً اتفعّل
        $current = get_option( 'stylesheet' );
        return ( $current === $slug ) ? $slug : null;
    }

    private function detect_file_type( $tmp_path ) {
        // القرار: theme أم plugin
        // القاعدة: لو فيه style.css بـ "Theme Name:" وملفه مش بيحتوي plugin header → theme
        //         لو فيه plugin header (Plugin Name: في .php) → plugin بغض النظر
        $is_theme  = false;
        $is_plugin = false;

        if ( ! class_exists( 'ZipArchive' ) ) return false;

        $zip = new ZipArchive();
        if ( $zip->open( $tmp_path ) !== true ) return false;

        for ( $i = 0; $i < $zip->numFiles; $i++ ) {
            $name  = $zip->getNameIndex( $i );
            $depth = substr_count( $name, '/' );

            // style.css في العمق الأول فقط (مش nested)
            if ( $depth === 1 && preg_match( '/\/style\.css$/i', $name ) ) {
                $css = $zip->getFromIndex( $i );
                if ( $css && stripos( $css, 'Theme Name:' ) !== false ) {
                    $is_theme = true;
                }
            }

            // plugin header في .php في العمق الأول
            if ( $depth === 1 && preg_match( '/\.php$/i', $name ) ) {
                $php = $zip->getFromIndex( $i );
                // اقرأ أول 8KB بس
                if ( $php && stripos( substr( $php, 0, 8192 ), 'Plugin Name:' ) !== false ) {
                    $is_plugin = true;
                    break; // لو فيه plugin header → plugin قطعي
                }
            }
        }

        $zip->close();

        // لو فيه plugin header صريح → plugin مهما كان
        if ( $is_plugin ) return false;
        return $is_theme;
    }

    /**
     * ✅ v2.8.0 — حماية حاسمة ضد الـ ZIP الخبيث:
     * بترفض أي ZIP بيحاول يستبدل بلجن الكلاينت نفسه أو ملفات/مسارات حساسة.
     * ده بيمنع السيناريو الكارثي: سيرفر مخترق/منتحَل يبعت ZIP ناقص أو خبيث
     * يستبدل مجلد wpl-client ويوقّع الموقع (أو يزرع backdoor).
     *
     * @param string $tmp_path مسار الـ ZIP المؤقّت
     * @return true|string  true لو آمن، أو رسالة خطأ لو خطر
     */
    private function zip_is_dangerous( $tmp_path ) {
        if ( ! class_exists( 'ZipArchive' ) ) {
            return 'تعذّر فحص الملف (ZipArchive غير متاح).';
        }
        $zip = new ZipArchive();
        if ( $zip->open( $tmp_path ) !== true ) {
            return 'تعذّر فتح الملف المضغوط.';
        }

        // أسماء مجلدات/ملفات ممنوع استبدالها إطلاقاً
        $blocked_slugs = [ 'wpl-client', 'wpl-server' ];

        for ( $i = 0; $i < $zip->numFiles; $i++ ) {
            $name = $zip->getNameIndex( $i );
            if ( $name === false ) continue;

            $norm = str_replace( '\\', '/', $name );

            // 1) منع path traversal (Zip Slip) — أي ../ أو مسار مطلق
            if ( strpos( $norm, '../' ) !== false || strpos( $norm, '..\\' ) !== false
              || ( isset( $norm[0] ) && $norm[0] === '/' )
              || preg_match( '/^[a-zA-Z]:/', $norm ) ) {
                $zip->close();
                return '⛔ الملف يحتوي مسارات خطيرة (path traversal) — تم رفض التثبيت.';
            }

            // 2) منع استبدال بلجن الكلاينت/السيرفر نفسه
            $top = explode( '/', $norm )[0];
            if ( in_array( strtolower( $top ), $blocked_slugs, true ) ) {
                $zip->close();
                return '⛔ الملف يحاول استبدال مكوّن نظام التراخيص نفسه — تم رفض التثبيت لأسباب أمنية.';
            }

            // 3) منع ملفات PHP في الجذر مباشرةً (ملف مش داخل مجلد بلجن/ثيم)
            //    البلجن/الثيم الشرعي دايماً جوه مجلد. ملف .php في الجذر = مشبوه.
            if ( strpos( $norm, '/' ) === false && preg_match( '/\.php$/i', $norm ) ) {
                $zip->close();
                return '⛔ الملف يحتوي ملف PHP في الجذر مباشرةً — تم رفض التثبيت لأسباب أمنية.';
            }
        }

        $zip->close();
        return true;
    }

    /**
     * ✅ v3.5.0: تثبيت موحّد يمسح المجلد القديم فعلياً قبل الكتابة.
     * ============================================================
     * المشكلة: install() مع overwrite_package لوحده مابيمسحش مجلد الإضافة
     * الموجود على بعض الاستضافات → "المجلد موجود مسبقاً" → فشل يتفسّر كنجاح.
     *
     * الحل: نعلّق hook مؤقت على upgrader_package_options يجبر
     * clear_destination=true وabort_if_destination_exists=false — فووردبريس
     * يمسح المجلد القديم وينزّل الجديد مكانه. الـ hook بيتشال فوراً بعد التثبيت.
     *
     * @param WP_Upgrader $upgrader  Plugin_Upgrader أو Theme_Upgrader
     * @param string      $tmp_file  مسار الـ ZIP المؤقّت
     * @return true|WP_Error
     */
    private function wpl_install_package( $upgrader, $tmp_file ) {
        $force_clear = function( $options ) {
            $options['clear_destination']           = true;  // امسح المجلد القديم
            $options['abort_if_destination_exists'] = false; // ماتفشلش لو موجود
            return $options;
        };

        add_filter( 'upgrader_package_options', $force_clear, 99 );
        $result = $upgrader->install( $tmp_file, [ 'overwrite_package' => true ] );
        remove_filter( 'upgrader_package_options', $force_clear, 99 );

        // تأكيد فعلي إن الملفات اتكتبت على القرص (النتيجة true مش كفاية لوحدها)
        if ( $result === true && isset( $upgrader->result ) && is_array( $upgrader->result ) ) {
            $dest = $upgrader->result['destination'] ?? '';
            if ( $dest && ! @is_dir( $dest ) ) {
                return new WP_Error( 'wpl_no_files', 'التثبيت لم يكتب الملفات على القرص — تأكد من صلاحيات المجلد.' );
            }
        }

        return $result;
    }

    /* ====== حالة القالب ====== */
    public function get_theme_status( $zip_filename ) {
        // نظّف slug من اسم الـ ZIP: اشيل الامتداد والأرقام والنقاط
        $raw  = preg_replace( '/\.zip$/i', '', $zip_filename );
        $slug = strtolower( preg_replace( '/[._\s]+/', '-', $raw ) );
        // اشيل أرقام الإصدار من الآخر: e.g. astra-4-0-12 → astra
        $slug_no_ver = preg_replace( '/-[\d]+(?:-[\d]+)*$/', '', $slug );

        $active_theme = get_option( 'stylesheet', '' );
        $all_themes   = wp_get_themes( [ 'errors' => false ] );

        foreach ( $all_themes as $theme_slug => $theme ) {
            $tsl  = strtolower( $theme_slug );
            $tnam = strtolower( $theme->get('Name') ?? '' );

            if ( $tsl === $slug || $tsl === $slug_no_ver ||
                 strpos( $tsl, $slug_no_ver ) !== false ||
                 strpos( $slug_no_ver, $tsl ) !== false ||
                 ( $tnam && strpos( $tnam, $slug_no_ver ) !== false ) ) {
                $is_active = ( strtolower( $active_theme ) === $tsl );
                return [
                    'status'      => $is_active ? 'active' : 'installed',
                    'plugin_file' => $theme_slug,
                ];
            }
        }

        return [ 'status' => 'not_installed', 'plugin_file' => '' ];
    }

    public function get_plugin_status( $zip_filename ) {
        if ( ! function_exists( 'get_plugins' ) )
            require_once ABSPATH . 'wp-admin/includes/plugin.php';

        $all_plugins    = get_plugins();
        $active_plugins = get_option( 'active_plugins', [] );
        $slug           = strtolower( preg_replace( '/\.zip$/i', '', $zip_filename ) );

        foreach ( $all_plugins as $plugin_file => $data ) {
            $dir  = strtolower( explode( '/', $plugin_file )[0] );
            $name = strtolower( $data['Name'] ?? '' );

            if ( strpos( $dir, $slug ) !== false || strpos( $slug, $dir ) !== false
              || ( $name && strpos( $name, $slug ) !== false ) ) {
                return [
                    'status'      => in_array( $plugin_file, $active_plugins ) ? 'active' : 'installed',
                    'plugin_file' => $plugin_file,
                ];
            }
        }

        return [ 'status' => 'not_installed', 'plugin_file' => '' ];
    }
}
