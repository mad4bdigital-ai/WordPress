<?php
/**
 * JetGallery Slider thumbnails template.
 */

$video_state                = $this->get_video_position_state( $settings, $with_featured_image );
$video_display_type         = $video_state['video_display_type'];
$show_video_before_featured = $video_state['show_video_before_featured'];
$show_video_after_featured  = $video_state['show_video_after_featured'];
$show_video_last            = $video_state['show_video_last'];

if ( $with_featured_image && has_post_thumbnail( $post_id ) ) {
	array_unshift( $attachment_ids, intval( get_post_thumbnail_id( $post_id ) ) );
}

$thumbs_video_placeholder_html    = '';
$thumbs_video_after_featured_html = '';
$thumbs_html                      = '';

if ( $this->gallery_has_video() && 'content' === $video_display_type ) {
	$video_thumbnail_image = '';
	$video_thumbnail_icon  = $this->render_icon( 'video_thumbnail_icon', '<span class="jet-woo-swiper-control-thumbs__item-video-icon">%s</span>', '', false );
	$show_video_thumbnail  = empty( $video_thumbnail_icon ) || filter_var( $settings['video_thumbnail_show_thumbnail'] ?? true, FILTER_VALIDATE_BOOLEAN );
	$thumbs_image_attr     = $this->get_image_size_style_attributes( $settings['thumbs_image_size'] );
	$video_thumbnail_url   = $this->get_video_thumbnail_url();

	if ( $this->video_has_custom_placeholder( $settings ) ) {
		$video_placeholder_id  = jet_woo_gallery_video_integration()->get_video_custom_placeholder( $settings );
		$video_thumbnail_src   = wp_get_attachment_image_src( $video_placeholder_id, 'full' );
		$video_thumbnail_url   = ! empty( $video_thumbnail_src[0] ) ? $video_thumbnail_src[0] : '';
		$video_thumbnail_image = ! empty( $video_thumbnail_src ) && $show_video_thumbnail ? $this->get_gallery_image( $video_placeholder_id, $settings['thumbs_image_size'], $video_thumbnail_src, false ) : '';
	}

	if ( empty( $video_thumbnail_url ) ) {
		$video_thumbnail_url = jet_woo_product_gallery()->plugin_url( 'assets/images/video-thumbnails-placeholder.png' );
	}

	if ( $show_video_thumbnail && empty( $video_thumbnail_image ) ) {
		$video_thumbnail_image = $this->get_image_by_url( $video_thumbnail_url, array_merge( [ 'class' => 'wp-post-gallery' ], $thumbs_image_attr ) );
	}

	$thumbs_video_placeholder_html = sprintf(
		'<div data-thumb="%1$s" class="jet-woo-swiper-control-thumbs__item jet-woo-swiper-control-thumbs__item--video swiper-slide"><div class="jet-woo-swiper-control-thumbs__item-image"><span class="jet-woo-swiper-control-thumbs__item-video-image">%2$s%3$s</span></div></div>',
		esc_url( $video_thumbnail_url ),
		$video_thumbnail_image,
		$video_thumbnail_icon
	);

	if ( $show_video_before_featured ) {
		$thumbs_html = $thumbs_video_placeholder_html;
	} elseif ( $show_video_after_featured ) {
		$thumbs_video_after_featured_html = $thumbs_video_placeholder_html;
	}
}

if ( $with_featured_image && ! has_post_thumbnail( $post_id ) ) {
	$thumbs_html .= sprintf(
		'<div class="jet-woo-product-gallery__image-item featured no-image swiper-slide"><div class="jet-woo-product-gallery__image image-with-placeholder"><img src="%s" alt="%s" class="wp-post-image"></div></div>',
		esc_url( $this->get_featured_image_placeholder() ),
		esc_attr__( 'Placeholder', 'jet-woo-product-gallery' )
	);
}

if ( $attachment_ids ) {
	foreach ( $attachment_ids as $index => $attachment_id ) {
		$image_src = wp_get_attachment_image_src( $attachment_id, 'full' );
		$image     = $this->get_gallery_image( $attachment_id, $settings['thumbs_image_size'], $image_src, false );

		$thumbs_html .= sprintf(
			'<div data-thumb="%s" data-attachment-id="%d" class="jet-woo-swiper-control-thumbs__item swiper-slide"><div class="jet-woo-swiper-control-thumbs__item-image">%s</div></div>',
			esc_url( $image_src[0] ),
			(int) $attachment_id,
			$image
		);

		if ( 0 === $index && ! empty( $thumbs_video_after_featured_html ) ) {
			$thumbs_html .= $thumbs_video_after_featured_html;
		}
	}
}

if ( $show_video_last ) {
	$thumbs_html .= $thumbs_video_placeholder_html;
}
?>

<div class="jet-gallery-swiper-thumb">
	<div class="jet-woo-swiper-control-nav jet-woo-swiper-gallery-thumbs swiper-container">
		<div class="swiper-wrapper">
			<?php
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $thumbs_html sanitized.
			echo $thumbs_html;
			?>
		</div>
		<?php if ( filter_var( $settings['slider_show_thumb_nav'], FILTER_VALIDATE_BOOLEAN ) ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- properly escaped inside get_slider_navigation().
			echo $this->get_slider_navigation( 'pagination_thumbnails_slider_arrow_prev', 'pagination_thumbnails_slider_arrow_next', false );
		} ?>
	</div>
</div>
