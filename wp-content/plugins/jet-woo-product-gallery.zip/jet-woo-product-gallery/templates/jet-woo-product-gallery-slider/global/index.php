<?php
/**
 * JetGallery Slider template.
 */

$enable_gallery             = filter_var( $settings['enable_gallery'], FILTER_VALIDATE_BOOLEAN );
$gallery_trigger            = $settings['gallery_trigger_type'];
$zoom_class                 = filter_var( $settings['enable_zoom'], FILTER_VALIDATE_BOOLEAN ) ? ' jet-woo-product-gallery__image--with-zoom' : '';
$video_type                 = jet_woo_gallery_video_integration()->get_video_type( $settings );
$video                      = $this->get_video_html();
$video_state                = $this->get_video_position_state( $settings, $with_featured_image );
$video_display_type         = $video_state['video_display_type'];
$pagination                 = filter_var( $settings['slider_show_pagination'], FILTER_VALIDATE_BOOLEAN );
$pagination_type            = $settings['slider_pagination_type'];
$pagination_control_type    = $settings['slider_pagination_controller_type'];
$wrapper_classes            = $this->get_wrapper_classes( [ 'jet-woo-product-gallery__content' ], $settings );
$swiper_wrapper_classes     = [ 'jet-woo-swiper' ];
$slider_html_attrs          = $this->get_slider_data_settings();
$slides_quantity            = 0;
$show_video_before_featured = $video_state['show_video_before_featured'];
$show_video_after_featured  = $video_state['show_video_after_featured'];
$show_video_last            = $video_state['show_video_last'];
$is_blocks_preview          = 'blocks' === $this->get_editor_type() && defined( 'REST_REQUEST' ) && REST_REQUEST;
$pagination_bullet_placeholder_class = $is_blocks_preview ? '' : ' placeholder';

if ( $with_featured_image ) {
	$slides_quantity++;
}

if ( ! empty( $attachment_ids ) ) {
	$slides_quantity += count( $attachment_ids );
}

if ( 'content' === $video_display_type && $this->gallery_has_video() ) {
	$slides_quantity++;
}

$slider_quantity_class = ( $slides_quantity > 1 )
	? ' jet-woo-product-gallery-slider--has-multiple'
	: ' jet-woo-product-gallery-slider--single';

if ( $pagination ) {
	$pagination_direction = $settings['slider_pagination_direction'];
	$pagination_position  = 'vertical' === $pagination_direction ? $settings['slider_pagination_v_position'] : $settings['slider_pagination_h_position'];

	array_push(
		$swiper_wrapper_classes,
		'jet-woo-swiper-' . $pagination_direction,
		'jet-gallery-swiper-' . $pagination_direction . '-pos-' . $pagination_position
	);
}
?>
<div class="<?php echo esc_attr( implode( ' ', $wrapper_classes ) ); ?>" data-featured-image="<?php echo esc_attr( $with_featured_image ); ?>">
	<div class="<?php echo esc_attr( implode( ' ', $swiper_wrapper_classes ) ); ?>">
		<div class="jet-gallery-swiper-slider">
			<div class="jet-woo-product-gallery-slider<?php echo esc_attr( $slider_quantity_class ); ?> swiper-container"
				<?php
				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- attributes are properly escaped inside implode_html_attributes().
				echo jet_woo_product_gallery_tools()->implode_html_attributes( $slider_html_attrs );
				?> >
				<div class="swiper-wrapper">
					<?php
					if ( $show_video_before_featured ) {
						include $this->get_global_template( 'video' );
					}

					if ( $with_featured_image ) {
						if ( has_post_thumbnail( $post_id ) ) {
							include $this->get_global_template( 'image' );
						} else {
							printf(
								'<div class="jet-woo-product-gallery__image-item featured no-image swiper-slide"><div class="jet-woo-product-gallery__image image-with-placeholder"><img src="%s" alt="%s" class="wp-post-image"></div></div>',
								esc_url( $this->get_featured_image_placeholder() ),
								esc_attr__( 'Placeholder', 'jet-woo-product-gallery' ),
							);
						}
					}

					if ( $show_video_after_featured ) {
						include $this->get_global_template( 'video' );
					}

					if ( $attachment_ids ) {
						foreach ( $attachment_ids as $attachment_id ) {
							include $this->get_global_template( 'thumbnails' );
						}
					}

					if ( $show_video_last ) {
						include $this->get_global_template( 'video' );
					}
					?>
				</div>

				<?php
				if ( filter_var( $settings['slider_show_nav'], FILTER_VALIDATE_BOOLEAN ) ) {
					// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- properly escaped inside get_slider_navigation().
					echo $this->get_slider_navigation( 'slider_nav_arrow_prev', 'slider_nav_arrow_next' );
				}
				?>

				<?php if ( $pagination && 'thumbnails' !== $pagination_type ) : ?>
					<?php if ( 'progressbar' === $pagination_control_type ) : ?>
						<div class="swiper-pagination swiper-pagination-progressbar">
							<span class="swiper-pagination-progressbar-fill placeholder"></span>
						</div>
					<?php elseif ( 'fraction' === $pagination_control_type ) : ?>
						<div class="swiper-pagination swiper-pagination-fraction">
							<span class="swiper-pagination-current placeholder">1</span>/
							<span class="swiper-pagination-total placeholder">3</span>
						</div>
					<?php else : ?>
						<div class="swiper-pagination swiper-pagination-bullets">
							<span class="swiper-pagination-bullet swiper-pagination-bullet-active<?php echo esc_attr( $pagination_bullet_placeholder_class ); ?>"></span>
							<span class="swiper-pagination-bullet<?php echo esc_attr( $pagination_bullet_placeholder_class ); ?>"></span>
							<span class="swiper-pagination-bullet<?php echo esc_attr( $pagination_bullet_placeholder_class ); ?>"></span>
						</div>
					<?php endif; ?>
				<?php endif; ?>
			</div>
		</div>

		<?php
		if ( $pagination && 'thumbnails' === $pagination_type ) {
			if ( count( $attachment_ids ) > 1 || $with_featured_image && ! empty( $attachment_ids ) || $with_featured_image && $this->gallery_has_video() || ! empty( $attachment_ids ) && $this->gallery_has_video() ) {
				include $this->get_global_template( 'thumbnails-pagination' );
			}
		}
		?>

	</div>

	<?php
	if ( 'popup' === $video_display_type ) {
		include $this->get_global_template( 'popup-video' );
	}
	?>

</div>
