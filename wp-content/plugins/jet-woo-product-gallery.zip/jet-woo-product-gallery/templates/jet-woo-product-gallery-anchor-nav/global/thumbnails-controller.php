<?php
/**
 * JetGallery Anchor Navigation thumbnails template.
 */

$video_state                = $this->get_video_position_state( $settings, $with_featured_image );
$video_display_type         = $video_state['video_display_type'];
$show_video_before_featured = $video_state['show_video_before_featured'];
$show_video_after_featured  = $video_state['show_video_after_featured'];
$show_video_last            = $video_state['show_video_last'];

if ( $with_featured_image && has_post_thumbnail( $post_id ) ) {
	array_unshift( $attachment_ids, intval( get_post_thumbnail_id( $post_id ) ) );
}

if ( $show_video_before_featured && empty( $anchor_nav_controller_ids ) ) {
	$anchor_nav_controller_ids[] = $this->get_unique_controller_id();
}

$thumbs_html = '';

if ( $this->gallery_has_video() && 'content' === $video_display_type ) {
	$video_thumbnail_image   = '';
	$video_thumbnail_icon    = $this->render_icon( 'video_thumbnail_icon', '<span class="controller-item__thumbnail-video-icon">%s</span>', '', false );
	$show_video_thumbnail    = empty( $video_thumbnail_icon ) || filter_var( $settings['video_thumbnail_show_thumbnail'] ?? true, FILTER_VALIDATE_BOOLEAN );
	$video_thumbnail_classes = [ 'controller-item__thumbnail-video-image' ];
	$video_thumbnail_style   = '';
	$video_thumbnail_attr    = '';
	$video_thumbnail_url     = $this->get_video_thumbnail_url();
	$video_placeholder_id    = 'video_placeholder';
	$image_size             = [];

	if ( $this->video_has_custom_placeholder( $settings ) ) {
		$custom_video_placeholder_id = jet_woo_gallery_video_integration()->get_video_custom_placeholder( $settings );
		$video_thumbnail_src         = wp_get_attachment_image_src( $custom_video_placeholder_id, 'full' );
		$video_thumbnail_url         = ! empty( $video_thumbnail_src[0] ) ? $video_thumbnail_src[0] : '';
		$video_thumbnail_image       = ! empty( $video_thumbnail_src ) && $show_video_thumbnail ? $this->get_gallery_image( $custom_video_placeholder_id, $settings['thumbs_image_size'], $video_thumbnail_src, false ) : '';
	}

	if ( empty( $video_thumbnail_url ) ) {
		$video_thumbnail_url = jet_woo_product_gallery()->plugin_url( 'assets/images/video-thumbnails-placeholder.png' );
	}

	if ( ! empty( $settings['thumbs_image_size'] ) && 'full' !== $settings['thumbs_image_size'] ) {
		$image_sizes = wp_get_registered_image_subsizes();
		$image_size  = $image_sizes[ $settings['thumbs_image_size'] ] ?? [];
		$style       = [];

		if ( ! empty( $image_size['width'] ) || ! empty( $image_size['height'] ) ) {
			$style[] = 'width: 100%';
		}

		if ( ! empty( $image_size['width'] ) ) {
			$style[] = sprintf( 'max-width: %dpx', absint( $image_size['width'] ) );
		}

		if ( ! empty( $image_size['height'] ) ) {
			$style[] = sprintf( 'max-height: %dpx', absint( $image_size['height'] ) );
		}

		if ( ! empty( $image_size['width'] ) && ! empty( $image_size['height'] ) ) {
			$style[] = sprintf( 'aspect-ratio: %d / %d', absint( $image_size['width'] ), absint( $image_size['height'] ) );
		}

		if ( ! empty( $style ) ) {
			$video_thumbnail_style = implode( '; ', $style ) . ';';
			$video_thumbnail_attr  = sprintf( ' style="%s"', esc_attr( $video_thumbnail_style ) );
		}
	}

	if ( $show_video_thumbnail && empty( $video_thumbnail_image ) ) {
		$video_thumbnail_image = $this->get_image_by_url( $video_thumbnail_url, [ 'class' => 'wp-post-gallery' ] );
	}

	if ( ! $show_video_thumbnail ) {
		$video_thumbnail_classes[] = 'controller-item__thumbnail-video-image--icon-only';
	}

	if ( $show_video_before_featured ) {
		array_unshift( $attachment_ids, $video_placeholder_id );
	} elseif ( $show_video_after_featured ) {
		array_splice( $attachment_ids, 1, 0, [ $video_placeholder_id ] );
	} elseif ( $show_video_last ) {
		$attachment_ids[] = $video_placeholder_id;
	}
}

if ( $with_featured_image && ! has_post_thumbnail( $post_id ) ) {
	$thumbs_html .= sprintf(
		'<div class="jet-woo-product-gallery__image-item featured no-image swiper-slide"><div class="jet-woo-product-gallery__image image-with-placeholder"><img src="%s" alt="%s" class="wp-post-image"></div></div>',
		esc_url( $this->get_featured_image_placeholder() ),
		esc_attr__( 'Placeholder', 'jet-woo-product-gallery' )
	);
}

foreach ( $attachment_ids as $index => $attachment_id ) {
	$anchor_id = isset( $anchor_nav_controller_ids[ $index ] ) ? $anchor_nav_controller_ids[ $index ] : $index;

	if ( 'video_placeholder' === $attachment_id ) {
		$thumbs_html .= sprintf(
			'<li class="controller-item">
				<a href="#%1$s" data-index="%1$s" data-role="gallery-controller">
					<span class="controller-item__thumbnail controller-item__thumbnail--video"><span class="%2$s"%3$s>%4$s%5$s</span></span>
				</a>
			</li>',
			esc_attr( $anchor_id ),
			esc_attr( implode( ' ', $video_thumbnail_classes ) ),
			$video_thumbnail_attr,
			$video_thumbnail_image,
			$video_thumbnail_icon
		);

		continue;
	}

	$image_src = wp_get_attachment_image_src( $attachment_id, 'full' );
	$image     = $this->get_gallery_image( $attachment_id, $settings['thumbs_image_size'], $image_src, false );

	$thumbs_html .= sprintf(
		'<li class="controller-item">
			<a href="#%1$s" data-index="%1$s" data-role="gallery-controller">
				<span class="controller-item__thumbnail">%2$s</span>
			</a>
		</li>',
		esc_attr( $anchor_id ),
		$image
	);
}
?>

<ul class="jet-woo-product-gallery-anchor-nav-controller">
	<div class="jet-woo-product-gallery-anchor-nav-controller-sticky">
		<?php
			// phpcs:ignore
			echo $thumbs_html;

			if ( 'popup' === $settings['video_display_in'] && $this->gallery_has_video() ) {
				include $this->get_global_template( 'popup-video' );
			}
		?>
	</div>
</ul>