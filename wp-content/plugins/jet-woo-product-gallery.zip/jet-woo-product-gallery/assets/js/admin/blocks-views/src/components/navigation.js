const {
	MediaUpload,
	MediaUploadCheck
} = wp.blockEditor;

const { __ } = wp.i18n;

const {
	Button,
	PanelBody,
	SelectControl,
	ToggleControl,
} = wp.components;

export default props => {

	const {
		attributes,
		setAttributes
	} = props;

	const hasVideoThumbnailIcon = 0 !== Object.keys( attributes.video_thumbnail_icon || {} ).length;
	const showVideoThumbnailControls = (
		( 'products' === attributes.gallery_source || 'products' !== attributes.gallery_source && attributes.enable_video ) &&
		'content' === attributes.video_display_in &&
		'thumbnails' === attributes.navigation_type
	);

	return (
		<PanelBody title={ __( 'Navigation', 'jet-woo-product-gallery' ) } initialOpen={ false }>

			<SelectControl
				label={ __( 'Navigation Type', 'jet-woo-product-gallery' ) }
				value={ attributes.navigation_type }
				options={
					[
						{
							value: 'bullets',
							label: __( 'Bullets', 'jet-woo-product-gallery' )
						},
						{
							value: 'thumbnails',
							label: __( 'Thumbnails', 'jet-woo-product-gallery' )
						}
					]
				}
				onChange={ newValue => {
					setAttributes( {
						navigation_type: newValue,
					} );
				}}
			/>
			
			<SelectControl
				label={ __( 'Navigation Position', 'jet-woo-product-gallery' ) }
				value={ attributes.navigation_position }
				options={
					[
						{
							value: 'outside',
							label: __( 'Outside', 'jet-woo-product-gallery' )
						},
						{
							value: 'inside',
							label: __( 'Inside', 'jet-woo-product-gallery' )
						}
					]
				}
				onChange={ newValue => {
					setAttributes( {
						navigation_position: newValue,
					} );
				}}
			/>

			<SelectControl
				label={ __( 'Controller Position', 'jet-woo-product-gallery' ) }
				value={ attributes.navigation_controller_position }
				options={
					[
						{
							value: 'top',
							label: __( 'Top', 'jet-woo-product-gallery' )
						},
						{
							value: 'left',
							label: __( 'Start', 'jet-woo-product-gallery' )
						},
						{
							value: 'right',
							label: __( 'End', 'jet-woo-product-gallery' )
						},
						{
							value: 'bottom',
							label: __( 'Bottom', 'jet-woo-product-gallery' )
						}
					]
				}
				onChange={ newValue => {
					setAttributes( {
						navigation_controller_position: newValue,
					} );
				}}
			/>

			{ attributes.navigation_type === 'bullets'
				&& [ 'top', 'bottom' ].includes( attributes.navigation_controller_position )
				&& (
					<SelectControl
						label={ __( 'Controller Align', 'jet-woo-product-gallery' ) }
						value={ attributes.navigation_controller_align }
						options={ [
							{
								value: 'start',
								label: __( 'Start', 'jet-woo-product-gallery' ),
							},
							{
								value: 'center',
								label: __( 'Center', 'jet-woo-product-gallery' ),
							},
							{
								value: 'end',
								label: __( 'End', 'jet-woo-product-gallery' ),
							},
						] }
						onChange={ newValue => {
							setAttributes( {
								navigation_controller_align: newValue,
							} );
						} }
					/>
				)
			}

			{ showVideoThumbnailControls &&
				<div className={ "components-base-control" }>
					<div className="jet-gallery-heading">Video Thumbnail</div>

					<MediaUploadCheck>
						{ hasVideoThumbnailIcon &&
							<div className={ "preview-jet-gallery-media preview-jet-gallery-media-icon" }>
								<Button className={ "jet-remove-button" } isPrimary icon="no-alt" onClick={ () => {
									setAttributes( { video_thumbnail_icon: {} } );
								} }
								></Button>
								<img src={ attributes.video_thumbnail_icon.url } width="100%" height="auto" />
							</div>
						}
						<div className="components-base-control jet-media-control">
							<MediaUpload
								allowedTypes={ [ 'image/svg+xml' ] }
								value={ attributes.video_thumbnail_icon && attributes.video_thumbnail_icon.id ? attributes.video_thumbnail_icon.id : '' }
								onSelect={ ( media ) => {
									const iconData = {
										id:  media.id,
										url: media.url
									};

									setAttributes( { video_thumbnail_icon: iconData } );
								} }
								render={ ( { open } ) => (
									<Button
										isSecondary
										icon="edit"
										onClick={ open }
									>{ __( 'Select Thumbnail Icon', 'jet-woo-product-gallery' ) }</Button>
								) }
							/>
						</div>
					</MediaUploadCheck>

					{ hasVideoThumbnailIcon &&
						<ToggleControl
							label={ __( 'Show Thumbnail', 'jet-woo-product-gallery' ) }
							checked={ attributes.video_thumbnail_show_thumbnail }
							onChange={ () => {
								setAttributes( { video_thumbnail_show_thumbnail: ! attributes.video_thumbnail_show_thumbnail } );
							} }
						/>
					}
				</div>
			}

		</PanelBody>
	);

};