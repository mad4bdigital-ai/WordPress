<?php
/**
 * Plugin Name: Custom Mega Menu Widgets (All Styles)
 * Description: 5 Custom Elementor Widgets for Mega Menu styles requested by the user. Includes unified CTA Buttons and Optional Right Sidebars for ALL widgets (V43).
 * Version:     1.1.43
 * Author:      AI Assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'elementor/widgets/register', function( $widgets_manager ) {
	if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
		return;
	}

	function ag_get_base_css($id) {
		return "
		.mega-menu-$id { font-family: 'Inter', sans-serif; background-color: #21252f; border-radius: 12px; padding: 30px; width: 100% !important; min-width: min-content !important; box-sizing: border-box; box-shadow: 0 10px 30px rgba(0,0,0,0.3); display: block; }
		.mega-menu-$id * { box-sizing: border-box; }
		.mega-menu-$id .menu-container { display: flex; gap: 40px; width: 100%; }
		.mega-menu-$id .left-column { flex: 7; border-right: 1px solid #323846; padding-right: 30px; }
		.mega-menu-$id .menu-container.no-sidebar .left-column { border-right: none; padding-right: 0; flex: 1 1 100%; width: 100%; }
		.mega-menu-$id .right-column { flex: 3; }
		.mega-menu-$id .column-title { color: #ffffff; font-size: 18px; font-weight: 600; margin-bottom: 25px; margin-top: 0; }
		.mega-menu-$id .template-item { display: flex; align-items: flex-start; gap: 15px; text-decoration: none; padding: 10px; border-radius: 8px; transition: 0.3s; }
		.mega-menu-$id .template-item:hover { background-color: rgba(255,255,255,0.05); }
		.mega-menu-$id .icon-box { background-color: #384050; width: 45px; height: 45px; border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; overflow: hidden; }
		.mega-menu-$id .icon-box svg, .mega-menu-$id .icon-box i { width: 20px; height: 20px; fill: currentColor; stroke: currentColor; font-size: 20px; display: block; }
		.mega-menu-$id .icon-text { font-weight: bold; font-size: 13px; text-transform: uppercase; }
		.mega-menu-$id .item-content h4 { color: #ffffff; font-size: 15px; margin: 0 0 5px 0; font-weight: 600; line-height: 1.2; }
		.mega-menu-$id .item-content p { color: #8c93a1; font-size: 13px; margin: 0; line-height: 1.4; }
		.mega-menu-$id .template-item.format-no_desc { align-items: center; }
		.mega-menu-$id .template-item.format-no_desc .item-content h4 { margin-bottom: 0; }
		
		.mega-menu-$id .niches-list { list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 18px; }
		.mega-menu-$id .niches-list a { color: #ffffff; text-decoration: none; font-size: 15px; font-weight: 500; transition: 0.3s; display: block; line-height: 1.4; }
		.mega-menu-$id .niches-list a:hover { color: #00e6a1; }
		
		/* Flexible Buttons (CTA) */
		.mega-menu-$id .ag-btn-solid { background: #00e6a1; color: #1e212b !important; border: 1px solid #00e6a1; border-radius: 20px; padding: 6px 16px; font-size: 13px; font-weight: 600; transition: 0.3s; text-decoration: none; display: inline-block; }
		.mega-menu-$id .ag-btn-solid:hover { background: transparent; color: #00e6a1 !important; }
		.mega-menu-$id .ag-btn-outline { border: 1px solid #00e6a1; color: #00e6a1 !important; border-radius: 20px; padding: 6px 16px; font-size: 13px; font-weight: 600; transition: 0.3s; text-decoration: none; display: inline-block; background: transparent; }
		.mega-menu-$id .ag-btn-outline:hover { background: #00e6a1; color: #1e212b !important; }
		.mega-menu-$id .ag-btn-text { color: #00e6a1 !important; text-decoration: none; font-size: 14px; font-weight: 600; transition: 0.3s; display: inline-block; }
		.mega-menu-$id .ag-btn-text:hover { color: #00c98d !important; }
		.mega-menu-$id .bottom-links-container { display: flex; flex-wrap: wrap; gap: 20px; align-items: center; margin-top: 15px; padding-top: 15px; }

		/* CSS Variables for Individual Button Colors */
		.mega-menu-$id .ag-btn-solid.has-custom-color { background: var(--btn-color); border-color: var(--btn-color); }
		.mega-menu-$id .ag-btn-solid.has-custom-color:hover { background: transparent; color: var(--btn-color) !important; }
		.mega-menu-$id .ag-btn-outline.has-custom-color { color: var(--btn-color) !important; border-color: var(--btn-color); }
		.mega-menu-$id .ag-btn-outline.has-custom-color:hover { background: var(--btn-color); color: #1e212b !important; }
		.mega-menu-$id .ag-btn-text.has-custom-color { color: var(--btn-color) !important; }

		/* Style 4 & 5: Vertical Tabs */
		.mega-menu-$id.mega-menu-tabs { padding: 0; display: flex; min-height: 400px; }
		.mega-menu-$id .tabs-sidebar { width: 220px; background-color: rgba(0,0,0,0.15); border-right: 1px solid #323846; padding: 20px 0; border-top-left-radius: 12px; border-bottom-left-radius: 12px; flex-shrink: 0; }
		.mega-menu-$id .tab-link { padding: 15px 20px; color: #8c93a1; font-size: 15px; font-weight: 600; cursor: pointer; transition: 0.3s; display: flex; justify-content: space-between; align-items: center; }
		.mega-menu-$id .tab-link:hover, .mega-menu-$id .tab-link.active { background-color: rgba(255,255,255,0.05); color: #ffffff; }
		.mega-menu-$id .tab-link .arrow { font-size: 12px; opacity: 0; transition: 0.3s; transform: translateX(-5px); }
		.mega-menu-$id .tab-link.active .arrow { opacity: 1; transform: translateX(0); color: #00e6a1; }
		.mega-menu-$id .tabs-content-area { flex: 1; padding: 30px; position: relative; }
		.mega-menu-$id .tab-pane { display: none; animation: fadeIn 0.4s; }
		.mega-menu-$id .tab-pane.active { display: block; }
		.mega-menu-$id .tab-pane-title { color: #ffffff; font-size: 20px; margin-top: 0; margin-bottom: 25px; font-weight: 600; }
		.mega-menu-$id .mobile-accordion-title { display: none; }
		
		/* Tabs Right Sidebar Styling */
		.mega-menu-$id.mega-menu-tabs .right-column { border-left: 1px solid #323846; padding: 30px; flex: 0 0 280px; }
		.mega-menu-$id.mega-menu-tabs.no-sidebar .right-column { display: none; }
		
		/* Base grid classes, overriden by Elementor controls */
		.mega-menu-$id .features-grid-s4 { display: grid; gap: 20px; }
		.mega-menu-$id .plugins-grid { display: grid; gap: 20px; margin-bottom: 30px; }
		.mega-menu-$id .templates-grid { display: grid; gap: 20px; margin-bottom: 30px; }
		.mega-menu-$id .features-grid { display: grid; gap: 20px; margin-bottom: 30px; }
		
		@keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }
		
		/* Style 5 Additions */
		.mega-menu-$id .mega-menu-multi .l2-sidebar { display: none; background-color: rgba(255,255,255,0.03); border-right: 1px solid #323846; border-radius: 0; }
		.mega-menu-$id .mega-menu-multi .l2-link { display: none; }
		.mega-menu-$id .l1-pane:has(.l2-pane.active) > .tab-pane-title { display: none; }

		@media (max-width: 900px) {
			.mega-menu-$id.mega-menu-tabs .right-column { border-left: none; border-top: 1px solid #323846; flex: none; width: 100%; }
		}
		@media (max-width: 768px) { 
			.mega-menu-$id { padding: 15px !important; min-width: 0 !important; max-width: 100% !important; overflow-x: hidden; box-sizing: border-box; }
			.mega-menu-$id .menu-container { flex-direction: column; gap: 20px; } 
			.mega-menu-$id .left-column { border-right: none; padding-right: 0; border-bottom: 1px solid #323846; padding-bottom: 20px; } 
			.mega-menu-$id.mega-menu-tabs { flex-direction: column; padding: 0 !important; }
			
			/* Mobile Accordion (For Style 4 and Style 5) */
			.mega-menu-$id .tabs-sidebar { display: none !important; }
			.mega-menu-$id .mobile-accordion-title { 
				display: flex; 
				justify-content: space-between; 
				align-items: center; 
				padding: 15px; 
				background: rgba(255,255,255,0.05); 
				border-radius: 8px; 
				margin-bottom: 15px; 
				font-weight: 600; 
				color: #fff; 
				cursor: pointer; 
				border: 1px solid transparent;
				transition: 0.3s;
			}
			.mega-menu-$id .mobile-accordion-title.active { 
				background: rgba(255,255,255,0.1); 
				border-color: rgba(255,255,255,0.2); 
				color: #00e6a1;
				margin-bottom: 5px;
			}
			.mega-menu-$id .mobile-accordion-title .accordion-arrow { 
				display: inline-block; 
				width: 8px; 
				height: 8px; 
				border-right: 2px solid currentColor; 
				border-bottom: 2px solid currentColor; 
				transform: rotate(45deg); 
				transition: transform 0.3s; 
				margin-bottom: 4px;
				margin-right: 5px;
			}
			.mega-menu-$id .mobile-accordion-title.active .accordion-arrow { 
				transform: rotate(-135deg); 
				margin-top: 4px;
				margin-bottom: 0;
			}
			.mega-menu-$id .tab-pane { padding: 10px 5px 20px 5px; }
			.mega-menu-$id .tab-pane-title { display: none; } /* Hide desktop title on mobile accordion */
			.mega-menu-$id .mobile-accordion-title.l2-accordion { margin-left: 20px; background: rgba(255,255,255,0.015); border-left: 1px solid rgba(255,255,255,0.05); }
			
			/* L2 sidebar on mobile */
			.mega-menu-$id .mega-menu-multi .l2-sidebar {
				border-radius: 0;
				background-color: transparent;
				padding: 5px 15px 15px 15px;
				border-bottom: 1px solid #323846;
			}

			.mega-menu-$id .tab-link { 
				padding: 8px 16px; 
				white-space: nowrap; 
				border-radius: 30px; 
				font-size: 14px; 
				background-color: rgba(255,255,255,0.05);
			}
			.mega-menu-$id .tab-link.active {
				background-color: rgba(255,255,255,0.15);
			}
			.mega-menu-$id .tab-link .arrow { display: none; }
			
			/* Content area padding */
			.mega-menu-$id .tabs-content-area { padding: 15px; }
			.mega-menu-$id.mega-menu-tabs .right-column { padding: 15px; }
			
			/* Adjust gaps */
			.mega-menu-$id .features-grid-s4, .mega-menu-$id .plugins-grid, .mega-menu-$id .templates-grid, .mega-menu-$id .features-grid { gap: 15px; margin-bottom: 20px; }
		}
		";
	}

	function ag_add_style_controls($widget) {
		$widget->start_controls_section('layout_sec', ['label' => 'Grid Layout', 'tab' => \Elementor\Controls_Manager::TAB_STYLE]);
		$widget->add_responsive_control('grid_columns', [
			'label' => 'Number of Columns',
			'type' => \Elementor\Controls_Manager::NUMBER,
			'min' => 1,
			'max' => 12,
			'step' => 1,
			'default' => 3,
			'tablet_default' => 2,
			'mobile_default' => 1,
			'selectors' => [ 
				'{{WRAPPER}} .features-grid-s4, {{WRAPPER}} .plugins-grid, {{WRAPPER}} .templates-grid, {{WRAPPER}} .features-grid' => 'grid-template-columns: repeat({{VALUE}}, 1fr) !important;' 
			],
			'description' => 'Type any number of columns you want for the grid (e.g. 5 or 6). Use the device icon to change it for Tablet/Mobile.',
		]);
		$widget->end_controls_section();

		$widget->start_controls_section('style_sec', ['label' => 'Mega Menu Colors', 'tab' => \Elementor\Controls_Manager::TAB_STYLE]);
		$widget->add_control('bg_color', [
			'label' => 'Main Background Color', 'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .mega-menu-wrapper' => 'background-color: {{VALUE}} !important;' ],
		]);
		$widget->add_control('sidebar_bg', [
			'label' => 'Tabs Sidebar Background', 'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .tabs-sidebar' => 'background-color: {{VALUE}} !important;' ],
		]);
		$widget->add_control('l2_sidebar_bg', [
			'label' => 'Level 2 Sidebar Background (Style 5)', 'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .l2-sidebar' => 'background-color: {{VALUE}} !important;' ],
		]);
		$widget->add_control('item_hover_bg', [
			'label' => 'Item Hover / Active Background', 'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .template-item:hover, {{WRAPPER}} .tab-link:hover, {{WRAPPER}} .tab-link.active' => 'background-color: {{VALUE}} !important;' ],
		]);
		$widget->add_control('title_color', [
			'label' => 'Headings, Links & Accordion', 'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .column-title, {{WRAPPER}} .item-content h4, {{WRAPPER}} .niches-list a, {{WRAPPER}} .tab-pane-title, {{WRAPPER}} .tab-link.active, {{WRAPPER}} .tab-link:hover, {{WRAPPER}} .mobile-accordion-title' => 'color: {{VALUE}} !important;' ],
		]);
		$widget->add_control('text_color', [
			'label' => 'Description Text', 'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .item-content p, {{WRAPPER}} .tab-link' => 'color: {{VALUE}} !important;' ],
		]);
		$widget->add_control('accent_color', [
			'label' => 'Global Accent Color (Buttons/Hover)', 'type' => \Elementor\Controls_Manager::COLOR,
			'selectors' => [ 
				'{{WRAPPER}} .ag-btn-solid:not(.has-custom-color)' => 'background-color: {{VALUE}}; border-color: {{VALUE}};',
				'{{WRAPPER}} .ag-btn-solid:not(.has-custom-color):hover' => 'color: {{VALUE}} !important;',
				'{{WRAPPER}} .ag-btn-outline:not(.has-custom-color)' => 'color: {{VALUE}} !important; border-color: {{VALUE}};',
				'{{WRAPPER}} .ag-btn-outline:not(.has-custom-color):hover' => 'background-color: {{VALUE}};',
				'{{WRAPPER}} .ag-btn-text:not(.has-custom-color)' => 'color: {{VALUE}} !important;',
				'{{WRAPPER}} .tab-link.active .arrow, {{WRAPPER}} .niches-list a:hover' => 'color: {{VALUE}} !important;',
			],
		]);
		$widget->end_controls_section();

		$widget->start_controls_section('typography_sec', ['label' => 'Typography', 'tab' => \Elementor\Controls_Manager::TAB_STYLE]);
		$widget->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => 'Titles (H3, Tabs, Accordion)',
				'selector' => '{{WRAPPER}} .column-title, {{WRAPPER}} .tab-pane-title, {{WRAPPER}} .tab-link, {{WRAPPER}} .mobile-accordion-title',
			]
		);
		$widget->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'item_title_typography',
				'label' => 'Item Titles (H4)',
				'selector' => '{{WRAPPER}} .item-content h4, {{WRAPPER}} .template-item h4',
			]
		);
		$widget->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'desc_typography',
				'label' => 'Descriptions (P)',
				'selector' => '{{WRAPPER}} .item-content p, {{WRAPPER}} .template-item p',
			]
		);
		$widget->end_controls_section();

		$widget->start_controls_section('accordion_sec', ['label' => 'Mobile Accordion', 'tab' => \Elementor\Controls_Manager::TAB_STYLE]);
		$widget->add_responsive_control('accordion_padding', [
			'label' => 'Accordion Title Padding',
			'type' => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => ['px', 'em', '%'],
			'selectors' => [ '{{WRAPPER}} .mobile-accordion-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
		]);
		$widget->end_controls_section();
	}

	function ag_get_elementor_templates() {
		$options = ['' => 'Select Template'];
		$posts = get_posts(['post_type' => 'elementor_library', 'posts_per_page' => -1]);
		foreach($posts as $post) { $options[$post->ID] = $post->post_title; }
		return $options;
	}
	function ag_get_post_types() {
		$options = [];
		$post_types = get_post_types(['public' => true], 'objects');
		foreach($post_types as $pt) { $options[$pt->name] = $pt->label; }
		return $options;
	}
	function ag_get_taxonomies() {
		$options = ['' => 'Any'];
		$taxonomies = get_taxonomies(['public' => true], 'objects');
		foreach($taxonomies as $tax) { $options[$tax->name] = $tax->label; }
		return $options;
	}
	function ag_add_dynamic_controls_to_repeater($repeater) {
		$repeater->add_control('item_type', [
			'label' => 'Item Type',
			'type' => \Elementor\Controls_Manager::CHOOSE,
			'options' => [
				'manual' => ['title' => 'Manual', 'icon' => 'eicon-text-area'],
				'template' => ['title' => 'Template', 'icon' => 'eicon-document-file'],
				'query' => ['title' => 'Posts', 'icon' => 'eicon-database'],
				'query_terms' => ['title' => 'Terms', 'icon' => 'eicon-tags'],
				'jet_query' => ['title' => 'JetEngine', 'icon' => 'eicon-cogs'],
			],
			'default' => 'manual',
			'toggle' => false,
		]);
		$repeater->add_control('display_format', [
			'label' => 'Display Format',
			'type' => \Elementor\Controls_Manager::SELECT,
			'options' => [
				'all' => 'Icon, Title, Description',
				'no_desc' => 'Icon, Title',
				'title_only' => 'Title Only',
			],
			'default' => 'all',
			'condition' => ['item_type!' => 'template']
		]);
		$repeater->add_control('title', [
			'label' => 'Title', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Item Name',
			'dynamic' => ['active' => true],
			'condition' => ['item_type' => 'manual']
		]);
		$repeater->add_control('desc', [
			'label' => 'Description', 'type' => \Elementor\Controls_Manager::TEXTAREA, 'default' => 'Short description...',
			'dynamic' => ['active' => true],
			'condition' => ['item_type' => 'manual']
		]);
		$repeater->add_control('link', [
			'label' => 'Link', 'type' => \Elementor\Controls_Manager::URL, 'default' => ['url' => '#'],
			'dynamic' => ['active' => true],
			'condition' => ['item_type' => 'manual']
		]);
		$repeater->add_control('template_id', [
			'label' => 'Select Template',
			'type' => \Elementor\Controls_Manager::SELECT2,
			'options' => ag_get_elementor_templates(),
			'condition' => ['item_type' => 'template']
		]);
		$repeater->add_control('query_post_type', [
			'label' => 'Post Type',
			'type' => \Elementor\Controls_Manager::SELECT2,
			'options' => ag_get_post_types(),
			'default' => 'post',
			'condition' => ['item_type' => 'query']
		]);
		$repeater->add_control('query_taxonomy', [
			'label' => 'Filter by Taxonomy',
			'type' => \Elementor\Controls_Manager::SELECT2,
			'options' => ag_get_taxonomies(),
			'default' => '',
			'condition' => ['item_type' => 'query']
		]);
		$repeater->add_control('query_term', [
			'label' => 'Term ID or Slug (e.g. 5, news)',
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => '',
			'condition' => [
				'item_type' => 'query',
				'query_taxonomy!' => ''
			]
		]);
		$repeater->add_control('query_count', [
			'label' => 'Number of Posts',
			'type' => \Elementor\Controls_Manager::NUMBER,
			'default' => 4,
			'condition' => ['item_type' => 'query']
		]);
		$repeater->add_control('query_terms_tax', [
			'label' => 'Taxonomy to Display',
			'type' => \Elementor\Controls_Manager::SELECT2,
			'options' => ag_get_taxonomies(),
			'default' => 'category',
			'condition' => ['item_type' => 'query_terms']
		]);
		$repeater->add_control('query_terms_hide_empty', [
			'label' => 'Hide Empty',
			'type' => \Elementor\Controls_Manager::SWITCHER,
			'default' => 'yes',
			'condition' => ['item_type' => 'query_terms']
		]);
		$repeater->add_control('query_terms_count', [
			'label' => 'Number of Terms',
			'type' => \Elementor\Controls_Manager::NUMBER,
			'default' => 4,
			'condition' => ['item_type' => 'query_terms']
		]);
		$repeater->add_control('query_terms_include', [
			'label' => 'Specific Term IDs (Optional)',
			'type' => \Elementor\Controls_Manager::TEXT,
			'description' => 'Comma separated term IDs (e.g. 5,12,194)',
			'condition' => ['item_type' => 'query_terms']
		]);
		$repeater->add_control('query_terms_meta_key', [
			'label' => 'Meta Key (Optional)',
			'type' => \Elementor\Controls_Manager::TEXT,
			'description' => 'e.g. destination_public_status',
			'condition' => ['item_type' => 'query_terms']
		]);
		$repeater->add_control('query_terms_meta_value', [
			'label' => 'Meta Value (Optional)',
			'type' => \Elementor\Controls_Manager::TEXT,
			'description' => 'e.g. true',
			'condition' => ['item_type' => 'query_terms']
		]);
		$repeater->add_control('query_terms_advanced_meta', [
			'label' => 'Multiple Meta Filters',
			'type' => \Elementor\Controls_Manager::TEXTAREA,
			'description' => 'Enter one filter per line: key=value (e.g. status=active)',
			'condition' => ['item_type' => 'query_terms']
		]);
		$repeater->add_control('query_terms_link_type', [
			'label' => 'Link Destination',
			'type' => \Elementor\Controls_Manager::SELECT,
			'options' => [
				'default' => 'Default Term Archive',
				'cpt_archive' => 'Filtered Post Type Archive',
			],
			'default' => 'default',
			'condition' => ['item_type' => 'query_terms']
		]);
		$repeater->add_control('query_terms_cpt', [
			'label' => 'Select Post Type',
			'type' => \Elementor\Controls_Manager::SELECT2,
			'options' => ag_get_post_types(),
			'default' => 'post',
			'condition' => [
				'item_type' => 'query_terms',
				'query_terms_link_type' => 'cpt_archive'
			]
		]);
		$repeater->add_control('term_image_meta_key', [
			'label' => 'Term Image Meta Key (Optional)',
			'type' => \Elementor\Controls_Manager::TEXT,
			'description' => 'e.g. thumbnail_id or featured_image',
			'condition' => ['item_type' => ['query_terms', 'jet_query']]
		]);
		$repeater->add_control('jet_query_id', [
			'label' => 'JetEngine Query ID',
			'type' => \Elementor\Controls_Manager::NUMBER,
			'description' => 'Enter the numeric ID of the query from JetEngine',
			'condition' => ['item_type' => 'jet_query']
		]);
	}

	function ag_add_icon_controls_to_repeater($repeater, $default_type = 'icon', $default_text = 'jet', $default_icon = 'fas fa-star') {
		$repeater->add_control('icon_type', [
			'label' => 'Icon Type',
			'type' => \Elementor\Controls_Manager::CHOOSE,
			'options' => [
				'icon' => ['title' => 'Icon', 'icon' => 'eicon-star'],
				'text' => ['title' => 'Text', 'icon' => 'eicon-t-letter'],
				'image' => ['title' => 'Image', 'icon' => 'eicon-image-bold'],
				'none' => ['title' => 'None', 'icon' => 'eicon-ban'],
			],
			'default' => $default_type,
			'toggle' => false,
		]);
		$repeater->add_control('bg_color', [
			'label' => 'Icon Background Color',
			'type' => \Elementor\Controls_Manager::COLOR,
			'description' => 'Color of the box behind the icon/text (e.g. #384050)',
			'condition' => ['icon_type!' => 'none'],
		]);
		$repeater->add_control('item_icon', [
			'label' => 'Icon',
			'type' => \Elementor\Controls_Manager::ICONS,
			'default' => ['value' => $default_icon, 'library' => 'fa-solid'],
			'condition' => ['icon_type' => 'icon'],
		]);
		$repeater->add_control('item_text', [
			'label' => 'Text',
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => $default_text,
			'condition' => ['icon_type' => 'text'],
		]);
		$repeater->add_control('icon_color', [
			'label' => 'Icon / Text Color',
			'type' => \Elementor\Controls_Manager::COLOR,
			'default' => '#ffffff',
			'condition' => ['icon_type' => ['icon', 'text']],
		]);
		$repeater->add_control('item_image', [
			'label' => 'Image',
			'type' => \Elementor\Controls_Manager::MEDIA,
			'condition' => ['icon_type' => 'image'],
		]);
	}

	function ag_process_dynamic_features($features) {
		if (empty($features)) return [];
		$processed = [];
		foreach ($features as $item) {
			$type = $item['item_type'] ?? 'manual';
			if ($type === 'manual') {
				$processed[] = $item;
			} elseif ($type === 'template') {
				$processed[] = $item;
			} elseif ($type === 'query') {
				$args = [
					'post_type' => $item['query_post_type'] ?? 'post',
					'posts_per_page' => intval($item['query_count'] ?? 4),
				];
				if (!empty($item['query_taxonomy']) && !empty($item['query_term'])) {
					$term_val = trim($item['query_term']);
					$field = is_numeric($term_val) ? 'term_id' : 'slug';
					$args['tax_query'] = [
						[
							'taxonomy' => $item['query_taxonomy'],
							'field'    => $field,
							'terms'    => $term_val,
						],
					];
				}
				$query = new \WP_Query($args);
				if ($query->have_posts()) {
					while ($query->have_posts()) {
						$query->the_post();
						$fake_item = [
							'item_type' => 'manual',
							'display_format' => $item['display_format'] ?? 'all',
							'title' => get_the_title(),
							'desc' => get_the_excerpt() ?: wp_trim_words(get_the_content(), 10),
							'link' => ['url' => get_permalink()],
							'tab_assignment' => $item['tab_assignment'] ?? '',
							'icon_type' => 'image',
							'item_image' => ['url' => get_the_post_thumbnail_url(get_the_ID(), 'thumbnail')],
							'bg_color' => $item['bg_color'] ?? '',
							'icon_color' => $item['icon_color'] ?? '',
						];
						if (empty($fake_item['item_image']['url'])) {
							$fake_item['icon_type'] = $item['icon_type'] ?? 'icon';
							$fake_item['item_icon'] = $item['item_icon'] ?? [];
							$fake_item['item_text'] = $item['item_text'] ?? '';
						}
						$processed[] = $fake_item;
					}
					wp_reset_postdata();
				}
			} elseif ($type === 'query_terms') {
				$tax = $item['query_terms_tax'] ?? 'category';
				$args = [
					'taxonomy' => $tax,
					'hide_empty' => ($item['query_terms_hide_empty'] ?? 'yes') === 'yes',
					'number' => intval($item['query_terms_count'] ?? 4),
				];
				if (!empty($item['query_terms_include'])) {
					$args['include'] = array_map('intval', explode(',', $item['query_terms_include']));
				}
				$meta_query = [];
				if (!empty($item['query_terms_meta_key'])) {
					$meta_query[] = [
						'key' => $item['query_terms_meta_key'],
						'value' => $item['query_terms_meta_value'] ?? '',
						'compare' => '='
					];
				}
				if (!empty($item['query_terms_advanced_meta'])) {
					$lines = explode("\n", $item['query_terms_advanced_meta']);
					foreach ($lines as $line) {
						$line = trim($line);
						if (empty($line) || strpos($line, '=') === false) continue;
						list($m_key, $m_val) = explode('=', $line, 2);
						$meta_query[] = [
							'key' => trim($m_key),
							'value' => trim($m_val),
							'compare' => '='
						];
					}
				}
				if (!empty($meta_query)) {
					$args['meta_query'] = $meta_query;
				}
				$terms = get_terms($args);
				if (!is_wp_error($terms) && !empty($terms)) {
					foreach ($terms as $term) {
						$term_link = get_term_link($term);
						if (!is_wp_error($term_link)) {
							if (($item['query_terms_link_type'] ?? 'default') === 'cpt_archive' && !empty($item['query_terms_cpt'])) {
								$cpt_link = get_post_type_archive_link($item['query_terms_cpt']);
								if ($cpt_link) {
									$term_link = add_query_arg($term->taxonomy, $term->slug, $cpt_link);
								} else {
									$term_link = add_query_arg('post_type', $item['query_terms_cpt'], $term_link);
								}
							}
						} else {
							$term_link = '#';
						}
						
						$fake_item = [
							'item_type' => 'manual',
							'display_format' => $item['display_format'] ?? 'all',
							'title' => $term->name,
							'desc' => $term->description,
							'link' => ['url' => $term_link],
							'tab_assignment' => $item['tab_assignment'] ?? '',
							'icon_type' => $item['icon_type'] ?? 'icon',
							'item_icon' => $item['item_icon'] ?? [],
							'item_text' => $item['item_text'] ?? '',
							'bg_color' => $item['bg_color'] ?? '',
							'icon_color' => $item['icon_color'] ?? '',
						];
						if (!empty($item['term_image_meta_key'])) {
							$meta_val = get_term_meta($term->term_id, $item['term_image_meta_key'], true);
							if (!empty($meta_val)) {
								if (is_numeric($meta_val)) {
									$img_url = wp_get_attachment_image_url($meta_val, 'thumbnail');
									if ($img_url) {
										$fake_item['icon_type'] = 'image';
										$fake_item['item_image'] = ['url' => $img_url];
									}
								} elseif (is_string($meta_val) && filter_var($meta_val, FILTER_VALIDATE_URL)) {
									$fake_item['icon_type'] = 'image';
									$fake_item['item_image'] = ['url' => $meta_val];
								} elseif (is_array($meta_val) && !empty($meta_val['url'])) {
									$fake_item['icon_type'] = 'image';
									$fake_item['item_image'] = ['url' => $meta_val['url']];
								}
							}
						}
						$processed[] = $fake_item;
					}
				}
			} elseif ($type === 'jet_query') {
				$query_id = intval($item['jet_query_id'] ?? 0);
				if ($query_id > 0 && class_exists('\Jet_Engine\Query_Builder\Manager')) {
					$query = \Jet_Engine\Query_Builder\Manager::instance()->get_query_by_id( $query_id );
					if ($query) {
						$query->setup_query();
						$results = $query->get_items();
						if (!empty($results)) {
							foreach($results as $res) {
								$fake_item = [
									'item_type' => 'manual',
									'display_format' => $item['display_format'] ?? 'all',
									'tab_assignment' => $item['tab_assignment'] ?? '',
									'icon_type' => $item['icon_type'] ?? 'icon',
									'item_icon' => $item['item_icon'] ?? [],
									'bg_color' => $item['bg_color'] ?? '',
									'icon_color' => $item['icon_color'] ?? '',
								];
								if (is_a($res, 'WP_Post')) {
									$fake_item['title'] = $res->post_title;
									$fake_item['desc'] = $res->post_excerpt ?: wp_trim_words($res->post_content, 10);
									$fake_item['link'] = ['url' => get_permalink($res->ID)];
									$thumb_url = get_the_post_thumbnail_url($res->ID, 'thumbnail');
									if ($thumb_url) {
										$fake_item['icon_type'] = 'image';
										$fake_item['item_image'] = ['url' => $thumb_url];
									}
								} elseif (is_a($res, 'WP_Term')) {
									$fake_item['title'] = $res->name;
									$fake_item['desc'] = $res->description;
									$fake_item['link'] = ['url' => get_term_link($res)];
									if (!empty($item['term_image_meta_key'])) {
										$meta_val = get_term_meta($res->term_id, $item['term_image_meta_key'], true);
										if (!empty($meta_val)) {
											if (is_numeric($meta_val)) {
												$img_url = wp_get_attachment_image_url($meta_val, 'thumbnail');
												if ($img_url) {
													$fake_item['icon_type'] = 'image';
													$fake_item['item_image'] = ['url' => $img_url];
												}
											} elseif (is_string($meta_val) && filter_var($meta_val, FILTER_VALIDATE_URL)) {
												$fake_item['icon_type'] = 'image';
												$fake_item['item_image'] = ['url' => $meta_val];
											} elseif (is_array($meta_val) && !empty($meta_val['url'])) {
												$fake_item['icon_type'] = 'image';
												$fake_item['item_image'] = ['url' => $meta_val['url']];
											}
										}
									}
								} elseif (is_array($res) || is_object($res)) {
									$res_arr = (array)$res;
									$fake_item['title'] = $res_arr['post_title'] ?? $res_arr['name'] ?? $res_arr['title'] ?? 'Item';
									$fake_item['desc'] = $res_arr['post_excerpt'] ?? $res_arr['description'] ?? $res_arr['desc'] ?? '';
									$fake_item['link'] = ['url' => '#'];
								}
								$processed[] = $fake_item;
							}
						}
					}
				}
			}
		}
		return $processed;
	}

	function ag_render_feature_item($item) {
		if (($item['item_type'] ?? 'manual') === 'template') {
			if (!empty($item['template_id'])) {
				echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display($item['template_id']);
			}
			return;
		}
		$format = $item['display_format'] ?? 'all';
		$desc = wp_strip_all_tags($item['desc'] ?? '');
		?>
		<a href="<?php echo esc_attr($item['link']['url'] ?? '#'); ?>" class="template-item format-<?php echo esc_attr($format); ?>">
			<?php if ($format !== 'title_only') ag_render_icon_box($item); ?>
			<div class="item-content">
				<h4><?php echo esc_html($item['title'] ?? ''); ?></h4>
				<?php if ($format === 'all' && !empty($desc)): ?>
					<p><?php echo esc_html($desc); ?></p>
				<?php endif; ?>
			</div>
		</a>
		<?php
	}
	function ag_render_icon_box($item) {
		$type = $item['icon_type'] ?? 'icon';
		if ($type === 'none') return;
		
		$bg_style = !empty($item['bg_color']) ? 'background-color: ' . esc_attr($item['bg_color']) . ';' : '';
		$icon_color = !empty($item['icon_color']) ? esc_attr($item['icon_color']) : '#ffffff';
		
		echo '<div class="icon-box" style="' . $bg_style . '">';
		if ($type === 'text') {
			echo '<span class="icon-text" style="color: '.$icon_color.';">' . esc_html($item['item_text'] ?? '') . '</span>';
		} elseif ($type === 'image' && !empty($item['item_image']['url'])) {
			echo '<img src="' . esc_url($item['item_image']['url']) . '" alt="" style="width:100%; height:100%; object-fit:cover; border-radius:10px;">';
		} elseif ($type === 'icon' && !empty($item['item_icon']['value'])) {
			echo '<div style="color: '.$icon_color.'; fill: '.$icon_color.'; stroke: '.$icon_color.'; display: flex; align-items: center; justify-content: center;">';
			\Elementor\Icons_Manager::render_icon( $item['item_icon'], [ 'aria-hidden' => 'true' ] );
			echo '</div>';
		} else {
			echo '<svg style="color: '.$icon_color.'; stroke: '.$icon_color.';" viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M20 14H4v-4h16v4zM16 10V6a4 4 0 0 0-8 0v4M4 14v6h16v-6"/></svg>';
		}
		echo '</div>';
	}

	// =========================================================================
	// HELPER CONTROLS (V17)
	// =========================================================================
	function ag_add_bottom_links_controls($widget) {
		$widget->start_controls_section('bottom_links_sec', ['label' => 'Bottom CTA Buttons', 'tab' => \Elementor\Controls_Manager::TAB_CONTENT]);
		$btn_repeater = new \Elementor\Repeater();
		$btn_repeater->add_control('title', ['label' => 'Button Text', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Click Here']);
		$btn_repeater->add_control('link', ['label' => 'Link', 'type' => \Elementor\Controls_Manager::URL, 'default' => ['url' => '#']]);
		$btn_repeater->add_control('style', [
			'label' => 'Button Style', 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'outline',
			'options' => [ 'solid' => 'Solid', 'outline' => 'Outline', 'text' => 'Text Only (Link)' ]
		]);
		$btn_repeater->add_control('custom_color', [
			'label' => 'Custom Color (Optional)', 'type' => \Elementor\Controls_Manager::COLOR,
			'description' => 'Leave empty to use the global Accent Color.',
		]);
		$widget->add_control('bottom_links', [
			'label' => 'Buttons', 'type' => \Elementor\Controls_Manager::REPEATER, 'fields' => $btn_repeater->get_controls(),
			'default' => [ ['title' => 'See all >', 'style' => 'text'] ],
			'title_field' => '{{{ title }}}',
		]);
		$widget->end_controls_section();
	}

	function ag_render_bottom_links($settings) {
		if(!empty($settings['bottom_links'])) {
			echo '<div class="bottom-links-container">';
			foreach($settings['bottom_links'] as $btn) {
				$class = 'ag-btn-' . ($btn['style'] ?? 'text');
				$has_custom_color = !empty($btn['custom_color']) ? ' has-custom-color' : '';
				$inline_style = !empty($btn['custom_color']) ? ' style="--btn-color: ' . esc_attr($btn['custom_color']) . ';"' : '';
				echo '<a href="' . esc_attr($btn['link']['url'] ?? '#') . '" class="' . esc_attr($class . $has_custom_color) . '"' . $inline_style . '>' . esc_html($btn['title'] ?? '') . '</a>';
			}
			echo '</div>';
		}
	}

	function ag_add_right_sidebar_controls($widget, $default_title = 'Additional Tools') {
		$widget->start_controls_section('right_sec', ['label' => 'Optional Right Sidebar', 'tab' => \Elementor\Controls_Manager::TAB_CONTENT]);
		$widget->add_control('show_right_sidebar', [
			'label' => 'Enable Right Sidebar?',
			'type' => \Elementor\Controls_Manager::SWITCHER,
			'label_on' => 'Yes',
			'label_off' => 'No',
			'return_value' => 'yes',
			'default' => 'yes',
		]);
		$widget->add_control('right_title', ['label' => 'Title', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => $default_title, 'condition' => ['show_right_sidebar' => 'yes']]);
		
		$top_items_repeater = new \Elementor\Repeater();
		$top_items_repeater->add_control('title', ['label' => 'Title', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Tool']);
		$top_items_repeater->add_control('desc', ['label' => 'Description', 'type' => \Elementor\Controls_Manager::TEXTAREA, 'default' => 'Description']);
		$top_items_repeater->add_control('link', ['label' => 'Link', 'type' => \Elementor\Controls_Manager::URL, 'default' => ['url' => '#']]);
		ag_add_icon_controls_to_repeater($top_items_repeater, 'text', 'jet');

		$widget->add_control('right_top_items', [
			'label' => 'Special Top Items', 'type' => \Elementor\Controls_Manager::REPEATER, 'fields' => $top_items_repeater->get_controls(),
			'condition' => ['show_right_sidebar' => 'yes'],
			'title_field' => '{{{ title }}}',
		]);

		$r_repeater = new \Elementor\Repeater();
		$r_repeater->add_control('title', ['label' => 'Title', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Tool']);
		$r_repeater->add_control('link', ['label' => 'Link', 'type' => \Elementor\Controls_Manager::URL, 'default' => ['url' => '#']]);
		
		$widget->add_control('r_list', [
			'label' => 'Plain Text Links', 'type' => \Elementor\Controls_Manager::REPEATER, 'fields' => $r_repeater->get_controls(),
			'default' => [['title' => 'Dynamic Templates']],
			'condition' => ['show_right_sidebar' => 'yes'],
			'title_field' => '{{{ title }}}',
		]);
		$widget->end_controls_section();
	}

	function ag_render_right_sidebar($settings) {
		if(($settings['show_right_sidebar'] ?? 'yes') !== 'yes') return;
		echo '<div class="right-column">';
		if(!empty($settings['right_title'])) {
			echo '<h3 class="column-title">' . esc_html($settings['right_title']) . '</h3>';
		}
		if(!empty($settings['right_top_items'])) {
			foreach($settings['right_top_items'] as $titem) {
				echo '<a href="' . esc_attr($titem['link']['url'] ?? '#') . '" class="template-item special-top-item" style="margin-bottom: 25px; padding: 0;">';
				ag_render_icon_box($titem);
				echo '<div class="item-content">';
				echo '<h4>' . esc_html($titem['title'] ?? '') . '</h4>';
				echo '<p>' . esc_html($titem['desc'] ?? '') . '</p>';
				echo '</div></a>';
			}
		}
		if(!empty($settings['r_list'])) {
			echo '<ul class="niches-list">';
			foreach($settings['r_list'] as $niche) {
				echo '<li><a href="' . esc_attr($niche['link']['url'] ?? '#') . '">' . esc_html($niche['title'] ?? '') . '</a></li>';
			}
			echo '</ul>';
		}
		echo '</div>';
	}

	// =========================================================================
	// WIDGET 1: Dynamic Templates (Style 1)
	// =========================================================================
	class Antigravity_Mega_Menu_Style_1 extends \Elementor\Widget_Base {
		public function get_name() { return 'mega_menu_style_1'; }
		public function get_title() { return esc_html__( 'Mega Menu (Dynamic Templates)', 'custom-mega-menu' ); }
		public function get_icon() { return 'eicon-mega-menu'; }
		public function get_categories() { return [ 'general' ]; }

		protected function register_controls() {
			$this->start_controls_section('left_sec', ['label' => 'Main Grid (Left)', 'tab' => \Elementor\Controls_Manager::TAB_CONTENT]);
			$this->add_control('left_title', ['label' => 'Title', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Dynamic Templates']);
			
			$repeater = new \Elementor\Repeater();
			ag_add_dynamic_controls_to_repeater($repeater);
			ag_add_icon_controls_to_repeater($repeater, 'icon', '', 'fas fa-box');

			$this->add_control('list', [
				'label' => 'Templates', 'type' => \Elementor\Controls_Manager::REPEATER, 'fields' => $repeater->get_controls(),
				'default' => [
					['title' => 'E-Commerce Shop', 'desc' => 'WooCommerce website template for Elementor'],
					['title' => 'Job Board Website', 'desc' => 'Dynamic job board website for Elementor'],
				],
				'title_field' => '{{{ title }}}',
			]);
			$this->end_controls_section();

			ag_add_bottom_links_controls($this);
			ag_add_right_sidebar_controls($this, 'All Niches');
			ag_add_style_controls($this);
		}

		protected function render() {
			$id = $this->get_id();
			$settings = $this->get_settings_for_display();
			$no_sidebar = (($settings['show_right_sidebar'] ?? 'yes') !== 'yes') ? 'no-sidebar' : '';
			?>
			<div class="mega-menu-wrapper mega-menu-<?php echo $id; ?>">
				<div class="menu-container <?php echo $no_sidebar; ?>">
					<div class="left-column">
						<h3 class="column-title"><?php echo esc_html( $settings['left_title'] ?? '' ); ?></h3>
						<div class="templates-grid">
							<?php $list = ag_process_dynamic_features($settings['list'] ?? []); if(!empty($list)) foreach($list as $item): ?>
								<?php ag_render_feature_item($item); ?>
							<?php endforeach; ?>
						</div>
						<?php ag_render_bottom_links($settings); ?>
					</div>
					<?php ag_render_right_sidebar($settings); ?>
				</div>
			</div>
			<style>
			<?php echo ag_get_base_css($id); ?>
			</style>
			<?php
		}
	}

	// =========================================================================
	// WIDGET 2: Plugins (Style 2) - UNRESTRICTED
	// =========================================================================
	class Antigravity_Mega_Menu_Style_2 extends \Elementor\Widget_Base {
		public function get_name() { return 'mega_menu_style_2'; }
		public function get_title() { return esc_html__( 'Mega Menu (Plugins - Flexible)', 'custom-mega-menu' ); }
		public function get_icon() { return 'eicon-apps'; }
		public function get_categories() { return [ 'general' ]; }

		protected function register_controls() {
			$this->start_controls_section('left_sec', ['label' => 'Main Grid (Left)', 'tab' => \Elementor\Controls_Manager::TAB_CONTENT]);
			$this->add_control('left_title', ['label' => 'Title', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Plugins']);
			
			$repeater = new \Elementor\Repeater();
			ag_add_dynamic_controls_to_repeater($repeater);
			ag_add_icon_controls_to_repeater($repeater, 'text', 'jet');

			$this->add_control('list', [
				'label' => 'Grid Items', 'type' => \Elementor\Controls_Manager::REPEATER, 'fields' => $repeater->get_controls(),
				'default' => [
					['title' => 'JetEngine', 'desc' => 'Use powerful WordPress...', 'bg_color' => '#8952f1'],
				],
				'title_field' => '{{{ title }}}',
			]);
			$this->end_controls_section();

			ag_add_bottom_links_controls($this);
			ag_add_right_sidebar_controls($this, 'Additional Tools');
			ag_add_style_controls($this);
		}

		protected function render() {
			$id = $this->get_id();
			$settings = $this->get_settings_for_display();
			$no_sidebar = (($settings['show_right_sidebar'] ?? 'yes') !== 'yes') ? 'no-sidebar' : '';
			?>
			<div class="mega-menu-wrapper mega-menu-<?php echo $id; ?>">
				<div class="menu-container <?php echo $no_sidebar; ?>">
					<div class="left-column">
						<h3 class="column-title"><?php echo esc_html($settings['left_title'] ?? ''); ?></h3>
						<div class="plugins-grid">
							<?php $list = ag_process_dynamic_features($settings['list'] ?? []); if(!empty($list)) foreach($list as $item): ?>
								<?php ag_render_feature_item($item); ?>
							<?php endforeach; ?>
						</div>
						<?php ag_render_bottom_links($settings); ?>
					</div>
					<?php ag_render_right_sidebar($settings); ?>
				</div>
			</div>
			<style>
			<?php echo ag_get_base_css($id); ?>
			.mega-menu-<?php echo $id; ?> .special-top-item:hover { background: transparent; opacity: 0.8; }
			</style>
			<?php
		}
	}

	// =========================================================================
	// WIDGET 3: Features (Style 3)
	// =========================================================================
	class Antigravity_Mega_Menu_Style_3 extends \Elementor\Widget_Base {
		public function get_name() { return 'mega_menu_style_3'; }
		public function get_title() { return esc_html__( 'Mega Menu (Features)', 'custom-mega-menu' ); }
		public function get_icon() { return 'eicon-table'; }
		public function get_categories() { return [ 'general' ]; }

		protected function register_controls() {
			$this->start_controls_section('main_sec', ['label' => 'Main Grid (Left)', 'tab' => \Elementor\Controls_Manager::TAB_CONTENT]);
			$this->add_control('main_title', ['label' => 'Title', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Features']);
			
			$repeater = new \Elementor\Repeater();
			ag_add_dynamic_controls_to_repeater($repeater);
			ag_add_icon_controls_to_repeater($repeater, 'icon', '', 'fas fa-list');

			$this->add_control('list', [
				'label' => 'Features', 'type' => \Elementor\Controls_Manager::REPEATER, 'fields' => $repeater->get_controls(),
				'default' => [
					['title' => 'AI MCP Server', 'desc' => 'Control site setup'],
				],
				'title_field' => '{{{ title }}}',
			]);
			$this->end_controls_section();

			ag_add_bottom_links_controls($this);
			ag_add_right_sidebar_controls($this, 'Additional Resources');
			
			// Change default show_right_sidebar to 'no' for style 3, since it was previously full width.
			$this->update_control('show_right_sidebar', ['default' => '']);

			ag_add_style_controls($this);
		}

		protected function render() {
			$id = $this->get_id();
			$settings = $this->get_settings_for_display();
			$no_sidebar = (($settings['show_right_sidebar'] ?? 'no') !== 'yes') ? 'no-sidebar' : '';
			?>
			<div class="mega-menu-wrapper mega-menu-<?php echo $id; ?>">
				<div class="menu-container <?php echo $no_sidebar; ?>">
					<div class="left-column">
						<h3 class="column-title"><?php echo esc_html($settings['main_title'] ?? ''); ?></h3>
						<div class="features-grid">
							<?php $list = ag_process_dynamic_features($settings['list'] ?? []); if(!empty($list)) foreach($list as $item): ?>
								<?php ag_render_feature_item($item); ?>
							<?php endforeach; ?>
						</div>
						<?php ag_render_bottom_links($settings); ?>
					</div>
					<?php ag_render_right_sidebar($settings); ?>
				</div>
			</div>
			<style>
			<?php echo ag_get_base_css($id); ?>
			</style>
			<?php
		}
	}

	// =========================================================================
	// WIDGET 4: Vertical Tabs Mega Menu (Style 4) - 1 Level
	// =========================================================================
	class Antigravity_Mega_Menu_Style_4 extends \Elementor\Widget_Base {
		public function get_name() { return 'mega_menu_style_4'; }
		public function get_title() { return esc_html__( 'Mega Menu (Vertical Tabs)', 'custom-mega-menu' ); }
		public function get_icon() { return 'eicon-tabs'; }
		public function get_categories() { return [ 'general' ]; }

		protected function register_controls() {
			$this->start_controls_section('tabs_sec', ['label' => 'Sidebar Tabs', 'tab' => \Elementor\Controls_Manager::TAB_CONTENT]);
			
			$tab_repeater = new \Elementor\Repeater();
			$tab_repeater->add_control('tab_id', ['label' => 'Tab ID (Must be unique, e.g. "tab1")', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'tab1']);
			$tab_repeater->add_control('tab_title', ['label' => 'Tab Title', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Tab Name']);
			
			$this->add_control('tabs_list', [
				'label' => 'Tabs', 'type' => \Elementor\Controls_Manager::REPEATER, 'fields' => $tab_repeater->get_controls(),
				'default' => [
					['tab_id' => 'tab1', 'tab_title' => 'JetEngine'],
					['tab_id' => 'tab2', 'tab_title' => 'JetElements'],
				],
				'title_field' => '{{{ tab_title }}} (ID: {{{ tab_id }}})',
			]);
			$this->end_controls_section();

			$this->start_controls_section('items_sec', ['label' => 'Content Items', 'tab' => \Elementor\Controls_Manager::TAB_CONTENT]);
			$repeater = new \Elementor\Repeater();
			ag_add_dynamic_controls_to_repeater($repeater);
			$repeater->add_control('tab_assignment', [
				'label' => 'Assign to Tab ID',
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'tab1',
				'description' => 'Type the exact Tab ID this item belongs to.',
			]);
			ag_add_icon_controls_to_repeater($repeater, 'icon', '', 'fas fa-check');

			$this->add_control('features_list', [
				'label' => 'Features Items', 'type' => \Elementor\Controls_Manager::REPEATER, 'fields' => $repeater->get_controls(),
				'default' => [
					['title' => 'Structure', 'desc' => 'Create Custom Post Types', 'tab_assignment' => 'tab1'],
					['title' => 'Widgets', 'desc' => 'Elementor widgets', 'tab_assignment' => 'tab2'],
				],
				'title_field' => '{{{ title }}} (Tab: {{{ tab_assignment }}})',
			]);
			$this->end_controls_section();

			ag_add_bottom_links_controls($this);
			ag_add_right_sidebar_controls($this, 'Additional Tools');
			$this->update_control('show_right_sidebar', ['default' => '']); // default off

			ag_add_style_controls($this);
		}

		protected function render() {
			$id = $this->get_id();
			$settings = $this->get_settings_for_display();
			
			$tabs = [];
			if(!empty($settings['tabs_list'])) {
				foreach($settings['tabs_list'] as $t) {
					if(!empty($t['tab_id'])) {
						$tabs[$t['tab_id']] = $t['tab_title'];
					}
				}
			}

			$grouped_features = [];
			if(!empty($settings['features_list'])) {
				foreach($settings['features_list'] as $item) {
					$tab_id = trim($item['tab_assignment']);
					$grouped_features[$tab_id][] = $item;
				}
			}

			$no_sidebar = (($settings['show_right_sidebar'] ?? 'no') !== 'yes') ? 'no-sidebar' : '';
			?>
			<div class="mega-menu-wrapper mega-menu-tabs mega-menu-<?php echo $id; ?> <?php echo $no_sidebar; ?>">
				<div class="tabs-sidebar">
					<?php $first = true; foreach($tabs as $tab_id => $tab_title): ?>
						<div class="tab-link <?php if($first) echo 'active'; ?>" data-target="tab-<?php echo esc_attr($id.'-'.$tab_id); ?>" onmouseenter="agActivateTab(this, 'tab-<?php echo esc_attr($id.'-'.$tab_id); ?>')">
							<?php echo esc_html($tab_title); ?>
							<span class="arrow">&gt;</span>
						</div>
					<?php $first = false; endforeach; ?>
				</div>
				<div class="tabs-content-area">
					<?php $first = true; foreach($tabs as $tab_id => $tab_title): ?>
						<div class="mobile-accordion-title <?php if($first) echo 'active'; ?>" onclick="agToggleAccordion(this, 'tab-<?php echo esc_attr($id.'-'.$tab_id); ?>')">
							<?php echo esc_html($tab_title); ?>
							<span class="accordion-arrow"></span>
						</div>
						<div class="tab-pane <?php if($first) echo 'active'; ?>" id="tab-<?php echo esc_attr($id.'-'.$tab_id); ?>">
							<h3 class="tab-pane-title"><?php echo esc_html($tab_title); ?></h3>
							<div class="features-grid-s4">
								<?php if(!empty($grouped_features[$tab_id])) foreach($grouped_features[$tab_id] as $feature): ?>
									<?php ag_render_feature_item($feature); ?>
								<?php endforeach; ?>
							</div>
						</div>
					<?php $first = false; endforeach; ?>
					
					<?php ag_render_bottom_links($settings); ?>
				</div>
				<?php ag_render_right_sidebar($settings); ?>
			</div>
			<script>
			if (typeof agActivateTab !== 'function') {
				function agActivateTab(element, targetId) {
					var wrapper = element.closest('.mega-menu-tabs');
					var links = wrapper.querySelectorAll('.tab-link');
					var panes = wrapper.querySelectorAll('.tab-pane');
					links.forEach(l => l.classList.remove('active'));
					panes.forEach(p => p.classList.remove('active'));
					element.classList.add('active');
					var targetPane = document.getElementById(targetId);
					if(targetPane) targetPane.classList.add('active');
				}
			}
			if (typeof agToggleAccordion !== 'function') {
				function agToggleAccordion(element, targetId) {
					var wrapper = element.closest('.mega-menu-tabs');
					var pane = document.getElementById(targetId);
					
					if (element.classList.contains('active')) {
						element.classList.remove('active');
						pane.classList.remove('active');
						return;
					}
					
					var parentPane = element.parentElement.closest('.tab-pane');
					if (parentPane) {
						var titles = parentPane.querySelectorAll('.mobile-accordion-title');
						var panes = parentPane.querySelectorAll('.tab-pane');
						titles.forEach(t => t.classList.remove('active'));
						panes.forEach(p => p.classList.remove('active'));
					} else {
						var titles = wrapper.querySelectorAll('.mobile-accordion-title');
						var panes = wrapper.querySelectorAll('.tab-pane');
						titles.forEach(t => t.classList.remove('active'));
						panes.forEach(p => p.classList.remove('active'));
					}
					
					element.classList.add('active');
					pane.classList.add('active');
				}
			}
			</script>
			<style>
			<?php echo ag_get_base_css($id); ?>
			</style>
			<?php
		}
	}

	// =========================================================================
	// WIDGET 5: Multi-Level Vertical Tabs (Style 5)
	// =========================================================================
	class Antigravity_Mega_Menu_Style_5 extends \Elementor\Widget_Base {
		public function get_name() { return 'mega_menu_style_5'; }
		public function get_title() { return esc_html__( 'Mega Menu (Multi-Level Tabs)', 'custom-mega-menu' ); }
		public function get_icon() { return 'eicon-folder-o'; }
		public function get_categories() { return [ 'general' ]; }

		protected function register_controls() {
			$this->start_controls_section('l1_sec', ['label' => 'Level 1 (Main Tabs)', 'tab' => \Elementor\Controls_Manager::TAB_CONTENT]);
			$l1_repeater = new \Elementor\Repeater();
			$l1_repeater->add_control('l1_id', ['label' => 'Main Tab ID', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'tools']);
			$l1_repeater->add_control('l1_title', ['label' => 'Title', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Tools']);
			$this->add_control('l1_tabs', [
				'label' => 'Main Tabs', 'type' => \Elementor\Controls_Manager::REPEATER, 'fields' => $l1_repeater->get_controls(),
				'default' => [['l1_id' => 'tools', 'l1_title' => 'Tools']],
				'title_field' => '{{{ l1_title }}} (ID: {{{ l1_id }}})',
			]);
			$this->end_controls_section();

			$this->start_controls_section('l2_sec', ['label' => 'Level 2 (Sub Tabs)', 'tab' => \Elementor\Controls_Manager::TAB_CONTENT]);
			$l2_repeater = new \Elementor\Repeater();
			$l2_repeater->add_control('l2_id', ['label' => 'Sub Tab ID', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'jetengine']);
			$l2_repeater->add_control('l2_title', ['label' => 'Title', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'JetEngine']);
			$l2_repeater->add_control('parent_l1_id', ['label' => 'Belongs to Main Tab ID', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'tools']);
			$this->add_control('l2_tabs', [
				'label' => 'Sub Tabs', 'type' => \Elementor\Controls_Manager::REPEATER, 'fields' => $l2_repeater->get_controls(),
				'default' => [
					['l2_id' => 'jetengine', 'l2_title' => 'JetEngine', 'parent_l1_id' => 'tools'],
					['l2_id' => 'jetelements', 'l2_title' => 'JetElements', 'parent_l1_id' => 'tools'],
				],
				'title_field' => '{{{ l2_title }}} (ID: {{{ l2_id }}}, Parent: {{{ parent_l1_id }}})',
			]);
			$this->end_controls_section();

			$this->start_controls_section('items_sec', ['label' => 'Content Items', 'tab' => \Elementor\Controls_Manager::TAB_CONTENT]);
			$repeater = new \Elementor\Repeater();
			ag_add_dynamic_controls_to_repeater($repeater);
			$repeater->add_control('tab_assignment', [
				'label' => 'Assign to Tab ID (Level 1 or Level 2)',
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'jetengine',
			]);
			ag_add_icon_controls_to_repeater($repeater, 'icon', '', 'fas fa-check');

			$this->add_control('features_list', [
				'label' => 'Features Items', 'type' => \Elementor\Controls_Manager::REPEATER, 'fields' => $repeater->get_controls(),
				'default' => [
					['title' => 'Structure', 'desc' => 'Create Custom Post Types', 'tab_assignment' => 'jetengine'],
					['title' => 'Widgets', 'desc' => 'Elementor widgets', 'tab_assignment' => 'jetelements'],
				],
				'title_field' => '{{{ title }}} (Tab: {{{ tab_assignment }}})',
			]);
			$this->end_controls_section();

			ag_add_bottom_links_controls($this);
			ag_add_right_sidebar_controls($this, 'Additional Tools');
			$this->update_control('show_right_sidebar', ['default' => '']); // default off

			ag_add_style_controls($this);
		}

		protected function render() {
			$id = $this->get_id();
			$settings = $this->get_settings_for_display();
			
			$l1_tabs = $settings['l1_tabs'] ?? [];
			$l2_tabs = $settings['l2_tabs'] ?? [];
			$features = ag_process_dynamic_features($settings['features_list'] ?? []);

			$grouped_features = [];
			foreach($features as $item) {
				$tab_id = trim($item['tab_assignment']);
				$grouped_features[$tab_id][] = $item;
			}
			
			$wrapper_id = 'ag-multi-' . $id;
			$no_sidebar = (($settings['show_right_sidebar'] ?? 'no') !== 'yes') ? 'no-sidebar' : '';
			?>
			<div class="mega-menu-wrapper mega-menu-tabs mega-menu-multi mega-menu-<?php echo $id; ?> <?php echo $no_sidebar; ?>" id="<?php echo esc_attr($wrapper_id); ?>">
				<div class="tabs-sidebar l1-sidebar">
					<?php $first = true; foreach($l1_tabs as $l1): if(empty($l1['l1_id'])) continue; ?>
						<div class="tab-link l1-link <?php if($first) echo 'active'; ?>" data-l1="<?php echo esc_attr($l1['l1_id']); ?>" onmouseenter="agActivateL1('<?php echo esc_attr($wrapper_id); ?>', this, '<?php echo esc_attr($l1['l1_id']); ?>')">
							<?php echo esc_html($l1['l1_title']); ?>
							<span class="arrow">&gt;</span>
						</div>
					<?php $first = false; endforeach; ?>
				</div>

				<div class="tabs-sidebar l2-sidebar">
					<?php foreach($l2_tabs as $l2): if(empty($l2['l2_id'])) continue; ?>
						<div class="tab-link l2-link" data-parent-l1="<?php echo esc_attr($l2['parent_l1_id']); ?>" data-l2="<?php echo esc_attr($l2['l2_id']); ?>" onmouseenter="agActivateL2('<?php echo esc_attr($wrapper_id); ?>', this, '<?php echo esc_attr($l2['l2_id']); ?>')">
							<?php echo esc_html($l2['l2_title']); ?>
							<span class="arrow">&gt;</span>
						</div>
					<?php endforeach; ?>
				</div>

				<div class="tabs-content-area">
					<?php 
					$first_l1 = true;
					foreach($l1_tabs as $l1): 
						if(empty($l1['l1_id'])) continue;
						$l1_id = $l1['l1_id'];
					?>
						<div class="mobile-accordion-title l1-accordion <?php if($first_l1) echo 'active'; ?>" onclick="agToggleAccordion(this, 'pane-<?php echo esc_attr($wrapper_id . '-' . $l1_id); ?>')">
							<?php echo esc_html($l1['l1_title']); ?>
							<span class="accordion-arrow"></span>
						</div>
						<div class="tab-pane l1-pane <?php if($first_l1) echo 'active'; ?>" id="pane-<?php echo esc_attr($wrapper_id . '-' . $l1_id); ?>">
							<h3 class="tab-pane-title"><?php echo esc_html($l1['l1_title']); ?></h3>
							
							<div class="features-grid-s4">
								<?php if(!empty($grouped_features[$l1_id])) foreach($grouped_features[$l1_id] as $feature): ?>
									<?php ag_render_feature_item($feature); ?>
								<?php endforeach; ?>
							</div>

							<?php 
							$first_l2 = true;
							foreach($l2_tabs as $l2): 
								if(empty($l2['l2_id']) || $l2['parent_l1_id'] !== $l1_id) continue;
								$l2_id = $l2['l2_id'];
							?>
								<div class="mobile-accordion-title l2-accordion <?php if($first_l1 && $first_l2) echo 'active'; ?>" onclick="agToggleAccordion(this, 'pane-<?php echo esc_attr($wrapper_id . '-' . $l2_id); ?>')">
									<?php echo esc_html($l2['l2_title']); ?>
									<span class="accordion-arrow"></span>
								</div>
								<div class="tab-pane l2-pane <?php if($first_l1 && $first_l2) echo 'active'; ?>" id="pane-<?php echo esc_attr($wrapper_id . '-' . $l2_id); ?>">
									<h3 class="tab-pane-title"><?php echo esc_html($l2['l2_title']); ?></h3>
									<div class="features-grid-s4">
										<?php if(!empty($grouped_features[$l2_id])) foreach($grouped_features[$l2_id] as $feature): ?>
											<?php ag_render_feature_item($feature); ?>
										<?php endforeach; ?>
									</div>
								</div>
							<?php 
							$first_l2 = false;
							endforeach; 
							?>
						</div>
					<?php 
					$first_l1 = false;
					endforeach; 
					?>
					
					<?php ag_render_bottom_links($settings); ?>
				</div>
				<?php ag_render_right_sidebar($settings); ?>
			</div>
			
			<script>
			if (typeof agActivateL1 !== 'function') {
				function agActivateL1(wrapperId, element, l1_id) {
					var wrapper = document.getElementById(wrapperId);
					if(!wrapper) return;
					
					var l1Links = wrapper.querySelectorAll('.l1-link');
					l1Links.forEach(l => l.classList.remove('active'));
					if(element) element.classList.add('active');

					var l2Sidebar = wrapper.querySelector('.l2-sidebar');
					var l2Links = wrapper.querySelectorAll('.l2-link');
					
					var hasL2 = false;
					var firstL2 = null;
					l2Links.forEach(l => {
						if(l.getAttribute('data-parent-l1') === l1_id) {
							l.style.display = 'flex';
							hasL2 = true;
							if(!firstL2) firstL2 = l;
						} else {
							l.style.display = 'none';
							l.classList.remove('active');
						}
					});

					var panes = wrapper.querySelectorAll('.tab-pane');
					panes.forEach(p => p.classList.remove('active'));

					if (hasL2) {
						l2Sidebar.style.display = 'block';
						if (firstL2) {
							agActivateL2(wrapperId, firstL2, firstL2.getAttribute('data-l2'));
						}
					} else {
						l2Sidebar.style.display = 'none';
						var targetPane = wrapper.querySelector('#pane-' + wrapperId + '-' + l1_id);
						if(targetPane) targetPane.classList.add('active');
					}
				}

				function agActivateL2(wrapperId, element, l2_id) {
					var wrapper = document.getElementById(wrapperId);
					if(!wrapper) return;

					var l2Links = wrapper.querySelectorAll('.l2-link');
					l2Links.forEach(l => l.classList.remove('active'));
					if(element) element.classList.add('active');

					var panes = wrapper.querySelectorAll('.tab-pane');
					panes.forEach(p => p.classList.remove('active'));

					var targetPane = wrapper.querySelector('#pane-' + wrapperId + '-' + l2_id);
					if(targetPane) {
						targetPane.classList.add('active');
						var parentPane = targetPane.closest('.l1-pane');
						if(parentPane) parentPane.classList.add('active');
					}
				}
			}
			
			document.addEventListener("DOMContentLoaded", function() {
				var wrapper = document.getElementById('<?php echo esc_js($wrapper_id); ?>');
				if(wrapper) {
					var firstL1 = wrapper.querySelector('.l1-link');
					if(firstL1) {
						var l1_id = firstL1.getAttribute('data-l1');
						agActivateL1('<?php echo esc_js($wrapper_id); ?>', firstL1, l1_id);
					}
				}
			});
			(function(){
				var wrapper = document.getElementById('<?php echo esc_js($wrapper_id); ?>');
				if(wrapper) {
					var firstL1 = wrapper.querySelector('.l1-link');
					if(firstL1) {
						var l1_id = firstL1.getAttribute('data-l1');
						agActivateL1('<?php echo esc_js($wrapper_id); ?>', firstL1, l1_id);
					}
				}
			})();
			</script>
			<style>
			<?php echo ag_get_base_css($id); ?>
			</style>
			<?php
		}
	}

	$widgets_manager->register( new \Antigravity_Mega_Menu_Style_1() );
	$widgets_manager->register( new \Antigravity_Mega_Menu_Style_2() );
	$widgets_manager->register( new \Antigravity_Mega_Menu_Style_3() );
	$widgets_manager->register( new \Antigravity_Mega_Menu_Style_4() );
	$widgets_manager->register( new \Antigravity_Mega_Menu_Style_5() );
} );
