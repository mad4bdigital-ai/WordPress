<?php

defined('ABSPATH') or die;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template variables in view files
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"
      style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
<head>
    <meta name="viewport" content="width=device-width"/>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <title><?php esc_html_e('Email Summary', 'fluentform'); ?></title>
    <style type="text/css">
        .summary_table {
            width: 100%;
            text-align: left;
            border-collapse: collapse;
        }

        .summary_table tr td {
            border: 1px solid #e0e0e0;
            padding: 4px 10px;
        }

        .summary_table tr th {
            border: 1px solid #e0e0e0;
            padding: 8px 10px;
        }

        thead {
            background: #f6f6f6;
        }

        img {
            max-width: 100%;
        }

        body {
            -webkit-font-smoothing: antialiased;
            -webkit-text-size-adjust: none;
            width: 100% !important;
            height: 100%;
            line-height: 1.6em;
        }

        body {
            background-color: #f6f6f6;
        }

        @media only screen and (max-width: 640px) {
            body {
                padding: 0 !important;
            }

            h1 {
                font-weight: 800 !important;
                margin: 20px 0 5px !important;
            }

            h2 {
                font-weight: 800 !important;
                margin: 20px 0 5px !important;
            }

            h3 {
                font-weight: 800 !important;
                margin: 20px 0 5px !important;
            }

            h4 {
                font-weight: 800 !important;
                margin: 20px 0 5px !important;
            }

            h1 {
                font-size: 22px !important;
            }

            h2 {
                font-size: 18px !important;
            }

            h3 {
                font-size: 16px !important;
            }

            .container {
                padding: 0 !important;
                width: 100% !important;
            }

            .content {
                padding: 0 !important;
            }

            .content-wrap {
                padding: 10px !important;
            }

            .invoice {
                width: 100% !important;
            }
        }
    </style>
</head>
<body itemscope itemtype="http://schema.org/EmailMessage"
      style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; -webkit-font-smoothing: antialiased; -webkit-text-size-adjust: none; width: 100% !important; height: 100%; line-height: 1.6em; background-color: #f6f6f6; margin: 0;"
      bgcolor="#f6f6f6">
<table class="body-wrap"
       style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; width: 100%; background-color: #f6f6f6; margin: 0;"
       bgcolor="#f6f6f6">
    <tr style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
        <td style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0;"
            valign="top"></td>
        <td class="container" width="600"
            style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; display: block !important; max-width: 600px !important; clear: both !important; margin: 0 auto;"
            valign="top">
            <div class="content"
                 style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; max-width: 600px; display: block; margin: 0 auto; padding: 20px;">
                <table class="main" width="100%" cellpadding="0" cellspacing="0"
                       style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; border-radius: 3px; background-color: #fff; margin: 0; border: 1px solid #e9e9e9;"
                       bgcolor="#fff">
                    <tr style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                        <td class="alert alert-warning"
                            style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 16px; vertical-align: top; color: #fff; font-weight: 500; text-align: center; border-radius: 3px 3px 0 0; background-color: #673ab7; margin: 0; padding: 20px;"
                            align="center" bgcolor="#FF9F00" valign="top">
                            <?php esc_html_e('Weekly Email Summary of Your Forms', 'fluentform'); ?>
                        </td>
                    </tr>
                    <tr style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                        <td class="content-wrap"
                            style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 20px;"
                            valign="top">
                            <table width="100%" cellpadding="0" cellspacing="0"
                                   style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                <tr style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                    <td class="content-block"
                                        style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;"
                                        valign="top">
                                        <b><?php esc_html_e('Hello There,', 'fluentform'); ?></b><br/>
                                        <?php printf(
                                          /* translators: %d is the Number Email Summary Days */
                                          esc_html__('Let\'s see how your forms performed in the last %d days.', 'fluentform'), intval($days));; ?>
                                    </td>
                                </tr>
                                <tr style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                    <td class="content-block"
                                        style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;"
                                        valign="top">
                                        <table class="summary_table">
                                            <thead>
                                            <tr>
                                                <th><?php esc_html_e('Form', 'fluentform'); ?></th>
                                                <th><?php esc_html_e('Entries', 'fluentform'); ?></th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php foreach ($submissions as $submission): ?>
                                                <tr>
                                                    <td><?php echo esc_html($submission->title); ?></td>
                                                    <td><?php echo esc_attr($submission->total); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>

                                <?php if ($payments): ?>
                                    <tr style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                        <td class="content-block"
                                            style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;"
                                            valign="top">
                                            <h3><?php esc_html_e('Payments', 'fluentform'); ?></h3>
                                            <table class="summary_table">
                                                <thead>
                                                <tr>
                                                    <th><?php esc_html_e('Form', 'fluentform'); ?></th>
                                                    <th><?php esc_html_e('Payment Total', 'fluentform'); ?></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php foreach ($payments as $payment): ?>
                                                    <tr>
                                                        <td><?php echo esc_html($payment->title); ?></td>
                                                        <td><?php echo esc_attr($payment->readable_amount); ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                <?php endif; ?>

                                <tr style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                    <td class="content-block"
                                        style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;"
                                        valign="top">
                                        <?php
                                        $generateText = sprintf(
                                            /* translators: 1: opening anchor tag, 2: site name, 3: closing anchor tag */
                                            __('This email has been generated from Fluent Forms at %1$s%2$s%3$s.', 'fluentform'),
                                            '<a href="' .  site_url() . '">',
                                            get_bloginfo('name'),
                                            '</a>'
                                        );
                                        $generateText = apply_filters_deprecated(
                                            'fluentform_email_summary_body_text',
                                            [
                                                $generateText,
                                                $submissions
                                            ],
                                            FLUENTFORM_FRAMEWORK_UPGRADE,
                                            'fluentform/email_summary_body_text',
                                            'Use fluentform/email_summary_body_text instead of fluentform_email_summary_body_text.'
                                        );
                                        $generateText = apply_filters('fluentform/email_summary_body_text', $generateText, $submissions);
                                        ?>
                                        <?php echo wp_kses_post($generateText); ?> .
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
                <div class="footer"
                     style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; width: 100%; clear: both; color: #999; margin: 0; padding: 20px;">
                    <table width="100%"
                           style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                        <tr style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                            <td class="aligncenter content-block"
                                style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 12px; vertical-align: top; color: #999; text-align: center; margin: 0; padding: 0 0 20px;"
                                align="center" valign="top">
                                <?php
                                $footerText = sprintf(
                                     /* translators: 1: opening anchor tag to site, 2: closing anchor tag, 3: opening anchor tag to settings, 4: closing anchor tag */
                                    __('This email has been sent from %1$syour website%2$s via Fluent Forms. You can disable this email %3$syour website%4$s', 'fluentform'),
                                    '<a href="' .  site_url() . '">',
                                    '</a>',
                                    '<a href="' .  admin_url('admin.php?page=fluent_forms_settings') . '">',
                                    '</a>'
                                );
                                $footerText = apply_filters_deprecated(
                                    'fluentform_email_summary_footer_text',
                                    [
                                        $footerText
                                    ],
                                    FLUENTFORM_FRAMEWORK_UPGRADE,
                                    'fluentform/email_summary_footer_text',
                                    'Use fluentform/email_summary_footer_text instead of fluentform_email_summary_footer_text.'
                                );
                                $footerText = apply_filters('fluentform/email_summary_footer_text', $footerText);
                                ?>
                                <p>
                                    <?php echo wp_kses_post($footerText); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </td>
        <td style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0;"
            valign="top"></td>
    </tr>
</table>
</body>
</html>
