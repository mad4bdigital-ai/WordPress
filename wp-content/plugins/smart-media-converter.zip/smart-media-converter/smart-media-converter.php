<?php
/**
 * Plugin Name: Smart Media Converter PRO
 * Description: محول الصور الذكي - يدعم المجلدات، الفحص الذكي، التفعيل الآلي، والتحويل التلقائي مستقبلاً.
 * Version: 2.0
 * Author: Antigravity
 */

if (!defined('ABSPATH')) exit;

// ==========================================
// 1. القوائم وواجهة المستخدم (UI)
// ==========================================
add_action('admin_menu', function() {
    add_management_page('Smart Media Converter', 'Smart Media Converter', 'manage_options', 'smart-media-converter', 'smc_admin_page');
});

function smc_admin_page() {
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    $htaccess_file = get_home_path() . '.htaccess';
    $is_injected = file_exists($htaccess_file) && strpos(file_get_contents($htaccess_file), '# BEGIN Smart Media Converter') !== false;

    // جلب جميع تصنيفات المجلدات (Folders by Premio)
    $taxonomies = get_object_taxonomies('attachment', 'objects');
    $terms = [];
    foreach($taxonomies as $tax) {
        $tax_terms = get_terms(['taxonomy' => $tax->name, 'hide_empty' => false]);
        if (!is_wp_error($tax_terms) && !empty($tax_terms)) {
            $terms[$tax->label] = $tax_terms;
        }
    }
    
    // جلب تصنيفات ووردبريس الافتراضية (حسب السنة والشهر)
    global $wpdb;
    $months = $wpdb->get_results("
        SELECT DISTINCT YEAR(post_date) AS year, MONTH(post_date) AS month, count(ID) as count
        FROM $wpdb->posts
        WHERE post_type = 'attachment' AND post_status = 'inherit' AND post_mime_type IN ('image/jpeg', 'image/png')
        GROUP BY year, month
        ORDER BY year DESC, month DESC
    ");
    ?>
    <style>
        .smc-box { background:#fff; padding:20px; border:1px solid #ccd0d4; box-shadow:0 1px 1px rgba(0,0,0,.04); max-width:800px; margin-bottom:20px; border-radius: 5px; }
        .smc-tabs { display: flex; border-bottom: 2px solid #ddd; margin-bottom: 20px; }
        .smc-tab { padding: 10px 20px; cursor: pointer; font-weight: bold; color: #555; }
        .smc-tab.active { border-bottom: 3px solid #2271b1; color: #2271b1; margin-bottom: -2px; }
        .smc-content { display: none; }
        .smc-content.active { display: block; }
        .smc-folders-list { max-height: 200px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; border-radius: 4px; margin-bottom: 15px; }
    </style>
    
    <div class="wrap">
        <h1>Smart Media Converter PRO 🚀</h1>
        <p>هذا الإصدار المطور يحتوي على كل شيء يعمل بشكل آلي بالكامل لخدمتك.</p>
        
        <!-- التفعيل الآلي -->
        <div class="smc-box" style="border-left: 4px solid #46b450;">
            <h3>🛠️ خطوة 1: تفعيل نظام العرض (.htaccess)</h3>
            <p>بنقرة واحدة، ستقوم الإضافة بكتابة الكود اللازم لعرض الصور المحولة للزوار بشكل خفي وسريع جداً.</p>
            <?php if($is_injected): ?>
                <button id="smc-inject-btn" class="button" disabled style="background:#46b450; color:#fff; border-color:#46b450;">تم التفعيل مسبقاً بنجاح ✅</button>
                <p style="color: #46b450; font-size: 12px; margin-top: 5px;">الكود السحري يعمل الآن في موقعك.</p>
            <?php else: ?>
                <button id="smc-inject-btn" class="button">تفعيل الكود السحري تلقائياً</button>
            <?php endif; ?>
            <span id="smc-inject-msg" style="margin-right: 10px; font-weight: bold;"></span>
        </div>

        <div class="smc-box">
            <h3>⚙️ خطوة 2: تحويل الصور الحالية</h3>
            
            <div class="smc-tabs">
                <div class="smc-tab active" data-target="tab-folders">خيار 1: حسب المجلدات (موصى به)</div>
                <div class="smc-tab" data-target="tab-smart">خيار 2: الفحص الذكي (تلقائي)</div>
            </div>
            
            <!-- تبويب المجلدات -->
            <div id="tab-folders" class="smc-content active">
                <p>حدد المجلدات أو التواريخ التي تريد تحويل صورها:</p>
                <div class="smc-folders-list">
                    <?php if(!empty($terms)): ?>
                        <h4 style="margin-top:0; color:#2271b1;">مجلدات الإضافات (مثال: Folders)</h4>
                        <?php foreach($terms as $label => $tax_terms): ?>
                            <strong><?php echo esc_html($label); ?>:</strong><br>
                            <?php foreach($tax_terms as $term): ?>
                                <label style="display:block; margin: 5px 0;">
                                    <input type="checkbox" class="smc-folder-cb" value="<?php echo esc_attr($term->term_id); ?>" data-tax="<?php echo esc_attr($term->taxonomy); ?>">
                                    <?php echo esc_html($term->name); ?> (<?php echo esc_html($term->count); ?> صورة)
                                </label>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                        <hr style="margin: 15px 0; border: 0; border-top: 1px solid #ddd;">
                    <?php endif; ?>
                    
                    <h4 style="margin-top:0; color:#2271b1;">أرشيف ووردبريس الافتراضي (حسب تاريخ الرفع)</h4>
                    <label style="display:block; margin: 5px 0;">
                        <input type="checkbox" class="smc-folder-cb" value="all" data-tax="wp_date">
                        <strong>⭐ كل الوسائط (تحويل جميع الصور)</strong>
                    </label>
                    <?php if(!empty($months)): foreach($months as $m): 
                        if (empty($m->year) || empty($m->month)) continue;
                        $date_obj = DateTime::createFromFormat('!Y-m', $m->year . '-' . $m->month);
                        $month_name = date_i18n('F Y', $date_obj->getTimestamp());
                    ?>
                        <label style="display:block; margin: 5px 0;">
                            <input type="checkbox" class="smc-folder-cb" value="<?php echo $m->year . '-' . str_pad($m->month, 2, '0', STR_PAD_LEFT); ?>" data-tax="wp_date">
                            <?php echo esc_html($month_name); ?> (<?php echo esc_html($m->count); ?> صورة)
                        </label>
                    <?php endforeach; endif; ?>
                </div>
                <button id="smc-start-folders" class="button button-primary button-large">ابدأ التحويل</button>
            </div>
            
            <!-- تبويب الفحص الذكي -->
            <div id="tab-smart" class="smc-content">
                <p>سيبحث هذا الخيار في قاعدة البيانات عن الصور المرفقة كـ (صورة بارزة) أو صور (داخل النصوص).<br>
                <em>تنبيه: قد لا يكتشف هذا الخيار الصور المخفية في إعدادات القوالب أو بعض إضافات Elementor.</em></p>
                <button id="smc-start-smart" class="button button-primary button-large">ابدأ الفحص والتحويل الذكي</button>
            </div>
            
            <!-- شريط التقدم المشترك -->
            <div id="smc-progress" style="display:none; margin-top:30px; background:#f0f0f1; padding: 20px; border-radius: 5px;">
                <h4 style="margin-top:0;">جاري التحويل...</h4>
                <progress id="smc-progressbar" value="0" max="100" style="width:100%; height:25px;"></progress>
                <p style="text-align:center; font-size: 16px; font-weight:bold;">
                    <span id="smc-percent">0</span>% 
                    (<span id="smc-count">0</span> / <span id="smc-total">0</span>)
                </p>
                <div style="background: #e5f5fa; padding: 10px; border-radius: 5px; text-align: center; margin-top: 15px; border: 1px solid #bce2ef;">
                    <strong style="color: #0073aa; font-size: 16px;">المساحة التي تم توفيرها للسيرفر:</strong> 
                    <span id="smc-saved-space" style="font-weight: bold; font-size: 18px; color: #d63638;">0 MB</span>
                </div>
                <p id="smc-status" style="color: #46b450; font-weight: bold; text-align:center; display: none;">✅ تمت العملية بنجاح!</p>
            </div>
        </div>
        
        <div class="smc-box" style="border-left: 4px solid #2271b1;">
            <h3>✨ التحويل التلقائي لصور المستقبل</h3>
            <p>أنت الآن في وضع الراحة! تم تفعيل نظام (التحويل التلقائي). أي صورة سترفعها لموقعك من الآن فصاعداً سيتم تحويلها لـ AVIF/WebP في الخلفية فوراً.</p>
        </div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        var nonce = '<?php echo wp_create_nonce("smc_nonce"); ?>';
        var total_saved_bytes = 0;
        
        // التبويبات
        $('.smc-tab').click(function(){
            $('.smc-tab').removeClass('active');
            $('.smc-content').removeClass('active');
            $(this).addClass('active');
            $('#' + $(this).data('target')).addClass('active');
        });
        
        // زر حقن htaccess
        $('#smc-inject-btn').click(function() {
            var btn = $(this);
            btn.prop('disabled', true).text('جاري التفعيل...');
            $.post(ajaxurl, { action: 'smc_inject_htaccess', nonce: nonce }, function(res) {
                if(res.success) {
                    $('#smc-inject-msg').css('color', '#46b450').text(res.data);
                    btn.text('تم التفعيل ✅');
                } else {
                    $('#smc-inject-msg').css('color', 'red').text(res.data);
                    btn.prop('disabled', false).text('حاول مجدداً');
                }
            });
        });
        
        // التحويل عبر المجلدات
        $('#smc-start-folders').click(function() {
            var selected_terms = [];
            var selected_taxes = [];
            var selected_dates = [];
            
            $('.smc-folder-cb:checked').each(function() {
                var tax = $(this).data('tax');
                if (tax === 'wp_date') {
                    selected_dates.push($(this).val());
                } else {
                    selected_terms.push($(this).val());
                    selected_taxes.push(tax);
                }
            });
            
            if(selected_terms.length === 0 && selected_dates.length === 0) { alert('يرجى تحديد خيار واحد على الأقل.'); return; }
            startProcess({ action: 'smc_get_folders_attachments', terms: selected_terms, taxes: selected_taxes, dates: selected_dates, nonce: nonce });
        });
        
        // التحويل الذكي
        $('#smc-start-smart').click(function() {
            startProcess({ action: 'smc_get_smart_attachments', nonce: nonce });
        });
        
        function startProcess(ajaxData) {
            $('.button-primary').prop('disabled', true);
            $('#smc-progress').show();
            $('#smc-status').hide();
            $('#smc-progressbar').val(0);
            $('#smc-percent').text('0');
            $('#smc-count').text('0');
            total_saved_bytes = 0;
            $('#smc-saved-space').text('0 MB');
            
            $.post(ajaxurl, ajaxData, function(res) {
                if(res.success) {
                    var ids = res.data;
                    $('#smc-total').text(ids.length);
                    if(ids.length > 0) processNext(ids, 0);
                    else {
                        alert('لم يتم العثور على أي صور!');
                        $('.button-primary').prop('disabled', false);
                    }
                } else {
                    alert('حدث خطأ أثناء الفحص.');
                    $('.button-primary').prop('disabled', false);
                }
            });
        }
        
        function processNext(ids, index) {
            if(index >= ids.length) {
                $('#smc-status').show();
                $('.button-primary').prop('disabled', false);
                return;
            }
            
            $.post(ajaxurl, { action: 'smc_convert_attachment', attachment_id: ids[index], nonce: nonce }, function(res) {
                if(res.success && res.data) {
                    var diff = (res.data.original_bytes || 0) - (res.data.new_bytes || 0);
                    if(diff > 0) total_saved_bytes += diff;
                    var saved_mb = (total_saved_bytes / 1024 / 1024).toFixed(2);
                    $('#smc-saved-space').text(saved_mb + ' MB');
                }
                updateProgress(ids, index);
            }).fail(function() {
                updateProgress(ids, index);
            });
        }
        
        function updateProgress(ids, index) {
            index++;
            var percent = Math.round((index / ids.length) * 100);
            $('#smc-count').text(index);
            $('#smc-percent').text(percent);
            $('#smc-progressbar').val(percent);
            processNext(ids, index);
        }
    });
    </script>
    <?php
}

// ==========================================
// 2. محركات البحث والتحديد (AJAX)
// ==========================================

// جلب صور المجلدات أو التواريخ
add_action('wp_ajax_smc_get_folders_attachments', function() {
    check_ajax_referer('smc_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error();

    $terms = isset($_POST['terms']) ? array_map('intval', $_POST['terms']) : [];
    $taxes = isset($_POST['taxes']) ? array_map('sanitize_text_field', $_POST['taxes']) : [];
    $dates = isset($_POST['dates']) ? array_map('sanitize_text_field', $_POST['dates']) : [];
    
    $all_ids = [];
    
    // 1. جلب عن طريق المجلدات (Folders Plugin)
    if (!empty($terms)) {
        $tax = !empty($taxes) ? $taxes[0] : 'folder';
        $query1 = new WP_Query([
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'post_mime_type' => ['image/jpeg', 'image/png'],
            'posts_per_page' => -1,
            'fields' => 'ids',
            'tax_query' => [[
                'taxonomy' => $tax,
                'field' => 'term_id',
                'terms' => $terms,
                'operator' => 'IN'
            ]]
        ]);
        $all_ids = array_merge($all_ids, $query1->posts);
    }
    
    // 2. جلب عن طريق تاريخ الرفع الافتراضي
    if (!empty($dates)) {
        $args2 = [
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'post_mime_type' => ['image/jpeg', 'image/png'],
            'posts_per_page' => -1,
            'fields' => 'ids'
        ];
        
        if (!in_array('all', $dates)) {
            $date_query = ['relation' => 'OR'];
            foreach ($dates as $date) {
                $parts = explode('-', $date);
                if (count($parts) == 2) {
                    $date_query[] = ['year' => $parts[0], 'month' => $parts[1]];
                }
            }
            $args2['date_query'] = $date_query;
        }
        $query2 = new WP_Query($args2);
        $all_ids = array_merge($all_ids, $query2->posts);
    }
    
    $unique_ids = array_unique($all_ids);
    wp_send_json_success(array_values($unique_ids));
});

// الفحص الذكي للصور المستخدمة
add_action('wp_ajax_smc_get_smart_attachments', function() {
    check_ajax_referer('smc_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error();
    
    global $wpdb;
    
    // 1. الصور البارزة
    $featured_ids = $wpdb->get_col("SELECT meta_value FROM $wpdb->postmeta WHERE meta_key = '_thumbnail_id' AND meta_value != ''");
    
    // 2. الصور داخل النصوص والمقالات
    $content_query = $wpdb->get_col("SELECT post_content FROM $wpdb->posts WHERE post_type IN ('post', 'page', 'product') AND post_status = 'publish'");
    
    foreach($content_query as $content) {
        // البحث عن روابط الصور في كود الـ HTML
        preg_match_all('/src="([^"]+)"/', $content, $matches);
        if(!empty($matches[1])) {
            foreach($matches[1] as $url) {
                // محاولة استخراج رقم الصورة من الرابط
                $id = attachment_url_to_postid($url);
                if($id) $featured_ids[] = $id;
            }
        }
        
        // البحث في كلاسات ووردبريس wp-image-ID
        preg_match_all('/wp-image-([0-9]+)/', $content, $matches_cls);
        if(!empty($matches_cls[1])) {
            foreach($matches_cls[1] as $id) $featured_ids[] = $id;
        }
    }
    
    // تنظيف وتوحيد المعرفات
    $unique_ids = array_unique(array_filter(array_map('intval', $featured_ids)));
    wp_send_json_success(array_values($unique_ids));
});

// ==========================================
// 3. محرك التحويل الأساسي
// ==========================================
function smc_core_convert_image($attachment_id) {
    $file_path = get_attached_file($attachment_id);
    if (!$file_path || !file_exists($file_path)) return false;
    
    $upload_dir = wp_upload_dir();
    $relative_path = str_replace($upload_dir['basedir'], '', $file_path);
    $target_base = WP_CONTENT_DIR . '/smc-uploads';
    
    $metadata = wp_get_attachment_metadata($attachment_id);
    $files_to_convert = [$file_path];
    if (isset($metadata['sizes']) && is_array($metadata['sizes'])) {
        $base_dir = dirname($file_path);
        foreach ($metadata['sizes'] as $size) {
            if (isset($size['file'])) $files_to_convert[] = $base_dir . '/' . $size['file'];
        }
    }
    
    $converted_count = 0;
    $total_original_size = 0;
    $total_new_size = 0;
    
    foreach ($files_to_convert as $src) {
        if (!file_exists($src)) continue;
        
        $rel = str_replace($upload_dir['basedir'], '', $src);
        $tgt = $target_base . $rel;
        
        // Check if destination file already exists to save time!
        $dest_avif = $tgt . '.avif';
        $dest_webp = $tgt . '.webp';
        
        if (function_exists('imageavif') && file_exists($dest_avif)) {
            $converted_count++;
            $total_original_size += filesize($src);
            $total_new_size += filesize($dest_avif);
            continue; // Skip, already converted
        } elseif (file_exists($dest_webp)) {
            $converted_count++;
            $total_original_size += filesize($src);
            $total_new_size += filesize($dest_webp);
            continue; // Skip, already converted
        }
        
        $target_dir = dirname($tgt);
        if (!file_exists($target_dir)) wp_mkdir_p($target_dir);
        
        $info = @getimagesize($src);
        if (!$info) continue;
        
        $img = null;
        if ($info['mime'] == 'image/jpeg') $img = @imagecreatefromjpeg($src);
        elseif ($info['mime'] == 'image/png') {
            $img = @imagecreatefrompng($src);
            if ($img) {
                imagepalettetotruecolor($img);
                imagealphablending($img, true);
                imagesavealpha($img, true);
            }
        }
        
        if ($img) {
            $success = false;
            // Try AVIF first
            if (function_exists('imageavif')) {
                $success = @imageavif($img, $dest_avif, 70); 
                if ($success && file_exists($dest_avif)) {
                    $total_original_size += filesize($src);
                    $total_new_size += filesize($dest_avif);
                }
            }
            
            // Fallback to WebP if AVIF fails or doesn't exist
            if (!$success && function_exists('imagewebp')) {
                $success = @imagewebp($img, $dest_webp, 80);
                if ($success && file_exists($dest_webp)) {
                    $total_original_size += filesize($src);
                    $total_new_size += filesize($dest_webp);
                }
            }
            
            if ($success) $converted_count++;
            @imagedestroy($img);
        }
    }
    return [
        'converted' => $converted_count,
        'original_bytes' => $total_original_size,
        'new_bytes' => $total_new_size
    ];
}

add_action('wp_ajax_smc_convert_attachment', function() {
    check_ajax_referer('smc_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error();
    
    $result = smc_core_convert_image(intval($_POST['attachment_id']));
    wp_send_json_success($result);
});

// ==========================================
// 4. الأنظمة التلقائية (htaccess + New Uploads)
// ==========================================

// التفعيل الآلي لملف htaccess
add_action('wp_ajax_smc_inject_htaccess', function() {
    check_ajax_referer('smc_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error();
    
    $rules = [
        "<IfModule mod_rewrite.c>",
        "RewriteEngine On",
        "RewriteCond %{HTTP_ACCEPT} image/avif",
        "RewriteCond %{DOCUMENT_ROOT}/wp-content/smc-uploads/$1.$2.avif -f",
        "RewriteRule ^wp-content/uploads/(.+)\.(jpe?g|png)$ /wp-content/smc-uploads/$1.$2.avif [T=image/avif,L]",
        "RewriteCond %{HTTP_ACCEPT} image/webp",
        "RewriteCond %{DOCUMENT_ROOT}/wp-content/smc-uploads/$1.$2.webp -f",
        "RewriteRule ^wp-content/uploads/(.+)\.(jpe?g|png)$ /wp-content/smc-uploads/$1.$2.webp [T=image/webp,L]",
        "</IfModule>"
    ];
    
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/misc.php');
    
    $htaccess_file = get_home_path() . '.htaccess';
    
    if (insert_with_markers($htaccess_file, 'Smart Media Converter', $rules)) {
        wp_send_json_success('تم حقن الكود بنجاح في ملف .htaccess!');
    } else {
        wp_send_json_error('تعذر الكتابة في ملف .htaccess بسبب تصاريح السيرفر. يرجى التحقق منها.');
    }
});

// التحويل التلقائي لأي صورة جديدة يتم رفعها
add_filter('wp_generate_attachment_metadata', function($metadata, $attachment_id) {
    // تشغيل التحويل في الخلفية للصورة الجديدة
    smc_core_convert_image($attachment_id);
    return $metadata;
}, 10, 2);
