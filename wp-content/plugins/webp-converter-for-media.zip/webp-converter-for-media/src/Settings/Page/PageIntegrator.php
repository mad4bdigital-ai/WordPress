<?php

namespace WebpConverter\Settings\Page;

use WebpConverter\HookableInterface;
use WebpConverter\PluginInfo;
use WebpConverter\Service\ViewLoader;

/**
 * Adds plugin settings page in admin panel.
 */
class PageIntegrator implements HookableInterface {

	const SETTINGS_MENU_PAGE = 'webpc_admin_page';
	const SETTINGS_PAGE_TYPE = 'action';
	const UPLOAD_MENU_PAGE   = 'webpc_optimization_page';

	private ViewLoader $view_loader;

	public function __construct( PluginInfo $plugin_info, ?ViewLoader $view_loader = null ) {
		$this->view_loader = $view_loader ?: new ViewLoader( $plugin_info );
	}

	/**
	 * Objects of supported plugin settings pages.
	 *
	 * @var PageInterface[]
	 */
	private array $pages = [];

	/**
	 * {@inheritdoc}
	 */
	public function init_hooks(): void {
		add_action( 'admin_menu', [ $this, 'add_settings_page_for_admin' ] );
		add_action( 'network_admin_menu', [ $this, 'add_settings_page_for_network' ] );
	}

	private function get_current_page(): ?PageInterface {
		$page_name = $_GET['page'] ?? null; // phpcs:ignore WordPress.Security
		$tab_name  = $_GET[ self::SETTINGS_PAGE_TYPE ] ?? null; // phpcs:ignore WordPress.Security

		foreach ( $this->pages as $page ) {
			if ( ( $page->get_menu_parent() === $page_name ) && ( $page->get_slug() === $tab_name ) ) {
				return $page;
			}
		}
		return null;
	}

	public function set_page_integration( PageInterface $page ): PageIntegrator {
		$this->pages[] = $page;

		return $this;
	}

	/**
	 * Returns URL of plugin settings page.
	 *
	 * @param string|null $action .
	 *
	 * @return string
	 */
	public static function get_settings_page_url( ?string $action = null ): string {
		if ( ! is_multisite() ) {
			$page_url = admin_url( 'options-general.php?page=' . self::SETTINGS_MENU_PAGE );
		} else {
			$page_url = network_admin_url( 'settings.php?page=' . self::SETTINGS_MENU_PAGE );
		}

		if ( $action !== null ) {
			$page_url .= '&' . self::SETTINGS_PAGE_TYPE . '=' . $action;
		}
		return $page_url;
	}

	/**
	 * Adds settings page to menu for non-multisite websites.
	 *
	 * @internal
	 */
	public function add_settings_page_for_admin(): void {
		if ( is_multisite() ) {
			return;
		}
		$this->add_settings_page( 'options-general.php', self::SETTINGS_MENU_PAGE );
		$this->add_settings_page( 'upload.php', self::UPLOAD_MENU_PAGE );
	}

	/**
	 * Adds settings page to menu for multisite websites.
	 *
	 * @internal
	 */
	public function add_settings_page_for_network(): void {
		$this->add_settings_page( 'settings.php', self::SETTINGS_MENU_PAGE );
	}

	/**
	 * Creates plugin settings page in WordPress Admin Dashboard.
	 *
	 * @param string $parent_page Parent menu page.
	 * @param string $menu_page   .
	 */
	private function add_settings_page( string $parent_page, string $menu_page ): void {
		add_submenu_page(
			$parent_page,
			'Converter for Media',
			'Converter for Media',
			'manage_options',
			$menu_page,
			[ $this, 'load_plugin_page' ]
		);
	}

	/**
	 * @internal
	 */
	public function load_plugin_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Sorry, you do not have permission to do that.', 'webp-converter-for-media' ) );
		}

		$page = $this->get_current_page();
		if ( $page === null ) {
			return;
		}

		$page->do_action_before_load();
		do_action( 'webpc_settings_page_loaded', $page->get_menu_parent(), $page->get_slug() );

		$this->view_loader->load_view(
			$page->get_template_path(),
			array_merge(
				$page->get_template_vars(),
				[
					'menu_items' => array_map(
						function ( PageInterface $settings_page ) use ( $page ) {
							return [
								'url'       => $settings_page->get_menu_url(),
								'title'     => $settings_page->get_label(),
								'is_active' => ( $settings_page === $page ),
							];
						},
						array_filter(
							$this->pages,
							function ( $page ) {
								return ( $page->is_available() );
							}
						)
					),
				]
			)
		);

		$page->do_action_after_load();
	}
}
