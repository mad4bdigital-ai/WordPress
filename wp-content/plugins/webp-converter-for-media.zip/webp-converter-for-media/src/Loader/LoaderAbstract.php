<?php

namespace WebpConverter\Loader;

use WebpConverter\Conversion\Format\FormatFactory;
use WebpConverter\PluginData;
use WebpConverter\PluginInfo;
use WebpConverter\Settings\Option\LoaderTypeOption;

/**
 * Abstract class for class that supports method of loading images.
 */
abstract class LoaderAbstract implements LoaderInterface {

	const ACTION_NAME = 'webpc_refresh_loader';

	protected PluginInfo $plugin_info;

	protected PluginData $plugin_data;

	protected FormatFactory $format_factory;

	public function __construct( PluginInfo $plugin_info, PluginData $plugin_data, FormatFactory $format_factory ) {
		$this->plugin_info    = $plugin_info;
		$this->plugin_data    = $plugin_data;
		$this->format_factory = $format_factory;
	}

	/**
	 * {@inheritdoc}
	 */
	public function is_active_loader(): bool {
		$settings = $this->plugin_data->get_plugin_settings();
		return ( $settings[ LoaderTypeOption::OPTION_NAME ] === $this->get_type() );
	}

	/**
	 * {@inheritdoc}
	 */
	public function init_admin_hooks(): void {
	}

	/**
	 * {@inheritdoc}
	 */
	public function init_front_end_hooks(): void {
	}
}
