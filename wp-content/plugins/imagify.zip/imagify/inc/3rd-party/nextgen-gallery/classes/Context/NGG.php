<?php
namespace Imagify\ThirdParty\NGG\Context;

use Imagify\Context\AbstractContext;
use Imagify\Traits\InstanceGetterTrait;

/**
 * Context class used for the WP media library.
 *
 * @since  1.9
 * @author Grégory Viguier
 */
class NGG extends AbstractContext {
	use InstanceGetterTrait;

	/**
	 * Context "short name".
	 *
	 * @var    string
	 * @since  1.9
	 * @author Grégory Viguier
	 */
	protected $context = 'ngg';

	/**
	 * Type of files this context allows.
	 *
	 * @var    string Possible values are:
	 *     - 'all' to allow all types.
	 *     - 'image' to allow only images.
	 *     - 'not-image' to allow only pdf files.
	 * @since  1.9
	 * @see    imagify_get_mime_types()
	 * @author Grégory Viguier
	 */
	protected $allowed_mime_types = 'image';

	/**
	 * The thumbnail sizes for this context, except the full size.
	 *
	 * @var    array {
	 *     Data for the currently registered thumbnail sizes.
	 *     Size names are used as array keys.
	 *
	 *     @type int    $width  The image width.
	 *     @type int    $height The image height.
	 *     @type bool   $crop   True to crop, false to resize.
	 *     @type string $name   The size name.
	 * }
	 * @since  1.9
	 * @author Grégory Viguier
	 */
	protected $thumbnail_sizes = [];

	/**
	 * Tell if the optimization process is allowed to backup in this context.
	 *
	 * @var    bool
	 * @since  1.9
	 * @author Grégory Viguier
	 */
	protected $can_backup = true;

	/**
	 * Get images max width for this context. This is used when resizing.
	 * 0 means to not resize.
	 *
	 * @since  1.9.8
	 * @author Grégory Viguier
	 *
	 * @return int
	 */
	public function get_resizing_threshold() {
		return 0;
	}

	/**
	 * Get user capacity to operate Imagify in this context.
	 *
	 * @since  1.9
	 * @author Grégory Viguier
	 *
	 * @param  string $describer Capacity describer. Possible values are like 'manage', 'bulk-optimize', 'manual-optimize', 'auto-optimize'.
	 * @return string
	 */
	public function get_capacity( $describer = 'manage' ) {
		switch ( $describer ) {
			case 'manage':
				$capacity = 'NextGEN Change options';
				break;

			case 'bulk-optimize':
				$capacity = 'NextGEN Manage others gallery';
				break;

			case 'optimize':
			case 'restore':
			case 'manual-optimize':
			case 'manual-restore':
				$capacity = 'NextGEN Manage gallery';
				break;

			case 'auto-optimize':
				$capacity = 'NextGEN Upload images';
				break;

			default:
				$capacity = $describer;
		}

		// NGG v4 may not register the v3 custom capabilities. Fall back to 'manage_options' so
		// the submenu and bulk page remain accessible to site administrators on v4.
		// @codeCoverageIgnoreStart — requires live NGG v4 class; not available in unit tests.
		if ( class_exists( 'Imagely\NGG\Admin\App' ) && ! get_role( $capacity ) && ! wp_roles()->is_role( $capacity ) ) {
			$wp_roles = wp_roles();
			$has_cap  = false;

			foreach ( $wp_roles->roles as $role_data ) {
				if ( ! empty( $role_data['capabilities'][ $capacity ] ) ) {
					$has_cap = true;
					break;
				}
			}

			if ( ! $has_cap ) {
				$capacity = 'manage_options';
			}
		}
		// @codeCoverageIgnoreEnd

		return $this->filter_capacity( $capacity, $describer );
	}
}
