const { registerBlockType } = wp.blocks;
const { __ } = wp.i18n;

const {
    SVG,
    Path
} = wp.primitives;

const {
    InspectorControls
} = wp.editor;

const {
	useBlockProps,
} = wp.blockEditor;

const {
    PanelBody,
    SelectControl,
    TextControl,
    ToggleControl,
    Disabled,
} = wp.components;

const {
    serverSideRender: ServerSideRender
} = wp;

function clone(o) {
	let output, v, key;

	output = Array.isArray(o) ? [] : {};

	for (key in o) {
		v = o[key];
		output[key] = (typeof v === "object") ? clone(v) : v;
	}

	return output;
}

const Repeater = window.JetEngineBlocksComponents.RepeaterControl;

const Icon = <svg width="24" height="24" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M48 52C48 51.4477 48.4477 51 49 51H55C55.5523 51 56 51.4477 56 52C56 52.5523 55.5523 53 55 53H49C48.4477 53 48 52.5523 48 52Z" fill="#0F172A"/> <path fill-rule="evenodd" clip-rule="evenodd" d="M45 47C45.5523 47 46 47.4477 46 48V52C46 52.5523 45.5523 53 45 53H41C40.4477 53 40 52.5523 40 52V48C40 47.4477 40.4477 47 41 47H45ZM42 51H44V49H42V51Z" fill="#0F172A"/> <path d="M57 47C57.5523 47 58 47.4477 58 48C58 48.5523 57.5523 49 57 49H49C48.4477 49 48 48.5523 48 48C48 47.4477 48.4477 47 49 47H57Z" fill="#0F172A"/> <path fill-rule="evenodd" clip-rule="evenodd" d="M45 37C45.5523 37 46 37.4477 46 38V42C46 42.5523 45.5523 43 45 43H41C40.4477 43 40 42.5523 40 42V38C40 37.4477 40.4477 37 41 37H45ZM42 41H44V39H42V41Z" fill="#0F172A"/> <path d="M55 41C55.5523 41 56 41.4477 56 42C56 42.5523 55.5523 43 55 43H49C48.4477 43 48 42.5523 48 42C48 41.4477 48.4477 41 49 41H55Z" fill="#0F172A"/> <path d="M57 37C57.5523 37 58 37.4477 58 38C58 38.5523 57.5523 39 57 39H49C48.4477 39 48 38.5523 48 38C48 37.4477 48.4477 37 49 37H57Z" fill="#0F172A"/> <path fill-rule="evenodd" clip-rule="evenodd" d="M45 27C45.5523 27 46 27.4477 46 28V32C46 32.5523 45.5523 33 45 33H41C40.4477 33 40 32.5523 40 32V28C40 27.4477 40.4477 27 41 27H45ZM42 31H44V29H42V31Z" fill="#0F172A"/> <path d="M53 31C53.5523 31 54 31.4477 54 32C54 32.5523 53.5523 33 53 33H49C48.4477 33 48 32.5523 48 32C48 31.4477 48.4477 31 49 31H53Z" fill="#0F172A"/> <path d="M57 27C57.5523 27 58 27.4477 58 28C58 28.5523 57.5523 29 57 29H49C48.4477 29 48 28.5523 48 28C48 27.4477 48.4477 27 49 27H57Z" fill="#0F172A"/> <path d="M13 31C13.5523 31 14 31.4477 14 32C14 32.5523 13.5523 33 13 33H7C6.44772 33 6 32.5523 6 32C6 31.4477 6.44772 31 7 31H13Z" fill="#0F172A"/> <path d="M31 31C31.5523 31 32 31.4477 32 32C32 32.5523 31.5523 33 31 33H23C22.4477 33 22 32.5523 22 32C22 31.4477 22.4477 31 23 31H31Z" fill="#0F172A"/> <path d="M17 27C17.5523 27 18 27.4477 18 28C18 28.5523 17.5523 29 17 29H7C6.44772 29 6 28.5523 6 28C6 27.4477 6.44772 27 7 27H17Z" fill="#0F172A"/> <path d="M33 27C33.5523 27 34 27.4477 34 28C34 28.5523 33.5523 29 33 29H23C22.4477 29 22 28.5523 22 28C22 27.4477 22.4477 27 23 27H33Z" fill="#0F172A"/> <path fill-rule="evenodd" clip-rule="evenodd" d="M17 10C17.5523 10 18 10.4477 18 11V24C18 24.5523 17.5523 25 17 25H7L6.89746 24.9951C6.39333 24.9438 6 24.5177 6 24V11C6 10.4477 6.44772 10 7 10H17ZM8 23H16V12H8V23Z" fill="#0F172A"/> <path fill-rule="evenodd" clip-rule="evenodd" d="M33 10C33.5523 10 34 10.4477 34 11V24C34 24.5523 33.5523 25 33 25H23L22.8975 24.9951C22.3933 24.9438 22 24.5177 22 24V11C22 10.4477 22.4477 10 23 10H33ZM24 23H32V12H24V23Z" fill="#0F172A"/> <path fill-rule="evenodd" clip-rule="evenodd" d="M50 4C52.2091 4 54 5.79086 54 8V20H58C60.2091 20 62 21.7909 62 24V56C62 58.2091 60.2091 60 58 60H40C37.7909 60 36 58.2091 36 56V39H6C3.79086 39 2 37.2091 2 35V8C2 5.79086 3.79086 4 6 4H50ZM40 22C38.8954 22 38 22.8954 38 24V56C38 57.1046 38.8954 58 40 58H58C59.1046 58 60 57.1046 60 56V24C60 22.8954 59.1046 22 58 22H40ZM6 6C4.89543 6 4 6.89543 4 8V35C4 36.1046 4.89543 37 6 37H36V24C36 22.5196 36.8046 21.2278 38 20.5361V11C38 10.4477 38.4477 10 39 10H49C49.5523 10 50 10.4477 50 11V20H52V8C52 6.89543 51.1046 6 50 6H6ZM40 20H48V12H40V20Z" fill="#0F172A"/> <path d="M20 41C20.5523 41 21 41.4477 21 42C21 44.634 21.4794 46.3235 22.1182 47.4414C22.748 48.5436 23.5789 49.1713 24.4473 49.6055C25.1955 49.9796 26.3176 50.2529 27.4883 50.4062C28.0625 50.4815 28.6196 50.5247 29.1143 50.54L26.7461 48.1719C26.3558 47.7815 26.356 47.1484 26.7461 46.7578C27.1366 46.3673 27.7706 46.3673 28.1611 46.7578L31.6963 50.293C32.0859 50.6826 31.9897 51.4963 31.9893 51.5C31.9805 51.7437 31.8823 51.9858 31.6963 52.1719L28.1611 55.707C27.7706 56.0976 27.1366 56.0976 26.7461 55.707C26.3559 55.3166 26.3559 54.6834 26.7461 54.293L28.5254 52.5146C28.1047 52.4888 27.6666 52.447 27.2285 52.3896C25.9714 52.225 24.5933 51.9148 23.5527 51.3945C22.4211 50.8287 21.252 49.9564 20.3818 48.4336C19.5206 46.9265 19 44.866 19 42C19 41.4477 19.4477 41 20 41Z" fill="#0F172A"/></svg>

function getOptionsFromObject( object ) {

    const result = [];

    for ( const [ value, label ] of Object.entries( object ) ) {
        result.push( {
            value: value,
            label: label,
        } );
    }

    return result;

}

registerBlockType( 'jet-smart-filters/items-number-switcher', {
    apiVersion: "3",
    title: __( 'Items Number Switcher' ),
    icon: Icon,
    category: 'jet-smart-filters',
    supports: {
        html: false
    },
    attributes: {
        block_editor_breakpoints: {
            type: 'array',
            default: [
                {
                    breakpoint: 767,
                    number: 3,
                },
                {
                    breakpoint: 1024,
                    number: 3,
                },
                {
                    breakpoint: 1920,
                    number: 3,
                },
            ],
        },
        content_provider: {
            type: 'string',
            default: 'not-selected',
        },
        query_id: {
            type: 'string',
            default: '',
        },
        additional_providers_enabled: {
            type: 'boolean',
            default: false,
        },
        additional_providers_list: {
            type: 'array',
            default: [{
                additional_provider: '',
                additional_query_id: ''
            }],
        },
    },
    className: 'jet-smart-filters-items-number-switcher',
    edit: ( props ) => {

        const blockProps = useBlockProps();

        const updateAdditionalProvidersRepeaterItem = ( index, key, value ) => {
            const providersList = clone( props.attributes.additional_providers_list );
            providersList[index][key] = value;

            props.setAttributes( { additional_providers_list: providersList } );
        };

        const updateBreakpointsRepeaterItem = ( index, key, value ) => {
            const breakpointList = clone( props.attributes.block_editor_breakpoints );
            breakpointList[index][key] = value;

            props.setAttributes( { block_editor_breakpoints: breakpointList } );
        };

        const allowedProviders = [ 'jet-engine', 'jet-data-table' ];

        const providerOptions = getOptionsFromObject( window.JetSmartFilterBlocksData.providers ).filter( op => op.value === 'not-selected' || allowedProviders.includes( op.value ) );

        return [
            props.isSelected && (
                <InspectorControls
                    key={'inspector'}
                >
                    <PanelBody title={__( 'General' )}>
                        <div>
                            <h4 style={{margin:'5px 0 0'}}>Please note!</h4>
                            <p style={{ color: '#757575', fontSize: '12px' }}>
                                This filter is compatible only with queries from the JetEngine Query Builder.
                            </p>
                        </div>
                        <Repeater
                            data={ props.attributes.block_editor_breakpoints }
                            onChange={ newData => {
                                props.setAttributes({ block_editor_breakpoints: newData });
                            } }
                            default={{
                                breakpoint: 1920,
                                number: 3,
                            }}
                        >
                            {
                                (item, index) =>
                                    <React.Fragment>
                                        <TextControl
                                            label={ __('Breakpoint') }
                                            value={ item.breakpoint }
                                            onChange={ newValue => {
                                                updateBreakpointsRepeaterItem(index, 'breakpoint', newValue);
                                            }}
                                        />
                                        <TextControl
                                            type="text"
                                            label={ __('Items Number') }
                                            value={ item.number }
                                            onChange={ newValue => {
                                                updateBreakpointsRepeaterItem(index, 'number', newValue);
                                            }}
                                        />
                                    </React.Fragment>
                            }
                        </Repeater>
                        <SelectControl
                            label={ __( 'This filter for' ) }
                            value={ props.attributes.content_provider }
                            options={ providerOptions }
                            onChange={ newValue => {
                                props.setAttributes({ content_provider: newValue });
                            } }
                        />
                        <TextControl
                            type="text"
                            label={ __( 'Query ID' ) }
                            help={ __( 'Set a unique query ID if you use multiple blocks of the same provider on the page. Use the same ID for the filtered block, and for the JetEngine Query it is connected to.' ) }
                            value={ props.attributes.query_id }
                            onChange={ newValue => {
                                props.setAttributes( { query_id: newValue } );
                            } }
                        />
                        <ToggleControl
                            label={ __( 'Additional Providers Enabled' ) }
                            checked={ props.attributes.additional_providers_enabled }
                            onChange={ newValue => {
                                props.setAttributes( { additional_providers_enabled: newValue } );
                            }}
                        />
                        {props.attributes.additional_providers_enabled === true && (
                            <Repeater
                                data={ props.attributes.additional_providers_list }
                                default={{
                                    additional_provider: ''
                                }}
                                onChange={ newData => {
                                    props.setAttributes({ additional_providers_list: newData });
                                } }
                            >
                                {
                                    (item, index) =>
                                        <React.Fragment>
                                            <SelectControl
                                                label={ __('Additional Provider') }
                                                value={ item.additional_provider }
                                                options={ providerOptions }
                                                onChange={ newValue => {
                                                    updateAdditionalProvidersRepeaterItem(index, 'additional_provider', newValue);
                                                }}
                                            />
                                            <TextControl
                                                type="text"
                                                label={ __('Additional Query ID') }
                                                value={ item.additional_query_id }
                                                onChange={ newValue => {
                                                    updateAdditionalProvidersRepeaterItem(index, 'additional_query_id', newValue);
                                                }}
                                            />
                                        </React.Fragment>
                                }
                            </Repeater>
                        )}
                    </PanelBody>
                </InspectorControls>
            ),
            <div class="jet-smart-filters-block-holder" { ...blockProps }>
                <Disabled key={ 'block_render' }>
                    <ServerSideRender
                        block="jet-smart-filters/items-number-switcher"
                        attributes={ props.attributes }
                    />
                </Disabled>
            </div>
        ];

    },
    save: props => {
        return null;
    },
} );
