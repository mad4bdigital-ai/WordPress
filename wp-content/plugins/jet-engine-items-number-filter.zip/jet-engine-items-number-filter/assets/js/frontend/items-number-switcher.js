( function( $ ) {

	"use strict";

	const eventBaseName = 'jet-engine/items-number-switcher/breakpoint-switched/';

	//apply items number filters after Listing Grid lazy load
	$( document ).on( 'jet-engine/listing-grid/after-lazy-load', function( e, args ) {
		
		const loadedProvider = args.container.find( 'div.jet-listing-grid.jet-listing' );

		for ( const groupName in JetSmartFilters.filterGroups ) {
			const filterGroup = JetSmartFilters.filterGroups[ groupName ];
			const groupProvider = filterGroup.getProvider();
			
			if ( loadedProvider[0] === groupProvider[0] ) {
				filterGroup.filters.forEach( ( filter ) => {
					if ( filter.name !== 'items-number-switcher' ) {
						return;
					}

					const builder = filter.getBuilder();

					dispatchEvent( getBreakpointByBuilder( builder ), builder )
				} );
			}
		}
	} );

	function dispatchEvent( breakpoint = '', builder = 'elementor' ) {
		const e = new CustomEvent(
			eventBaseName + builder,
			{
				detail: {
					breakpoint: breakpoint,
					builder: builder,
				},
			}
		);

		document.dispatchEvent( e );
	}

	function getItemsPerPage( provider, queryId ) {
		return JetSmartFilterSettings?.props?.[ provider ]?.[ queryId ]?.per_page || 0;
	}

	function getBreakpointByBuilder( builder ) {

		if ( ! window.JetEngine ) {
			return '';
		}

		const wWidth = window.innerWidth;

		switch ( builder ) {
			case 'elementor':
				return elementorFrontend.getCurrentDeviceMode();
			case 'bricks':
				let breakpoint = JetEngineSettings.bricksBreakpoints[0]['name'];
				let smallest   = breakpoint;

				JetEngineSettings.bricksBreakpoints.forEach( ( b ) => {
					if ( +b['width'] <= +wWidth ) {
						breakpoint = b['name'];
					}
				} );

				if ( wWidth < smallest['width'] ) {
					breakpoint = smallest['name'];
				}

				return breakpoint;
			case 'blocks':
				return wWidth;
		}
	}

	const initBreakpointObserver = function() {
		const breakpointObserver = class BreakpointObserver {

			timeouts = {};
			breakpoints = {};

			constructor() {
				this.init();
			}

			init() {
				if ( ! window.JetEngineSettings ) {
					return;
				}
				
				if ( window.elementorFrontend ) {
					this.initElementor();
				}

				if ( window.bricksData ) {
					this.initBricks();
				}

				this.initBlocks();
			}

			initElementor() {
				this.breakpoints['elementor'] = elementorFrontend.getCurrentDeviceMode();

				const observer = new MutationObserver( () => {

					clearTimeout( this.timeouts['elementor'] );

					this.timeouts['elementor'] = setTimeout(
						() => {
							const newMode = elementorFrontend.getCurrentDeviceMode();
							
							if ( newMode === this.breakpoints['elementor'] ) {
								return;
							}

							this.breakpoints['elementor'] = newMode;
							
							dispatchEvent( newMode, 'elementor' )
						}, 500
					);
				} );

				observer.observe(
					document.body,
					{
						attributes: true,
						attributeFilter: ['data-elementor-device-mode']
					}
				);
			}

			initBricks() {
				this.breakpoints['bricks'] = getBreakpointByBuilder( 'bricks' );

				window.addEventListener(
					'resize',
					() => {

						clearTimeout( this.timeouts['bricks'] );
	
						this.timeouts['bricks'] = setTimeout(
							() => {
								const newMode = getBreakpointByBuilder( 'bricks' );
								
								if ( newMode === this.breakpoints['bricks'] ) {
									return;
								}
	
								this.breakpoints['bricks'] = newMode;
								
								dispatchEvent( newMode, 'bricks' )
							}, 500
						);
					}
				);
			}

			initBlocks() {
				window.addEventListener(
					'resize',
					() => {

						clearTimeout( this.timeouts['blocks'] );
	
						this.timeouts['blocks'] = setTimeout(
							() => {
								this.breakpoints['blocks'] = getBreakpointByBuilder( 'blocks' );
								dispatchEvent( this.breakpoints['blocks'], 'blocks' )
							}, 500
						);
					}
				);
			}

		};

		new breakpointObserver();

	}

	const initItemsNumberSwitcher = function() {

		window.JetSmartFilters.filtersList.JetEngineItemsNumberSwitcher = 'jet-smart-filters-items-number-switcher';
		window.JetSmartFilters.filters.JetEngineItemsNumberSwitcher = class JetEngineItemsNumberSwitcher extends window.JetSmartFilters.filters.BasicFilter {

			name = 'items-number-switcher';

			dataValue = '';

			builder;

			constructor( $container ) {
				
				const $filter = $container.find( '.jet-smart-filters-items-number-switcher' );
				
				super( $container, $filter );

				this.$container = $container;

				//JetSmartFilters.events.subscribe( 'ajaxFilters/updated', this.reapplyPagination.bind( this ) );				

				window.addEventListener(
					'load',
					() => {
						const builder = this.getBuilder();
						document.addEventListener( eventBaseName + builder, this.switchNumberOnEvent.bind( this ) );

						if ( this.providerReady() ) {
							dispatchEvent( getBreakpointByBuilder( builder ), builder );
						}
					}
				);
			}

			providerReady() {
				if ( this.filterGroup.$provider.hasClass( 'jet-listing-grid--lazy-load' ) ) {
					return false;
				}

				return true;
			}

			getItemsNumber( breakpoint, builder = 'elementor' ) {
				let itemsNumber = false;

				switch ( builder ) {
					case 'elementor':
					case 'bricks':
						itemsNumber = this.$filter.data( 'posts_num_responsive_' + breakpoint );

						if ( ! itemsNumber ) {
							itemsNumber = this.$filter.data( 'posts_num_responsive' );
						}

						break;
					case 'blocks':
						const filterBreakpoints = {};

						for ( const attr of this.$filter[0].attributes ) {
						  if ( /^data-posts_num_responsive_.+/.test( attr.name ) ) {
							const breakpointWidth = attr.name.replace( 'data-posts_num_responsive_', '' );
							filterBreakpoints[ breakpointWidth ] = attr.value;
						  }
						}

						let widthList = Object.keys( filterBreakpoints );
						widthList.sort( (a, b) => Math.sign( b - a ) );

						const wWidth = window.innerWidth;

						for ( const c of widthList ) {
							if ( wWidth >= c ) {
								itemsNumber = filterBreakpoints[ c ];
								break;
							}
						}

						if ( ! itemsNumber ) {
							itemsNumber = filterBreakpoints[ Math.min( ...widthList ) ];
						}

						break;
				}

				return itemsNumber;
			}

			getBuilder() {
				if ( this.builder !== undefined ) {
					return this.builder;
				}

				const $filter = this?.$filter;

				if ( ! $filter?.length ) {
					this.builder = false;
					return false;
				}
				
				if ( $filter.parent().filter( '.elementor-widget-container, .elementor-widget' ).length ) {
					this.builder = 'elementor';
				} else if ( $filter.parent().filter( '[class*="brxe-"]' ).length ) {
					this.builder = 'bricks';
				} else if ( $filter.data( 'isBlock' ) ) {
					this.builder = 'blocks';
				}

				return this.builder;
			}

			switchNumberOnEvent( e ) {
				const breakpoint = e?.detail?.breakpoint;
				const builder = e?.detail?.builder || 'elementor';
				
				if ( this.getBuilder() !== builder ) {
					return;
				}

				this.switchNumber( this.getItemsNumber( breakpoint, builder ) );
			}

			switchNumber( itemsNumber ) {

				if ( ! itemsNumber ) {
					return;
				}

				if ( this.dataValue && +this.dataValue === +itemsNumber ) {
					return;
				}

				// let originalReset = this.filterGroup.resetFiltersByName;

				// this.filterGroup.resetFiltersByName = function( filterType ) {
				// 	if ( filterType === 'pagination' ) {
				// 		return;
				// 	}

				// 	originalReset( filterType );
				// }

				// if ( this.dataValue ) {
				// 	this.prevPerPage = this.dataValue;
				// 	this.prevPage = this.getCurrentPage();
				// }

				this.dataValue = +itemsNumber;

				//this.reapplyPagination();

				this.wasChanged ? this.wasChanged() : this.wasСhanged();

				//this.filterGroup.resetFiltersByName = originalReset;
			}

			reapplyPagination() {
				if ( ! this.prevPerPage || ! this.prevPage ) {
					return;
				}

				const prevPage = this.prevPage;
				const prevPerPage = this.prevPerPage;
				const newPerPage =  this.dataValue;

				let newPage = false;

				if ( prevPage < 2 ) {
					return;
				}

				newPage = Math.floor( ( prevPage - 1 ) * prevPerPage / newPerPage ) + 1;
				
				if ( prevPage === newPage ) {
					return;
				}

				for ( const filter of this.filterGroup.filters ) {
					if ( filter.name === 'pagination' ) {
						filter.$filter.find( `.jet-filters-pagination__item[data-value="${newPage}"]` ).click();
						break;
					}
				}
			}

			getNewPage( newPerPage ) {
				const currentPage = this.getCurrentPage();

				if ( currentPage < 2 ) {
					return false;
				}

				return Math.floor( ( currentPage - 1 ) * this.prevPerPage / newPerPage ) + 1;
			}

			getCurrentPage() {
				for ( const filter of this.filterGroup.filters ) {
					if ( filter.name === 'pagination' ) {
						if ( ! filter.$filter.find( '.jet-filters-pagination__item' ).length ) {
							continue;
						}
						
						return filter.dataValue;
					}
				}

				return 0;
			}

			reset() {}

			processData() {
				return;
			}

		};

	}

	document.addEventListener( 'DOMContentLoaded', ( e ) => {
		initBreakpointObserver();
		initItemsNumberSwitcher();
	});

}( jQuery ) );
