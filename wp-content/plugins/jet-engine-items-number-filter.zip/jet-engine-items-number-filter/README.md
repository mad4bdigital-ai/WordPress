# JetEngine - items number filter

## 1.1.0
* UPD: Blocks editor switched blocks to apiVersion 3
* FIX: load editor scripts on JetEngine Block views hook

## 1.0.1
* FIX: Blocks editor script dependencies
