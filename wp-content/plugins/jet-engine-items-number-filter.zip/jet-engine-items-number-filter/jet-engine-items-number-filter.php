<?php
/**
 * Plugin Name: JetEngine - Items number filter
 * Plugin URI:
 * Description:  Allows users to add a filter that sets the number of items per page depending on the screen width. Requires the JetSmartFilters plugin.
 * Version:     1.1.0
 * Author:      Crocoblock
 * Author URI:
 * Text Domain: jet-engine-dynamic-tables-module
 * License:     GPL-3.0+
 * License URI: http://www.gnu.org/licenses/gpl-3.0.txt
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die();
}

define( 'JET_ENGINE_ITEMS_NUMBER_FILTER_VERSION', '1.1.0' );

define( 'JET_ENGINE_ITEMS_NUMBER_FILTER__FILE__', __FILE__ );
define( 'JET_ENGINE_ITEMS_NUMBER_FILTER_PLUGIN_BASE', plugin_basename( JET_ENGINE_ITEMS_NUMBER_FILTER__FILE__ ) );
define( 'JET_ENGINE_ITEMS_NUMBER_FILTER_PATH', plugin_dir_path( JET_ENGINE_ITEMS_NUMBER_FILTER__FILE__ ) );
define( 'JET_ENGINE_ITEMS_NUMBER_FILTER_URL', plugins_url( '/', JET_ENGINE_ITEMS_NUMBER_FILTER__FILE__ ) );

add_action( 'plugins_loaded', 'jet_engine_items_number_filter_init' );

function jet_engine_items_number_filter_init() {
	if ( ! function_exists( 'jet_smart_filters' ) ) {
		add_action( 'admin_notices', 'jet_engine_items_number_filter_print_notice' );
		return;
	}

	require JET_ENGINE_ITEMS_NUMBER_FILTER_PATH . 'includes/plugin.php';
}

function jet_engine_items_number_filter_print_notice() {
	?>
		<div class="notice notice-error">
			<p>
				Please, install and activate <b>JetSmartFilters</b> plugin to use <b>JetEngine - Items Number Filter.</b>
			</p>
		</div>
	<?php
}

function jet_engine_items_number_filter() {
	return Jet_Engine_Items_Number_Filter\Plugin::instance();
}
