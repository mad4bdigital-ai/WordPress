<div class="jet-filter jet-smart-filters-items-number-switcher" <?php $this->filter_data_atts( $args ); ?>></div>
