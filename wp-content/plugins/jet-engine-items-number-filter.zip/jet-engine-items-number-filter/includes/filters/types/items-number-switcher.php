<?php
namespace Jet_Engine_Items_Number_Filter\Filters\Types;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Define User_Geolocation class
 */
class Items_Number_Switcher extends \Jet_Smart_Filters_Filter_Base {

	/**
	 * Get provider ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'items-number-switcher';
	}

	/**
	 * Get provider name
	 *
	 * @return string
	 */
	public function get_name() {
		return __( 'Items Number Switcher', 'jet-engine' );
	}

	/**
	 * Get provider wrapper selector
	 *
	 * @return string
	 */
	public function get_scripts() {
		return array( 'jet-engine-items-number-switcher' );
	}

	public function get_template( $args = array() ) {
		return JET_ENGINE_ITEMS_NUMBER_FILTER_PATH . 'includes/filters/types/items-number-switcher-template.php';
	}

	/**
	 * Prepare filter template argumnets
	 *
	 * @param  [type] $args [description]
	 *
	 * @return [type]       [description]
	 */
	public function prepare_args( $args ) {

		$content_provider = isset( $args['content_provider'] ) ? $args['content_provider'] : false;
		$additional_providers = isset( $args['additional_providers'] ) ? $args['additional_providers'] : false;

		$result = array(
			'query_type'               => \Jet_Engine_Items_Number_Filter\Filters\Manager::get_filter_var(),
			'query_var'                => '',
			'content_provider'         => $content_provider,
			'additional_providers'     => $additional_providers,
			'apply_type'               => 'ajax',
			'block_editor_breakpoints' => ! empty( $args['block_editor_breakpoints'] ) ? $args['block_editor_breakpoints'] : array(),
		);

		foreach ( $args as $key => $arg ) {
			if ( false !== strpos( $key, 'posts_num_responsive' ) ) {
				$result[ $key ] = $arg;
			}
		}

		return $result;

	}

	public function additional_filter_data_atts( $args ) {

		$result = array();

		foreach ( $args as $key => $arg ) {
			if ( false !== strpos( $key, 'posts_num_responsive' ) ) {
				$key = str_replace( ':', '_', $key );
				$result[ 'data-' . $key ] = $arg;
			}
		}

		if ( ! empty( $args['block_editor_breakpoints'] ) ) {
			$result['data-is-block'] = 1;

			foreach ( $args['block_editor_breakpoints'] as $item ) {
				$breakpoint = absint( $item['breakpoint'] );
				$number     = absint( $item['number'] );
	
				if ( ! $breakpoint || ! $number ) {
					continue;
				}
	
				$result[ 'data-posts_num_responsive_' . $breakpoint ] = $number;
			}
		}

		return $result;
	}

}
