<?php
namespace Jet_Engine_Items_Number_Filter\Filters;

class Manager {

	private static $var = '_items_per_page';

	public function __construct() {

		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ), -999 );
		add_action( 'enqueue_block_editor_assets', array( $this, 'register_assets' ), -999 );

		add_action( 'jet-engine/blocks-views/editor-script/after', array( $this, 'register_block_editor_assets' ), 100 );

		add_action( 'jet-smart-filters/filter-types/register', array( $this, 'register_filter_types' ), 100 );

		add_action( 'jet-engine/elementor-views/widgets/register', array( $this, 'register_widgets' ), 100, 2 );

		// general query var
		add_filter( 'jet-smart-filters/query/vars', array( $this, 'register_query_var' ) );
		// query var for permalink parser
		add_filter( 'jet-smart-filters/render/query-vars', array( $this, 'register_query_var' ) );
		// parse geo query variable before storing to request
		add_filter( 'jet-smart-filters/render/set-query-var', array( $this, 'parse_query_var' ), 10, 2 );

		add_filter( 'jet-smart-filters/filters/valid-url-params', array( $this, 'add_valid_url_params' ) );

		add_action( 'init', array( $this, 'init_bricks' ), 100 );

		add_action( 'jet-engine/blocks-views/register-block-types', array( $this, 'register_block_types' ) );

		add_filter( 'jet-smart-filters/admin/filter-types', array( $this, 'hide_filter_in_admin' ) );

	}

	public static function get_filter_var() {
		return self::$var;
	}

	public function hide_filter_in_admin( $types ) {
		unset( $types['items-number-switcher'] );
		return $types;
	}

	public function register_block_types( $blocks_types ) {
		require_once JET_ENGINE_ITEMS_NUMBER_FILTER_PATH . '/includes/filters/blocks-types/items-number-switcher.php';

		$item_switcher = new Blocks\Items_Number_Switcher();

		$blocks_types->register_block_type( $item_switcher );
	}

	public function has_bricks() {
		return ( defined( 'BRICKS_VERSION' ) && \Jet_Engine\Modules\Performance\Module::instance()->is_tweak_active( 'enable_bricks_views' ) );
	}

	public function init_bricks() {
		if ( ! $this->has_bricks() ) {
			return;
		}

		\Bricks\Elements::register_element( JET_ENGINE_ITEMS_NUMBER_FILTER_PATH . '/includes/filters/bricks/items-number-switcher.php' );

		add_filter( 'jet-engine/listing/frontend/js-settings', array( $this, 'add_bricks_breakpoints_data' ) );
	}

	public function add_bricks_breakpoints_data( $data ) {
		$breakpoints = array();

		foreach ( \Bricks\Breakpoints::get_breakpoints() as $b ) {
			$breakpoints[] = array( 'name' => $b['key'], 'width' => $b['width'] );
		}

		usort( $breakpoints, function( $a, $b ) {
			return $a['width'] <=> $b['width'];
		} );

		$data['bricksBreakpoints'] = $breakpoints;

		return $data;
	}

	public function parse_query_var( $value, $var ) {

		if ( self::$var === $var && $value ) {

			$parsed_value = array();

			foreach ( explode( ';', $value ) as $row ) {
				$row_data = explode( ':', $row, 2 );
				$parsed_value[ $row_data[0] ] = $row_data[1];
			}

			$value = $parsed_value;

		}

		return $value;
	}

	public function register_query_var( $vars ) {
		$vars[] = self::$var;
		return $vars;
	}

	public function register_assets() {
		
		wp_register_script(
			'jet-engine-items-number-switcher',
			JET_ENGINE_ITEMS_NUMBER_FILTER_URL . 'assets/js/frontend/items-number-switcher.js',
			array( 'jquery' ),
			jet_engine()->get_version(),
			true
		);

	}

	public function register_block_editor_assets() {
		wp_enqueue_script(
			'jet-engine-items-number-switcher-editor',
			JET_ENGINE_ITEMS_NUMBER_FILTER_URL . 'assets/js/admin/blocks-views/blocks.js',
			array( 'jet-engine-blocks-views' ),
			jet_engine()->get_version(),
			true
		);
	}

	public function register_widgets( $widgets_manager, $elementor_views ) {

		$filters_path = JET_ENGINE_ITEMS_NUMBER_FILTER_PATH . 'includes/filters/elementor-widgets';

		$elementor_views->register_widget(
			$filters_path . '/items-number-switcher.php',
			$widgets_manager,
			__NAMESPACE__ . '\Elementor_Widgets\Items_Number_Switcher'
		);

	}

	public function register_filter_types( $types_manager ) {

		$filters_path = JET_ENGINE_ITEMS_NUMBER_FILTER_PATH . 'includes/filters/types';

		$types_manager->register_filter_type(
			'\Jet_Engine_Items_Number_Filter\Filters\Types\Items_Number_Switcher',
			$filters_path . '/items-number-switcher.php'
		);

	}

	public function add_valid_url_params( $params ) {
		$params[] = self::$var;
		return $params;
	}

}
