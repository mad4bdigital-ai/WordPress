<?php
namespace Jet_Engine_Items_Number_Filter\Filters\Elementor_Widgets;

use \Elementor\Controls_Manager;
use \Elementor\Repeater;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Items_Number_Switcher extends \Elementor\Jet_Smart_Filters_Base_Widget {

	public function get_name() {
		return 'jet-smart-filters-items-number-switcher';
	}

	public function get_title() {
		return __( 'Items Number Switcher', 'jet-engine' );
	}

	public function get_icon() {
		return 'jet-engine-icon-items-number-switcher';
	}

	public function get_custom_help_url() {
		return;	
	}

	public function content_providers() {
		$allowed = array(
			'jet-engine',
			'jet-woo-products-grid',
			'jet-woo-products-list',
			'jet-data-table',
		);

		$allowed = apply_filters( 'jet-engine/maps-listing/map-sync/allowed-providers/elementor', $allowed );

		$all = jet_smart_filters()->data->content_providers();

		$result = array();

		foreach ( $allowed as $name ) {
			if ( ! isset( $all[ $name ] ) ) {
				continue;
			}

			$result[ $name ] = $all[ $name ];
		}

		return $result;
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_general',
			array(
				'label' => __( 'Content', 'jet-smart-filters' ),
			)
		);

		$query_builder_link = admin_url( 'admin.php?page=jet-engine-query' );

		$this->add_control(
			'query_notice',
			array(
				'label' => '',
				'type' => Controls_Manager::RAW_HTML,
				'raw' => sprintf( __( '<b>Please note!</b><br><div class="elementor-control-field-description">This filter is compatible only with queries from <a href="%s" target="_blank">the JetEngine Query Builder</a>.', 'jet-engine' ), $query_builder_link ),
			)
		);

		$this->add_responsive_control(
			'posts_num_responsive',
			array(
				'label'       => __( 'Posts number', 'jet-engine' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 6,
				'min'         => -1,
				'max'         => 1000,
				'step'        => 1,
			)
		);

		$this->add_control(
			'content_provider',
			array(
				'label'   => __( 'This filter for', 'jet-engine' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->content_providers(),
			)
		);

		$this->add_control(
			'apply_on',
			array(
				'label'     => __( 'Apply on', 'jet-engine' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'value',
				'options'   => array(
					'value'  => __( 'Value change', 'jet-engine' ),
					'submit' => __( 'Click on apply button', 'jet-engine' ),
				),
				'condition' => array(
					'apply_type' => array( 'ajax', 'mixed' ),
				),
			)
		);

		$this->add_control(
			'query_id',
			array(
				'label'       => esc_html__( 'Query ID', 'jet-smart-filters' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'description' => __( 'Set a unique query ID if you use multiple widgets of the same provider on the page. Use the same ID for the filtered block, and for the JetEngine Query it is connected to.', 'jet-smart-filters' ),
			)
		);

		$this->add_control(
			'additional_providers_enabled',
			array(
				'label'        => esc_html__( 'Additional Providers Enabled', 'jet-smart-filters' ),
				'type'         => Controls_Manager::SWITCHER,
				'description'  => '',
				'label_on'     => esc_html__( 'Yes', 'jet-smart-filters' ),
				'label_off'    => esc_html__( 'No', 'jet-smart-filters' ),
				'return_value' => 'yes',
				'default'      => 'no',
			)
		);
		
		$repeater = new Repeater();
		
		$repeater->add_control(
			'additional_provider',
			array(
				'label'       => __( 'Additional Provider', 'jet-smart-filters' ),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'options'     => $this->content_providers(),
			)
		);
		
		$repeater->add_control(
			'additional_query_id',
			array(
				'label'       => esc_html__( 'Additional Query ID', 'jet-smart-filters' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
			)
		);
		
		$this->add_control(
			'additional_providers_list',
			array(
				'label' => __( 'Additional Providers List', 'jet-smart-filters' ),
				'type'  => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{ additional_provider + ( additional_query_id ? "/" + additional_query_id : "" ) }}',
				'condition'   => array(
					'additional_providers_enabled' => 'yes',
				),
			)
		);

		$this->end_controls_section();

		$this->register_filter_settings_controls();

	}

	protected function render() {
		jet_smart_filters()->set_filters_used();

		$this->add_render_attribute(
			'_wrapper',
			array(
				'style' => 'height: 0; width: 0; margin: 0; padding: 0; overflow: hidden;',
			)
		);

		$args = $this->get_settings();

		$args['filter_id'] = 0;

		$args['additional_providers'] = jet_smart_filters()->utils->get_additional_providers( $args );

		jet_smart_filters()->filter_types->render_filter_template( $this->get_widget_fiter_type(), $args );
	}

}
