<?php

namespace Jet_Engine_Items_Number_Filter\Filters\Filters\Bricks;

use Jet_Engine\Bricks_Views\Helpers\Options_Converter;
use Bricks\Helpers;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Items_Number_Switcher extends \Jet_Smart_Filters\Bricks_Views\Elements\Jet_Smart_Filters_Bricks_Base {
	// Element properties
	public $category = 'jetsmartfilters'; // Use predefined element category 'general'
	public $name = 'jet-smart-filters-items-number-switcher'; // Make sure to prefix your elements
	public $icon = 'jet-engine-icon-items-number-switcher'; // Themify icon font class
	public $scripts = [ 'jetEngineBricks' ]; // Script(s) run when element is rendered on frontend or updated in builder

	public $jet_element_render = 'items-number-switcher';

	// Return localised element label
	public function get_label() {
		return esc_html__( 'Items Number Switcher', 'jet-engine' );
	}

	// Set builder control groups
	public function set_control_groups() {
		$this->register_general_group();
	}

	// Set builder controls
	public function set_controls() {
		$this->register_general_controls();
	}

	public function register_general_controls() {

		$this->start_jet_control_group( 'section_general' );

		$query_builder_link = admin_url( 'admin.php?page=jet-engine-query' );

		$this->register_jet_control(
			'query_notice',
			[
				'content' => sprintf( __( '<b>Please note!</b><br><div class="elementor-control-field-description">This filter is compatible only with queries from <a href="%s" target="_blank">the JetEngine Query Builder</a>.', 'jet-engine' ), $query_builder_link ),
				'type' => 'info',
			]
		);

		// $this->register_jet_control(
		// 	'map_listing_id',
		// 	[
		// 		'tab'            => 'content',
		// 		'label'          => esc_html__( 'Map Listing ID', 'jet-smart-filters' ),
		// 		'type'           => 'text',
		// 		'hasDynamicData' => false,
		// 		'description'    => esc_html__( 'CSS ID of Map Listing that triggers filtering. If left empty, the first Map Listing on the page will be taken.', 'jet-smart-filters' ),
		// 	]
		// );

		$provider_allowed = \Jet_Smart_Filters\Bricks_Views\Manager::get_allowed_providers();

		$query_providers = array(
			'jet-engine'          => true,
			'bricks-query-loop'   => true,
			'jet-data-table'      => true,
		);

		$query_providers = apply_filters( 'jet-engine/maps-listing/map-sync/allowed-providers/bricks', $query_providers );

		$provider_allowed = array_intersect_key( $provider_allowed, $query_providers );

		$this->register_jet_control(
			'posts_num_responsive',
			[
				'tab'        => 'content',
				'label'      => esc_html__( 'Posts number', 'jet-engine' ),
				'type'       => 'number',
				'inline'  => true,
				'min' => 1,
				'max' => 10,
				'default'    => 6,
				'css'     => array(
					array(
						'property' => '--posts-num',
					),
				),
			]
		);

		$this->register_jet_control(
			'content_provider',
			[
				'tab'        => 'content',
				'label'      => esc_html__( 'This filter for', 'jet-smart-filters' ),
				'type'       => 'select',
				'options'    => Options_Converter::filters_options_by_key( jet_smart_filters()->data->content_providers(), $provider_allowed ),
				'searchable' => true,
			]
		);

		$this->register_jet_control(
			'query_id',
			[
				'tab'            => 'content',
				'label'          => esc_html__( 'Query ID', 'jet-smart-filters' ),
				'type'           => 'text',
				'hasDynamicData' => false,
				'description'    => esc_html__( 'Set a unique query ID if you use multiple widgets of the same provider on the page. Use the same ID for the filtered block, and for the JetEngine Query it is connected to.', 'jet-smart-filters' ),
			]
		);

		$this->register_jet_control(
			'additional_providers_enabled',
			[
				'tab'     => 'content',
				'label'   => esc_html__( 'Additional providers enabled', 'jet-smart-filters' ),
				'type'    => 'checkbox',
				'default' => false,
			]
		);

		$repeater = new \Jet_Engine\Bricks_Views\Helpers\Repeater();

		$repeater->add_control(
			'additional_provider_notice_cache_query_loop',
			[
				'tab'         => 'content',
				'type'        => 'info',
				'content'     => esc_html__( 'You have enabled the "Cache query loop" option.', 'jet-smart-filters' ),
				'description' => sprintf(
					esc_html__( 'This option will break the filters functionality. You can disable this option or use "JetEngine Query Builder" query type. Go to: %s > Cache query loop', 'jet-smart-filters' ),
					'<a href="' . Helpers::settings_url( '#tab-performance' ) . '" target="_blank">Bricks > ' . esc_html__( 'Settings', 'jet-smart-filters' ) . ' > Performance</a>'
				),
				'required'    => [
					[ 'additional_provider', '=', 'bricks-query-loop' ],
					[ 'cacheQueryLoops', '=', true, 'globalSettings' ],
				],
			]
		);

		$repeater->add_control(
			'additional_provider',
			[
				'label'      => esc_html__( 'Additional provider', 'jet-smart-filters' ),
				'type'       => 'select',
				'options'    => Options_Converter::filters_options_by_key( jet_smart_filters()->data->content_providers(), $provider_allowed ),
				'searchable' => true,
			]
		);

		$repeater->add_control(
			'additional_query_id',
			[
				'label' => esc_html__( 'Additional query ID', 'jet-smart-filters' ),
				'type'  => 'text',
			]
		);

		$this->register_jet_control(
			'additional_providers_list',
			[
				'tab'           => 'content',
				'label'         => esc_html__( 'Additional providers list', 'jet-smart-filters' ),
				'type'          => 'repeater',
				'titleProperty' => 'additional_provider',
				'fields'        => $repeater->get_controls(),
				'required'      => [ 'additional_providers_enabled', '=', true ],
			]
		);

		$this->end_jet_control_group();
	}

	// Render element HTML
	public function render() {
		
		jet_smart_filters()->set_filters_used();

		$settings = $this->parse_jet_render_attributes( $this->get_jet_settings() );

		$settings['filter_id'] = 0;
		$settings['additional_providers'] = jet_smart_filters()->utils->get_additional_providers( $settings );

		echo "<div {$this->render_attributes( '_root' )}>";
		jet_smart_filters()->filter_types->render_filter_template( 'items-number-switcher', $settings );
		echo "</div>";
	}

}
