<?php
namespace Jet_Engine_Items_Number_Filter\Filters\Blocks;

/**
 * Maps Listing View
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Define Maps_Listing_Blocks_Views_Type class
 */
class Items_Number_Switcher extends \Jet_Smart_Filters_Block_Base {

	/**
	 * Returns block name
	 *
	 * @return string
	 */
	public function get_name() {
		return 'items-number-switcher';
	}

	/**
	 * Return attributes array
	 *
	 * @return array
	 */
	public function get_attributes() {
		return array(
			'content_provider' => array(
				'type'    => 'string',
				'default' => 'not-selected',
			),
			'query_id' => array(
				'type'    => 'string',
				'default' => '',
			),
			'additional_providers_enabled' => array(
				'type'    => 'boolean',
				'default' => false,
			),
			'additional_providers_list' => array(
				'type'    => 'array',
				'default' => array(
					array(
						'additional_provider'       => '',
						'additional_providers_list' => '',
					)
				)
			),
			'block_editor_breakpoints' => array(
				'type'    => 'array',
				'default' => array(
					array(
						'breakpoint' => 767,
						'number'     => 3
					),
					array(
						'breakpoint' => 1024,
						'number'     => 3
					),
					array(
						'breakpoint' => 1920,
						'number'     => 3
					),
				),
			),
		);
	}

	/**
	 * Return callback
	 */
	public function render_callback( $settings = array() ) {

		jet_smart_filters()->set_filters_used();

		$settings['filter_id'] = 0;

		$settings['additional_providers'] = jet_smart_filters()->utils->get_additional_providers( $settings );

		ob_start();

		jet_smart_filters()->filter_types->render_filter_template( $this->get_name(), $settings );

		return ob_get_clean();
	}

}
