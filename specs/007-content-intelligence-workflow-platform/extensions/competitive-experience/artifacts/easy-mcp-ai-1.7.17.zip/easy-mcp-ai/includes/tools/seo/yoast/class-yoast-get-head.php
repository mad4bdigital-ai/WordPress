<?php




namespace Easy_MCP_AI\Tools\SEO;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Easy_MCP_AI\Tools\Base_Tool;

class Yoast_Get_Head extends Base_Tool {

	public function get_name() {
		return 'wp_yoast_get_head';
	}

	public function get_description() {
		return 'Gets the full rendered SEO head HTML and JSON-LD for a URL on this site via the Yoast SEO REST endpoint. Only URLs belonging to this site resolve. A foreign/off-site URL is refused by Yoast with a 404, which this tool surfaces as an error — and because Yoast returns that payload as an object rather than an array, the error message comes through EMPTY, so the failure looks unexplained. Always pass a URL on this site. Useful for auditing SEO or populating headless CMS metadata. Returns the rendered head HTML and parsed JSON-LD schema.';
	}

	public function get_category() {
		return 'yoast-seo';
	}

	public function get_required_capability() {
		return 'edit_posts';
	}

	public function get_annotations() {
		return array(
			'title'           => $this->get_title(),
			'readOnlyHint'    => true,
			'destructiveHint' => false,
			'openWorldHint'   => false,
		);
	}

	public function get_input_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'url' => array(
					'type'        => 'string',
					'description' => 'The URL to get SEO head data for.',
				),
			),
			'required'   => array( 'url' ),
		);
	}

	public function execute( array $arguments ) {
		if ( ! class_exists( 'WPSEO_Options' ) ) {
			throw new \RuntimeException( 'Yoast SEO is not active on this site. Please install and activate Yoast SEO to use this tool.' );
		}

		$this->validate_required( $arguments, array( 'url' ) );

		$params = array( 'url' => esc_url_raw( $arguments['url'] ) );

		return $this->rest_request( 'GET', '/yoast/v1/get_head', $params );
	}
}
