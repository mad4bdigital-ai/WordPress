<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function easy_mcp_ai_view_token_create( $users, $tools_by_cat, $token = null, $draft = null ) {
	$is_edit        = isset( $token ) && ! empty( $token );
$current_tools  = array();
if ( $is_edit ) {
    $current_tools = isset( $token['allowed_tools'] ) ? $token['allowed_tools'] : array();
    if ( is_string( $current_tools ) ) {
        $current_tools = json_decode( $current_tools, true );
    }
    if ( ! is_array( $current_tools ) ) {
        $current_tools = array();
    }
}
$is_all_tools = empty( $current_tools ) || in_array( '*', $current_tools, true );












$has_draft = is_array( $draft ) && ! empty( $draft );
if ( $has_draft ) {
    $current_tools = isset( $draft['allowed_tools'] ) ? (array) $draft['allowed_tools'] : array();
    $is_all_tools  = ! empty( $draft['all_tools'] );
}
$v_name      = $has_draft
    ? (string) ( $draft['name'] ?? '' )
    : ( $is_edit ? (string) $token['name'] : '' );
$v_user_id   = $has_draft
    ? (int) ( $draft['wp_user_id'] ?? 0 )
    : ( $is_edit ? (int) $token['wp_user_id'] : (int) get_current_user_id() );
$v_is_active = $has_draft ? ! empty( $draft['is_active'] ) : ( $is_edit && ! empty( $token['is_active'] ) );



$check_all   = $has_draft ? $is_all_tools : ( $is_all_tools || ! $is_edit );
$error       = isset( $_GET['error'] ) ? sanitize_text_field( wp_unslash( $_GET['error'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
?>
<div class="wrap wp-mcp-admin">
    <h1>
        <?php
        if ( $is_edit ) {
            esc_html_e( 'Edit Token', 'easy-mcp-ai' );
        } else {
            esc_html_e( 'Create New Token', 'easy-mcp-ai' );
        }
        ?>
    </h1>

    <?php include __DIR__ . '/partials/page-nav.php'; ?>

    <?php if ( 'name_required' === $error ) : ?>
        <div class="notice notice-error is-dismissible">
            <p><?php esc_html_e( 'Token name is required.', 'easy-mcp-ai' ); ?></p>
        </div>
    <?php endif; ?>

    <?php if ( 'create_failed' === $error ) : ?>
        <div class="notice notice-error is-dismissible">
            <p><?php esc_html_e( 'Failed to create token. Please try again.', 'easy-mcp-ai' ); ?></p>
        </div>
    <?php endif; ?>

    <?php if ( 'tools_required' === $error ) : ?>
        <div class="notice notice-error is-dismissible">
            <p><?php esc_html_e( 'Nothing was saved: no tools were selected. Choose at least one tool, or tick "Select All Tools (full access)".', 'easy-mcp-ai' ); ?></p>
        </div>
    <?php endif; ?>

    <?php if ( 'invalid_user' === $error ) : ?>
        <div class="notice notice-error is-dismissible">
            <p><?php esc_html_e( 'Invalid user selected. Tokens can only be assigned to administrators, editors, or authors.', 'easy-mcp-ai' ); ?></p>
        </div>
    <?php endif; ?>

    <form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=easy-mcp-ai-tokens' ) ); ?>" class="wp-mcp-token-form">
        <?php if ( $is_edit ) : ?>
            <?php wp_nonce_field( 'easy_mcp_ai_update_token' ); ?>
            <input type="hidden" name="easy_mcp_ai_update_token" value="1">
            <input type="hidden" name="token_id" value="<?php echo esc_attr( $token['id'] ); ?>">
        <?php else : ?>
            <?php wp_nonce_field( 'easy_mcp_ai_create_token' ); ?>
            <input type="hidden" name="easy_mcp_ai_create_token" value="1">
        <?php endif; ?>

        <!-- Placeholder removed: was always submitting "*" defeating per-tool permissions.
             JS form-submit handler adds "*" dynamically only when select-all is checked. -->

        <table class="form-table" role="presentation">
            <tr>
                <th scope="row">
                    <label for="token_name"><?php esc_html_e( 'Token Name', 'easy-mcp-ai' ); ?></label>
                </th>
                <td>
                    <input type="text" id="token_name" name="token_name" class="regular-text"
                        value="<?php echo esc_attr( $v_name ); ?>"
                        placeholder="<?php esc_attr_e( 'e.g., Claude Code - Production', 'easy-mcp-ai' ); ?>" required>
                    <p class="description"><?php esc_html_e( 'A descriptive name to identify this token.', 'easy-mcp-ai' ); ?></p>
                </td>
            </tr>

            <tr>
                <th scope="row">
                    <label for="wp_user_id"><?php esc_html_e( 'WordPress User', 'easy-mcp-ai' ); ?></label>
                </th>
                <td>
                    <select id="wp_user_id" name="wp_user_id" class="regular-text">
                        <?php foreach ( $users as $user ) : ?>
                            <?php $roles_display = implode( ', ', array_map( 'ucfirst', $user->roles ) ); ?>
                            <option value="<?php echo esc_attr( $user->ID ); ?>" <?php selected( $v_user_id, $user->ID ); ?>>
                                <?php echo esc_html( $user->display_name ); ?> (<?php echo esc_html( $roles_display ); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description"><?php esc_html_e( 'The WordPress user whose permissions this token will use when executing tools.', 'easy-mcp-ai' ); ?></p>
                </td>
            </tr>

            <tr>
                <th scope="row">
                    <label for="expires_at"><?php esc_html_e( 'Expiration Date', 'easy-mcp-ai' ); ?></label>
                </th>
                <td>
                    <?php
                    if ( $has_draft ) {
                        $expires_value = (string) ( $draft['expires_at'] ?? '' );
                    } elseif ( $is_edit ) {
                        $expires_value = ! empty( $token['expires_at'] ) ? gmdate( 'Y-m-d', strtotime( $token['expires_at'] . ' UTC' ) ) : '';
                    } else {
                        $expires_value = gmdate( 'Y-m-d', strtotime( '+30 days' ) );
                    }
                    ?>
                    <input type="date" id="expires_at" name="expires_at" class="regular-text"
                        value="<?php echo esc_attr( $expires_value ); ?>"
                        min="<?php echo esc_attr( gmdate( 'Y-m-d', strtotime( '+1 day' ) ) ); ?>">
                    <p class="description"><?php esc_html_e( 'Leave empty for a token that never expires.', 'easy-mcp-ai' ); ?></p>
                </td>
            </tr>

            <?php if ( $is_edit ) : ?>
                <tr>
                    <th scope="row">
                        <label for="is_active"><?php esc_html_e( 'Active', 'easy-mcp-ai' ); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" id="is_active" name="is_active" value="1"
                                <?php checked( $v_is_active ); ?>>
                            <?php esc_html_e( 'Token is active and can be used for authentication.', 'easy-mcp-ai' ); ?>
                        </label>
                    </td>
                </tr>
            <?php endif; ?>

            <tr>
                <th scope="row"><?php esc_html_e( 'Tool Permissions', 'easy-mcp-ai' ); ?></th>
                <td>
                    <fieldset>
                        <label class="wp-mcp-select-all">
                            <?php
                            












                            ?>
                            <input type="checkbox" id="wp-mcp-select-all-tools" name="allowed_tools_all" value="1" <?php checked( $check_all ); ?>>
                            <strong><?php esc_html_e( 'Select All Tools (full access)', 'easy-mcp-ai' ); ?></strong>
                        </label>

                        <div class="wp-mcp-filters" <?php echo $check_all ? 'style="display:none;"' : ''; ?>>
                            <div class="wp-mcp-multiselect" id="wp-mcp-filter-category" data-default-label="<?php esc_attr_e( 'All Categories', 'easy-mcp-ai' ); ?>">
                                <button type="button" class="wp-mcp-multiselect-btn" aria-haspopup="true" aria-expanded="false">
                                    <span class="wp-mcp-multiselect-label"><?php esc_html_e( 'All Categories', 'easy-mcp-ai' ); ?></span>
                                    <span class="wp-mcp-multiselect-arrow" aria-hidden="true">&#9660;</span>
                                </button>
                                <div class="wp-mcp-multiselect-dropdown">
                                    <?php foreach ( $tools_by_cat as $category => $tools ) : ?>
                                        <label class="wp-mcp-multiselect-option">
                                            <input type="checkbox" value="<?php echo esc_attr( $category ); ?>">
                                            <?php echo esc_html( ucfirst( $category ) ); ?>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <div class="wp-mcp-multiselect" id="wp-mcp-filter-action" data-default-label="<?php esc_attr_e( 'All Actions', 'easy-mcp-ai' ); ?>">
                                <button type="button" class="wp-mcp-multiselect-btn" aria-haspopup="true" aria-expanded="false">
                                    <span class="wp-mcp-multiselect-label"><?php esc_html_e( 'All Actions', 'easy-mcp-ai' ); ?></span>
                                    <span class="wp-mcp-multiselect-arrow" aria-hidden="true">&#9660;</span>
                                </button>
                                <div class="wp-mcp-multiselect-dropdown">
                                    <label class="wp-mcp-multiselect-option"><input type="checkbox" value="list"> <?php esc_html_e( 'List', 'easy-mcp-ai' ); ?></label>
                                    <label class="wp-mcp-multiselect-option"><input type="checkbox" value="get"> <?php esc_html_e( 'Get', 'easy-mcp-ai' ); ?></label>
                                    <label class="wp-mcp-multiselect-option"><input type="checkbox" value="create"> <?php esc_html_e( 'Create', 'easy-mcp-ai' ); ?></label>
                                    <label class="wp-mcp-multiselect-option"><input type="checkbox" value="update"> <?php esc_html_e( 'Update', 'easy-mcp-ai' ); ?></label>
                                    <label class="wp-mcp-multiselect-option"><input type="checkbox" value="delete"> <?php esc_html_e( 'Delete', 'easy-mcp-ai' ); ?></label>
                                    <label class="wp-mcp-multiselect-option"><input type="checkbox" value="search"> <?php esc_html_e( 'Search', 'easy-mcp-ai' ); ?></label>
                                    <label class="wp-mcp-multiselect-option"><input type="checkbox" value="upload"> <?php esc_html_e( 'Upload', 'easy-mcp-ai' ); ?></label>
                                </div>
                            </div>
                        </div>

                        <div class="wp-mcp-tools-tree wp-mcp-tools-grid" <?php echo ( $is_all_tools || ! $is_edit ) ? 'style="display:none;"' : ''; ?>>
                            <?php if ( ! empty( $tools_by_cat ) ) : ?>
                                <?php foreach ( $tools_by_cat as $category => $tools ) : ?>
                                    <div class="wp-mcp-tool-category">
                                        <label class="wp-mcp-category-toggle">
                                            <input type="checkbox" class="wp-mcp-category-checkbox" data-category="<?php echo esc_attr( $category ); ?>"
                                                <?php
                                                if ( $is_all_tools || ! $is_edit ) {
                                                    echo 'checked';
                                                } elseif ( $is_edit ) {
                                                    $cat_tool_names = array_map( function( $t ) { return $t['name']; }, $tools );
                                                    $all_checked    = ! array_diff( $cat_tool_names, $current_tools );
                                                    if ( $all_checked ) {
                                                        echo 'checked';
                                                    }
                                                }
                                                ?>>
                                            <strong><?php echo esc_html( ucfirst( $category ) ); ?></strong>
                                        </label>
                                        <div class="wp-mcp-tool-items">
                                            <?php foreach ( $tools as $tool ) : ?>
                                                <?php
                                                $tool_parts = explode( '_', $tool['name'], 3 );
                                                $action = isset( $tool_parts[1] ) ? $tool_parts[1] : '';
                                                ?>
                                                <label class="wp-mcp-tool-item">
                                                    <input type="checkbox" name="allowed_tools[]"
                                                        value="<?php echo esc_attr( $tool['name'] ); ?>"
                                                        class="wp-mcp-tool-checkbox" data-category="<?php echo esc_attr( $category ); ?>" data-action="<?php echo esc_attr( $action ); ?>"
                                                        <?php
                                                        if ( $check_all ) {
                                                            echo 'checked';
                                                        } elseif ( in_array( $tool['name'], $current_tools, true ) ) {
                                                            echo 'checked';
                                                        }
                                                        ?>>
                                                    <code><?php echo esc_html( $tool['name'] ); ?></code>
                                                    <?php
                                                    if ( ! empty( $tool['description'] ) ) :
                                                        $easy_mcp_ai_full_desc = (string) $tool['description'];
                                                        
                                                        
                                                        $easy_mcp_ai_short_desc = preg_match( '/^(.+?[.!?])(\s|$)/u', $easy_mcp_ai_full_desc, $easy_mcp_ai_desc_match )
                                                            ? $easy_mcp_ai_desc_match[1]
                                                            : $easy_mcp_ai_full_desc;
                                                        if ( mb_strlen( $easy_mcp_ai_short_desc ) > 160 ) {
                                                            $easy_mcp_ai_short_desc = rtrim( mb_substr( $easy_mcp_ai_short_desc, 0, 157 ) ) . '…';
                                                        }
                                                        ?>
                                                        <span class="description">&mdash; <?php echo esc_html( $easy_mcp_ai_short_desc ); ?></span>
                                                    <?php endif; ?>
                                                </label>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <p class="description"><?php esc_html_e( 'No tools are currently registered.', 'easy-mcp-ai' ); ?></p>
                            <?php endif; ?>
                        </div>

                        <ul class="description" style="list-style:disc;padding-left:1.2em;margin:4px 0;">
                            <li><?php esc_html_e( 'Uncheck "Select All" to choose individual tools.', 'easy-mcp-ai' ); ?></li>
                            <li><?php esc_html_e( 'Only select tools you actually use — saves tokens and limits unintended changes.', 'easy-mcp-ai' ); ?></li>
                            <li><strong><?php esc_html_e( 'Security notice:', 'easy-mcp-ai' ); ?></strong> <?php esc_html_e( 'Granting write or delete permissions allows the AI to create, modify, or permanently remove content on your site. By enabling these tools you accept the associated risk. We strongly recommend manually reviewing every non-read-only permission before granting it.', 'easy-mcp-ai' ); ?></li>
                        </ul>
                    </fieldset>
                </td>
            </tr>
        </table>

        <?php
        if ( $is_edit ) {
            submit_button( __( 'Update Token', 'easy-mcp-ai' ) );
        } else {
            submit_button( __( 'Create Token', 'easy-mcp-ai' ) );
        }
        ?>
    </form>
</div>
<?php
}
easy_mcp_ai_view_token_create(
    $users,
    $tools_by_cat,
    isset( $token ) ? $token : null,
    isset( $form_draft ) ? $form_draft : null
);
